"""Generates a royalty-free cinematic SFX + music-bed library from pure synthesis (no downloads, no licences).

Usage: python3 scripts/make_sfx.py   ->  public/sfx/*.wav
Swap any file for a better one from Pixabay / Freesound (CC0) with the same name.
"""
import numpy as np, soundfile as sf, os
SR = 48000
rng = np.random.default_rng(7)
os.makedirs("public/sfx", exist_ok=True)

def t(sec): return np.linspace(0, sec, int(SR * sec), endpoint=False)
def env(n, a=0.005, r=0.3):
    e = np.ones(n); ai = int(a * SR); ri = int(r * SR)
    e[:ai] = np.linspace(0, 1, ai); e[-ri:] *= np.linspace(1, 0, ri) ** 2; return e
def lp(x, k):  # cheap one-pole low-pass, k in (0,1)
    y = np.zeros_like(x); acc = 0.0
    for i, v in enumerate(x): acc += k * (v - acc); y[i] = acc
    return y
def norm(x, peak=0.9): return x / (np.max(np.abs(x)) + 1e-9) * peak
def save(name, x):
    x = norm(x); sf.write(f"public/sfx/{name}", np.stack([x, x], 1).astype(np.float32), SR); print(name)

# Cinematic boom: pitched-down sine + sub + noise thump
d = t(2.5); f = 70 * np.exp(-d * 2.2) + 28
boom = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-d * 1.6)
boom += 0.5 * lp(rng.standard_normal(len(d)), 0.05) * np.exp(-d * 6)
save("boom.wav", np.tanh(boom * 2.5))

# Whoosh: band-swept noise with swell
d = t(0.9); n = rng.standard_normal(len(d))
k = np.linspace(0.02, 0.35, len(d)); y = np.zeros_like(n); acc = 0
for i in range(len(n)): acc += k[i] * (n[i] - acc); y[i] = acc
save("whoosh.wav", y * np.sin(np.pi * d / d[-1]) ** 2)

# Stamp: hard transient + low thud
d = t(0.6)
stamp = np.sin(2 * np.pi * 90 * d) * np.exp(-d * 18) + 0.8 * rng.standard_normal(len(d)) * np.exp(-d * 60)
save("stamp.wav", np.tanh(stamp * 3))

# Ball kick
d = t(0.35)
save("kick.wav", np.sin(2 * np.pi * (180 * np.exp(-d * 20) + 60) * d) * np.exp(-d * 25) + 0.4 * rng.standard_normal(len(d)) * np.exp(-d * 120))

# Riser: rising tone + noise, 2.5s
d = t(2.5); f = 120 + 900 * (d / d[-1]) ** 2
riser = 0.6 * np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.5 * lp(rng.standard_normal(len(d)), 0.25)
save("riser.wav", riser * (d / d[-1]) ** 2)

# Heartbeat (lub-dub x4)
d = t(3.2); hb = np.zeros(len(d))
for b in range(4):
    for off, amp in [(0, 1.0), (0.22, 0.7)]:
        s = int((b * 0.8 + off) * SR); seg = t(0.25)
        hb[s:s + len(seg)] += amp * np.sin(2 * np.pi * 50 * seg) * np.exp(-seg * 22)
save("heartbeat.wav", hb)

# Shimmer: stacked bell partials for the trophy moment
d = t(3.0); sh = np.zeros(len(d))
for fr in [880, 1320, 1760, 2640, 3520]:
    sh += np.sin(2 * np.pi * fr * d + rng.random() * 6) * np.exp(-d * (1.2 + fr / 3000))
save("shimmer.wav", sh * env(len(d), 0.01, 1.0))

# Fire crackle bed
d = t(6.0); fire = 0.3 * lp(rng.standard_normal(len(d)), 0.08)
for _ in range(220):
    s = rng.integers(0, len(d) - 800); fire[s:s + 800] += rng.uniform(.2, 1) * rng.standard_normal(800) * np.exp(-np.arange(800) / 90)
save("fire.wav", fire * env(len(d), 0.3, 1.0))

# Crowd roar bed
d = t(6.0); crowd = lp(rng.standard_normal(len(d)), 0.12) + 0.4 * lp(rng.standard_normal(len(d)), 0.4)
save("crowd.wav", crowd * (0.6 + 0.4 * np.sin(2 * np.pi * 0.3 * d)) * env(len(d), 0.8, 1.5))

# Dark cinematic drone / music bed (minor chord pad, 50s)
d = t(50.0); pad = np.zeros(len(d))
for fr, a in [(55, 1), (110, .6), (130.81, .35), (164.81, .3), (220, .2)]:
    pad += a * np.sin(2 * np.pi * fr * d + 0.3 * np.sin(2 * np.pi * 0.07 * d))
pad += 0.15 * lp(rng.standard_normal(len(d)), 0.01)
save("drone.wav", pad * env(len(d), 2.0, 4.0))

# Ding: bright bell (e.g. a microwave finishing)
d = t(1.5); ding = np.zeros(len(d))
for fr, a in [(1568, 1.0), (3136, 0.4), (4704, 0.2)]:
    ding += a * np.sin(2 * np.pi * fr * d) * np.exp(-d * 4)
save("ding.wav", ding * env(len(d), 0.002, 0.4))

# Glitch: choppy digital stutter (signal interference)
d = t(0.8); g = np.zeros(len(d)); step = int(0.04 * SR)
for i in range(0, len(d), step):
    if rng.random() > 0.35:
        seg = min(step, len(d) - i)
        g[i:i + seg] = np.sign(np.sin(2 * np.pi * rng.uniform(200, 1800) * t(seg / SR)[:seg])) * rng.uniform(0.3, 1)
save("glitch.wav", g * 0.6 + 0.3 * rng.standard_normal(len(d)) * (np.abs(g) > 0))
