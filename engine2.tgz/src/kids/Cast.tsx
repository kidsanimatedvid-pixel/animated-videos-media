import React from 'react';

/* Suhail & Friends cast (each drawn in a 400x400 box, feet at about y=390, centre x=200).
   Every character takes the current frame `f`, a mouth opening `talk` (0..1) and a `mood`. */
export type Mood = 'happy' | 'sad' | 'greedy' | 'sour' | 'surprised' | 'calm';
export type CastProps = {f: number; talk?: number; mood?: Mood; seed?: number; look?: number; extra?: number};

// Blink for 5 frames roughly every 2.5-4 s, offset per character
export const blinkAmt = (f: number, seed = 0) => {
  const period = 90 + (seed % 4) * 17;
  const p = (f + seed * 37) % period;
  return p < 5 ? Math.sin((p / 5) * Math.PI) : 0;
};

const INK = '#2B1B12';

const Eye: React.FC<{cx: number; cy: number; rx: number; ry: number; blink: number; look?: number; lid?: number}> = ({cx, cy, rx, ry, blink, look = 0, lid = 0}) => {
  const sy = Math.max(0.08, 1 - blink);
  return (
    <g transform={`translate(${cx} ${cy}) scale(1 ${sy}) translate(${-cx} ${-cy})`}>
      <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={INK} />
      <circle cx={cx + 8 + look * 4} cy={cy - 10} r={rx * 0.36} fill="#fff" />
      <circle cx={cx - 5 + look * 3} cy={cy + 12} r={rx * 0.18} fill="#fff" opacity={0.8} />
      {lid > 0 ? <rect x={cx - rx - 2} y={cy - ry - 2} width={rx * 2 + 4} height={(ry * 2 + 4) * lid} fill="#F2A65A" /> : null}
    </g>
  );
};

/* ───────────── Suhail the fennec fox ───────────── */
export const Suhail: React.FC<CastProps> = ({f, talk = 0, mood = 'happy', seed = 1, look = 0}) => {
  const b = blinkAmt(f, seed);
  const earBase = mood === 'sad' || mood === 'sour' ? 28 : mood === 'surprised' ? -6 : 0;
  const wig = Math.sin(f * 0.18) * 2.5;
  const tail = Math.sin(f * 0.22) * (mood === 'sad' ? 3 : 9);
  const lid = mood === 'greedy' ? 0.45 : mood === 'sour' ? 0.38 : mood === 'sad' ? 0.25 : 0;
  const mouth = () => {
    if (talk > 0.12) {
      const h = 6 + talk * 18;
      return (
        <g>
          <ellipse cx={200} cy={246 + h / 2} rx={15} ry={h} fill="#6B2230" />
          <ellipse cx={200} cy={250 + h} rx={9} ry={Math.max(2, h * 0.4)} fill="#FF8FA3" />
        </g>
      );
    }
    if (mood === 'sad') return <path d="M186 252 Q 200 242 214 252" stroke={INK} strokeWidth={4.5} fill="none" strokeLinecap="round" />;
    if (mood === 'sour') return <path d="M184 248 q 5 -5 10 0 t 10 0 t 10 0" stroke={INK} strokeWidth={4.5} fill="none" strokeLinecap="round" />;
    if (mood === 'greedy') return <path d="M182 242 Q 200 262 222 240" stroke={INK} strokeWidth={5} fill="none" strokeLinecap="round" />;
    return <path d="M200 235 Q 200 246 188 248 M200 235 Q 200 246 212 248" stroke={INK} strokeWidth={4} fill="none" strokeLinecap="round" />;
  };
  return (
    <g>
      <g transform={`rotate(${tail} 270 300)`}>
        <path d="M290 330 C 360 320, 385 250, 345 205 C 330 250, 300 275, 262 290 Z" fill="#E8913F" />
        <path d="M345 205 C 372 232, 372 262, 360 282 C 350 262, 340 240, 330 228 Z" fill="#FFF1DC" />
      </g>
      <ellipse cx={200} cy={318} rx={92} ry={70} fill="#F2A65A" />
      <ellipse cx={200} cy={332} rx={52} ry={48} fill="#FFF1DC" />
      <ellipse cx={160} cy={382} rx={30} ry={14} fill="#E8913F" />
      <ellipse cx={240} cy={382} rx={30} ry={14} fill="#E8913F" />
      <g transform={`rotate(${-earBase - wig} 150 135)`}>
        <path d="M120 150 C 70 90, 55 30, 72 6 C 120 20, 165 70, 175 125 Z" fill="#F2A65A" />
        <path d="M125 135 C 95 95, 85 55, 92 34 C 122 48, 150 85, 158 120 Z" fill="#FFC9A8" />
      </g>
      <g transform={`rotate(${earBase + wig} 250 135)`}>
        <path d="M280 150 C 330 90, 345 30, 328 6 C 280 20, 235 70, 225 125 Z" fill="#F2A65A" />
        <path d="M275 135 C 305 95, 315 55, 308 34 C 278 48, 250 85, 242 120 Z" fill="#FFC9A8" />
      </g>
      <ellipse cx={200} cy={185} rx={98} ry={84} fill="#F2A65A" />
      <path d="M110 200 C 130 255, 175 268, 200 268 C 225 268, 270 255, 290 200 C 265 215, 235 205, 200 225 C 165 205, 135 215, 110 200 Z" fill="#FFF1DC" />
      <ellipse cx={138} cy={222} rx={16} ry={10} fill="#FF8FA3" opacity={0.55} />
      <ellipse cx={262} cy={222} rx={16} ry={10} fill="#FF8FA3" opacity={0.55} />
      <Eye cx={160} cy={180} rx={22} ry={27} blink={b} look={look} lid={lid} />
      <Eye cx={240} cy={180} rx={22} ry={27} blink={b} look={look} lid={lid} />
      {mood === 'sad' ? (
        <>
          <path d="M140 150 Q 158 146 176 136" stroke="#C9722C" strokeWidth={5} fill="none" strokeLinecap="round" />
          <path d="M224 136 Q 242 146 260 150" stroke="#C9722C" strokeWidth={5} fill="none" strokeLinecap="round" />
        </>
      ) : (
        <>
          <path d={mood === 'surprised' ? 'M140 135 Q 158 124 176 134' : 'M140 145 Q 158 136 176 144'} stroke="#C9722C" strokeWidth={5} fill="none" strokeLinecap="round" />
          <path d={mood === 'surprised' ? 'M224 134 Q 242 124 260 135' : 'M224 144 Q 242 136 260 145'} stroke="#C9722C" strokeWidth={5} fill="none" strokeLinecap="round" />
        </>
      )}
      <path d="M188 222 Q 200 214 212 222 Q 206 234 200 235 Q 194 234 188 222 Z" fill={INK} />
      {mouth()}
      <path d="M118 252 C 150 280, 250 280, 282 252 L 290 276 C 250 305, 150 305, 110 276 Z" fill="#2EC4B6" />
      <g transform={`rotate(${Math.sin(f * 0.15) * 3} 245 285)`}>
        <path d="M250 280 L 285 345 L 255 350 L 232 290 Z" fill="#22A699" />
        <path d="M262 318 L 278 316 M258 330 L 280 328" stroke="#1B8A80" strokeWidth={3} />
      </g>
    </g>
  );
};

/* ───────────── Qamra the crescent moon (narrator) ───────────── */
export const Qamra: React.FC<CastProps> = ({f, talk = 0}) => {
  const tw = (k: number) => 0.6 + 0.4 * Math.sin(f * 0.12 + k);
  const glow = 1 + Math.sin(f * 0.06) * 0.04;
  const id = 'qm' + Math.round(talk * 0) ; // stable id
  return (
    <g>
      <g transform={`translate(190 200) scale(${glow}) translate(-190 -200)`}>
        <circle cx={190} cy={200} r={185} fill="#9FD8FF" opacity={0.15} />
        <circle cx={190} cy={200} r={160} fill="#9FD8FF" opacity={0.18} />
      </g>
      <defs>
        <mask id={id}>
          <rect width={400} height={400} fill="#fff" />
          <circle cx={290} cy={150} r={125} fill="#000" />
        </mask>
      </defs>
      <circle cx={190} cy={200} r={145} fill="#FFE08A" mask={`url(#${id})`} />
      <circle cx={190} cy={200} r={145} fill="none" stroke="#F5C451" strokeWidth={8} mask={`url(#${id})`} />
      <path d="M78 190 Q 92 202 106 190" stroke="#6B4A12" strokeWidth={6} fill="none" strokeLinecap="round" />
      <path d="M128 198 Q 142 210 156 198" stroke="#6B4A12" strokeWidth={6} fill="none" strokeLinecap="round" />
      <path d="M76 186 L 70 178 M86 184 L 83 175" stroke="#6B4A12" strokeWidth={4} strokeLinecap="round" />
      <ellipse cx={86} cy={222} rx={14} ry={9} fill="#FF9FB0" opacity={0.75} />
      <ellipse cx={150} cy={228} rx={12} ry={8} fill="#FF9FB0" opacity={0.75} />
      {talk > 0.12 ? (
        <ellipse cx={119} cy={242} rx={12} ry={4 + talk * 12} fill="#7A3B2A" />
      ) : (
        <path d="M104 236 Q 118 250 134 238" stroke="#6B4A12" strokeWidth={6} fill="none" strokeLinecap="round" />
      )}
      <g transform={`rotate(${Math.sin(f * 0.08) * 8} 128 92)`}>
        <path d="M118 62 l9 18 20 3 -14 14 3 20 -18 -9 -18 9 3 -20 -14 -14 20 -3z" fill="#FFFFFF" stroke="#F5C451" strokeWidth={4} strokeLinejoin="round" />
      </g>
      <path d="M300 300 l6 14 14 6 -14 6 -6 14 -6 -14 -14 -6 14 -6z" fill="#FFF7D6" opacity={tw(0)} />
      <path d="M330 230 l4 9 9 4 -9 4 -4 9 -4 -9 -9 -4 9 -4z" fill="#FFF7D6" opacity={tw(2)} />
      <path d="M40 300 l4 9 9 4 -9 4 -4 9 -4 -9 -9 -4 9 -4z" fill="#FFF7D6" opacity={tw(4)} />
    </g>
  );
};

/* ───────────── Jummul the baby camel ───────────── */
const C1 = '#EFC88C';
const C2 = '#D9A866';
const C3 = '#FFF3DE';
export const Jummul: React.FC<CastProps> = ({f, talk = 0, mood = 'happy', seed = 2, extra = 0}) => {
  const b = blinkAmt(f, seed);
  const headBob = Math.sin(f * 0.1) * 3 + (mood === 'sad' ? 10 : 0);
  const chew = extra > 0 ? Math.abs(Math.sin(f * 0.5)) : 0; // extra>0 = chewing
  const sy = Math.max(0.08, 1 - b);
  return (
    <g>
      <g transform={`rotate(${Math.sin(f * 0.2) * 10} 95 290)`}>
        <path d="M95 290 C 70 300, 65 330, 78 345" stroke="#C9A06A" strokeWidth={8} fill="none" strokeLinecap="round" />
        <ellipse cx={78} cy={350} rx={10} ry={14} fill="#8A6440" />
      </g>
      <rect x={115} y={320} width={34} height={62} rx={17} fill={C2} />
      <rect x={245} y={320} width={34} height={62} rx={17} fill={C2} />
      <g transform={`rotate(${Math.sin(f * 0.12) * 4} 200 250)`}>
        <path d="M130 255 C 120 185, 175 160, 215 180 C 240 195, 245 225, 250 255 Z" fill={C1} />
        <path d="M205 178 C 235 170, 262 190, 258 215 C 245 205, 228 200, 215 198 Z" fill={C2} />
      </g>
      <ellipse cx={200} cy={290} rx={112} ry={62} fill={C1} />
      <ellipse cx={205} cy={305} rx={70} ry={38} fill={C3} />
      <rect x={150} y={325} width={36} height={62} rx={18} fill={C1} />
      <rect x={215} y={325} width={36} height={62} rx={18} fill={C1} />
      <ellipse cx={168} cy={386} rx={22} ry={9} fill="#C9A06A" />
      <ellipse cx={233} cy={386} rx={22} ry={9} fill="#C9A06A" />
      <path d="M270 270 C 300 240, 300 200, 292 170 L 330 165 C 345 205, 330 255, 300 290 Z" fill={C1} />
      <g transform={`translate(0 ${headBob}) rotate(${mood === 'sad' ? 8 : 0} 300 170)`}>
        <ellipse cx={282} cy={88} rx={12} ry={20} fill={C2} transform={`rotate(${-25 - (mood === 'sad' ? 30 : 0)} 282 88)`} />
        <ellipse cx={330} cy={84} rx={12} ry={20} fill={C2} transform={`rotate(${20 + (mood === 'sad' ? 30 : 0)} 330 84)`} />
        <ellipse cx={308} cy={135} rx={62} ry={52} fill={C1} />
        <ellipse cx={350} cy={160} rx={42} ry={32} fill={C3} />
        <path d="M290 88 q 8 -16 18 -2 q 8 -16 18 0 q 6 -12 14 4" fill="#C9A06A" />
        <g transform={`translate(315 125) scale(1 ${sy}) translate(-315 -125)`}>
          <ellipse cx={315} cy={125} rx={13} ry={17} fill={INK} />
          <circle cx={320} cy={118} r={5} fill="#fff" />
          <path d="M304 110 l -10 -12 M312 107 l -4 -15 M321 107 l 2 -15 M329 111 l 8 -12" stroke={INK} strokeWidth={4} strokeLinecap="round" />
        </g>
        {mood === 'sad' ? <path d="M298 104 L 326 96" stroke="#8A6440" strokeWidth={4} strokeLinecap="round" /> : null}
        <ellipse cx={372} cy={150} rx={5} ry={3} fill="#8A6440" />
        {talk > 0.12 || chew > 0.3 ? (
          <ellipse cx={356} cy={182} rx={14} ry={3 + Math.max(talk, chew * 0.6) * 12} fill="#6B2E22" />
        ) : mood === 'sad' ? (
          <path d="M342 186 Q 356 176 372 186" stroke="#8A6440" strokeWidth={5} fill="none" strokeLinecap="round" />
        ) : (
          <path d="M340 178 Q 356 190 374 178" stroke="#8A6440" strokeWidth={5} fill="none" strokeLinecap="round" />
        )}
        <ellipse cx={300} cy={158} rx={13} ry={8} fill="#FF9FB0" opacity={0.6} />
      </g>
    </g>
  );
};

/* ───────────── Hudhud the hoopoe ───────────── */
export const Hudhud: React.FC<CastProps & {crest?: number; flap?: number}> = ({f, talk = 0, seed = 3, crest = 1, flap = 0}) => {
  const b = blinkAmt(f, seed);
  const spread = 0.55 + 0.45 * crest; // 0 = folded, 1 = full fan
  const wing = flap > 0 ? Math.sin(f * 1.1) * 35 * flap : Math.sin(f * 0.1) * 3;
  const sy = Math.max(0.08, 1 - b);
  const feather = (a: number, k: number) => (
    <g key={k} transform={`rotate(${a * spread} 205 128)`}>
      <rect x={193} y={25 + (1 - crest) * 30} width={24} height={100 - (1 - crest) * 30} rx={12} fill="#F0A35E" />
      <rect x={193} y={40 + (1 - crest) * 30} width={24} height={12} fill="#FFFFFF" />
      <path d={`M193 ${52 + (1 - crest) * 30} V ${37 + (1 - crest) * 30} A 12 12 0 0 1 217 ${37 + (1 - crest) * 30} V ${40 + (1 - crest) * 30} H 193 Z`} fill={INK} />
    </g>
  );
  return (
    <g>
      {[-50, -25, 0, 25, 50].map((a, k) => feather(a + Math.sin(f * 0.2 + k) * 2, k))}
      <path d="M120 270 L 40 320 L 55 345 L 135 300 Z" fill={INK} />
      <path d="M62 309 L 74 332 L 88 324 L 76 300 Z" fill="#FFFFFF" />
      <path d="M185 320 V 375 M220 320 V 375" stroke="#7A5A48" strokeWidth={7} strokeLinecap="round" />
      <path d="M170 378 H 200 M205 378 H 235" stroke="#7A5A48" strokeWidth={7} strokeLinecap="round" />
      <ellipse cx={200} cy={260} rx={88} ry={72} fill="#E8A36B" />
      <ellipse cx={225} cy={280} rx={50} ry={45} fill="#FFE2C4" />
      <g transform={`rotate(${-wing} 205 240)`}>
        <path d="M120 230 C 150 215, 205 225, 215 262 C 200 300, 140 300, 115 275 Z" fill={INK} />
        <path d="M135 236 L 150 294 M160 228 L 172 298 M186 232 L 194 290" stroke="#FFFFFF" strokeWidth={9} strokeLinecap="round" />
      </g>
      <circle cx={215} cy={165} r={60} fill="#F0A35E" />
      <path d="M265 170 C 300 172, 335 185, 362 210 C 330 200, 298 192, 262 188 Z" fill="#3A2A20" />
      <g transform={`rotate(${talk * 14} 265 186)`}>
        <path d="M264 186 C 298 192, 330 200, 360 212 C 326 206, 296 202, 262 198 Z" fill="#5A4436" />
      </g>
      <g transform={`translate(232 155) scale(1 ${sy}) translate(-232 -155)`}>
        <circle cx={232} cy={155} r={17} fill={INK} />
        <circle cx={238} cy={149} r={6} fill="#fff" />
      </g>
      <ellipse cx={218} cy={185} rx={12} ry={7} fill="#FF8FA3" opacity={0.6} />
    </g>
  );
};

/* ───────────── Arnab the rabbit (guest, letter أ) ───────────── */
export const Arnab: React.FC<CastProps> = ({f, talk = 0, seed = 4}) => {
  const b = blinkAmt(f, seed);
  const sy = Math.max(0.08, 1 - b);
  const ear = Math.sin(f * 0.2) * 4;
  return (
    <g>
      <circle cx={110} cy={320} r={26} fill="#FFFFFF" />
      <ellipse cx={200} cy={310} rx={85} ry={72} fill="#E9E4F0" />
      <ellipse cx={205} cy={325} rx={48} ry={44} fill="#FFFFFF" />
      <ellipse cx={160} cy={382} rx={32} ry={13} fill="#D6CFE2" />
      <ellipse cx={245} cy={382} rx={32} ry={13} fill="#D6CFE2" />
      <g transform={`rotate(${-8 - ear} 175 130)`}>
        <ellipse cx={170} cy={60} rx={24} ry={78} fill="#E9E4F0" />
        <ellipse cx={170} cy={64} rx={12} ry={60} fill="#FFC2D1" />
      </g>
      <g transform={`rotate(${10 + ear} 230 130)`}>
        <ellipse cx={235} cy={60} rx={24} ry={78} fill="#E9E4F0" />
        <ellipse cx={235} cy={64} rx={12} ry={60} fill="#FFC2D1" />
      </g>
      <ellipse cx={203} cy={185} rx={80} ry={68} fill="#E9E4F0" />
      <ellipse cx={203} cy={215} rx={46} ry={32} fill="#FFFFFF" />
      <g transform={`translate(0 180) scale(1 ${sy}) translate(0 -180)`}>
        <ellipse cx={172} cy={172} rx={15} ry={19} fill={INK} />
        <ellipse cx={234} cy={172} rx={15} ry={19} fill={INK} />
        <circle cx={177} cy={165} r={5} fill="#fff" />
        <circle cx={239} cy={165} r={5} fill="#fff" />
      </g>
      <ellipse cx={150} cy={205} rx={13} ry={8} fill="#FF9FB0" opacity={0.7} />
      <ellipse cx={256} cy={205} rx={13} ry={8} fill="#FF9FB0" opacity={0.7} />
      <path d="M195 200 Q 203 194 211 200 Q 203 210 195 200 Z" fill="#FF7A9C" />
      {talk > 0.12 ? <ellipse cx={203} cy={222} rx={9} ry={3 + talk * 8} fill="#6B2230" /> : <path d="M203 206 v 8 M203 214 q -8 8 -14 2 M203 214 q 8 8 14 2" stroke={INK} strokeWidth={3.5} fill="none" strokeLinecap="round" />}
      <rect x={196} y={226} width={14} height={12} rx={3} fill="#fff" stroke="#D6CFE2" strokeWidth={2} />
    </g>
  );
};
