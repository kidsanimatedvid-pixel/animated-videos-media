import React from 'react';
import type {Caption} from '@remotion/captions';
import {AbsoluteFill, interpolate, random, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {EASE, kf} from '../components/Motion';
import {Hudhud, Jummul, Qamra, Suhail, type Mood} from './Cast';

/* One data-driven scene for the kids channel. A storyboard scene sets:
   bg: 'day' | 'dusk' | 'night'
   actors: [{who, x, y, s, flip?, enter?, enterAt?, mood?, mood2?, mood2On?, basket?, hop?, eat?, crest?, crestOn?, flap?}]
   props: [{type: 'palm'|'dates'|'rumble'|'hearts'|'badge'|'title'|'sparkles', ...}]
   cam: {z0, z1, fx, fy}; captionTop.
   The actor whose `who` equals scene.speaker moves its mouth on every spoken word. */

type Actor = {
  who: 'suhail' | 'qamra' | 'jummul' | 'hudhud';
  x: number; y: number; s: number; flip?: boolean;
  enter?: 'left' | 'right' | 'fly' | 'pop' | 'none'; enterAt?: number; enterOn?: string;
  mood?: Mood; mood2?: Mood; mood2On?: string;
  basket?: 'empty' | 'full'; hop?: boolean; eat?: boolean; crest?: number; crestOn?: string; flap?: boolean; look?: number;
};
type Prop = {type: string; x?: number; y?: number; s?: number; on?: string; text?: string; sub?: string; color?: string};

const clean = (w: string) => w.replace(/[^\p{L}\p{N}]/gu, '');
const onWord = (caps: Caption[], word: string | undefined, fps: number, fallback = 0) => {
  if (!word) return fallback;
  const c = caps.find((c) => clean(c.text).startsWith(clean(word)));
  return c ? Math.round((c.startMs / 1000) * fps) : fallback;
};
const talkAt = (caps: Caption[], f: number, fps: number) => {
  const ms = (f / fps) * 1000;
  const w = caps.find((c) => ms >= c.startMs - 30 && ms < c.endMs - 40);
  return w ? 0.35 + 0.65 * Math.abs(Math.sin(f * 0.55)) : 0;
};

/* ── backgrounds ── */
const SKY: Record<string, [string, string, string]> = {
  day: ['#7FCBFF', '#BDE6FF', '#FFE9BF'],
  dusk: ['#5B5AA8', '#C98BB9', '#FFC59A'],
  night: ['#1E2257', '#38407F', '#6A5D9A'],
};
const Background: React.FC<{kind: string; f: number}> = ({kind, f}) => {
  const [a, b, c] = SKY[kind] ?? SKY.day;
  const night = kind === 'night';
  const sand1 = night ? '#6E5A7E' : kind === 'dusk' ? '#E39A6A' : '#F2C27A';
  const sand2 = night ? '#58486A' : kind === 'dusk' ? '#D9875A' : '#E9AE62';
  const sand3 = night ? '#4A3C5C' : kind === 'dusk' ? '#CC7A50' : '#E0A055';
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <defs>
        <linearGradient id={`sky-${kind}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={a} /><stop offset="0.55" stopColor={b} /><stop offset="1" stopColor={c} />
        </linearGradient>
      </defs>
      <rect width={1080} height={1920} fill={`url(#sky-${kind})`} />
      {night
        ? Array.from({length: 40}).map((_, i) => (
            <circle key={i} cx={random(`sx${i}`) * 1080} cy={random(`sy${i}`) * 900} r={2 + random(`sr${i}`) * 3}
              fill="#FFF7D6" opacity={0.4 + 0.6 * Math.abs(Math.sin(f * 0.05 + i))} />
          ))
        : (
          <>
            <circle cx={860} cy={300} r={kind === 'dusk' ? 110 : 90} fill={kind === 'dusk' ? '#FFB37A' : '#FFE27A'} opacity={0.9} />
            {[0, 1, 2].map((i) => {
              const x = ((i * 420 + f * (0.6 + i * 0.2)) % 1500) - 250;
              return (
                <g key={i} transform={`translate(${x} ${200 + i * 140})`} opacity={kind === 'dusk' ? 0.55 : 0.9}>
                  <ellipse cx={0} cy={0} rx={90} ry={34} fill="#fff" /><ellipse cx={60} cy={-18} rx={60} ry={34} fill="#fff" /><ellipse cx={-55} cy={-8} rx={50} ry={26} fill="#fff" />
                </g>
              );
            })}
          </>
        )}
      <path d="M0 960 C 250 880, 520 990, 780 930 C 900 905, 1000 930, 1080 920 L1080 1920 L0 1920Z" fill={sand1} />
      <path d="M0 1060 C 300 1000, 640 1090, 1080 1030 L1080 1920 L0 1920Z" fill={sand2} />
      <path d="M0 1180 C 350 1130, 700 1200, 1080 1160 L1080 1920 L0 1920Z" fill={sand3} />
      {Array.from({length: 14}).map((_, i) => (
        <ellipse key={i} cx={random(`p${i}`) * 1080} cy={1200 + random(`q${i}`) * 500} rx={8 + random(`r${i}`) * 10} ry={3} fill="#000" opacity={0.06} />
      ))}
    </svg>
  );
};

/* ── props ── */
const Palm: React.FC<{x: number; y: number; s: number; f: number}> = ({x, y, s, f}) => (
  <svg width={1080} height={1920} style={{position: 'absolute'}}>
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <path d="M0 0 C -10 -150, 10 -300, 30 -420" stroke="#6B4630" strokeWidth={34} fill="none" strokeLinecap="round" />
      {[-60, -30, -10].map((yy, i) => <path key={i} d={`M-14 ${yy * 5} q 20 -8 40 0`} stroke="#53351F" strokeWidth={6} fill="none" />)}
      <g transform={`rotate(${Math.sin(f * 0.05) * 2} 30 -420)`}>
        {[[-150, -360], [-170, -460], [-60, -540], [110, -540], [220, -460], [200, -360]].map(([ex, ey], i) => (
          <path key={i} d={`M30 -420 Q ${(30 + ex) / 2} ${ey - 70} ${ex} ${ey} Q ${(30 + ex) / 2 + 10} ${ey - 20} 30 -420`} fill={i % 2 ? '#3E8E5A' : '#4FA86A'} />
        ))}
        {[[-5, -395], [25, -385], [55, -395], [10, -365], [42, -362]].map(([dx, dy], i) => (
          <ellipse key={i} cx={dx} cy={dy} rx={14} ry={19} fill="#8A3E1C" />
        ))}
      </g>
    </g>
  </svg>
);

const DateFruit: React.FC<{x: number; y: number; r?: number}> = ({x, y, r = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${r})`}>
    <ellipse cx={0} cy={0} rx={13} ry={18} fill="#8A3E1C" />
    <ellipse cx={-4} cy={-6} rx={4} ry={6} fill="#B5643A" opacity={0.7} />
  </g>
);

const FallingDates: React.FC<{f: number; at: number; x: number; y: number}> = ({f, at, x, y}) => {
  const d = f - at;
  if (d < 0) return null;
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      {Array.from({length: 7}).map((_, i) => {
        const delay = i * 3;
        const t = Math.max(0, d - delay);
        const yy = Math.min(y + 4.5 * t * t * 0.5, 1120 + (i % 3) * 25);
        const xx = x - 90 + i * 32 + Math.sin(i) * 20;
        const landed = yy >= 1120 + (i % 3) * 25;
        const bounce = landed ? Math.abs(Math.sin((t - 12) * 0.5)) * Math.max(0, 1 - (t - 12) / 20) * 30 : 0;
        return <DateFruit key={i} x={xx} y={yy - bounce} r={t * 8 * (i % 2 ? 1 : -1)} />;
      })}
    </svg>
  );
};

const Basket: React.FC<{full: boolean; fill: number}> = ({full, fill}) => (
  <g>
    {full || fill > 0
      ? [[170, 300], [200, 292], [230, 300], [185, 285], [215, 283], [200, 272]].slice(0, full ? 6 : Math.round(fill * 6)).map(([x, y], i) => <DateFruit key={i} x={x} y={y} r={i * 25} />)
      : null}
    <path d="M130 300 L 270 300 L 250 380 L 150 380 Z" fill="#C98A4A" />
    <path d="M136 322 H 264 M142 344 H 258 M147 364 H 253" stroke="#A86E33" strokeWidth={6} />
    <path d="M160 300 L 165 380 M200 300 V 380 M240 300 L 235 380" stroke="#A86E33" strokeWidth={5} />
    <rect x={124} y={292} width={152} height={16} rx={8} fill="#B87A3C" />
  </g>
);

const Hearts: React.FC<{f: number; at: number}> = ({f, at}) => {
  const d = f - at;
  if (d < 0) return null;
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      {Array.from({length: 10}).map((_, i) => {
        const t = d - i * 4;
        if (t < 0) return null;
        const x = 140 + random(`hx${i}`) * 800 + Math.sin(t * 0.08 + i) * 25;
        const y = 1000 - t * 5 - random(`hy${i}`) * 100;
        const o = interpolate(t, [0, 8, 70, 90], [0, 1, 1, 0], {extrapolateRight: 'clamp'});
        const c = i % 3 === 0 ? '#FF7A9C' : i % 3 === 1 ? '#FFD45A' : '#FF9E6B';
        return (
          <path key={i} transform={`translate(${x} ${y}) scale(${1.2 + random(`hs${i}`)})`} opacity={o} fill={c}
            d="M0 10 C -18 -6, -10 -22, 0 -12 C 10 -22, 18 -6, 0 10 Z" />
        );
      })}
    </svg>
  );
};

const Sparkles: React.FC<{f: number}> = ({f}) => (
  <svg width={1080} height={1920} style={{position: 'absolute'}}>
    {Array.from({length: 12}).map((_, i) => {
      const x = random(`k${i}`) * 1000 + 40;
      const y = 300 + random(`l${i}`) * 800;
      const s = 0.5 + 0.5 * Math.abs(Math.sin(f * 0.1 + i * 1.7));
      return <path key={i} transform={`translate(${x} ${y}) scale(${s})`} d="M0 -18 L5 -5 L18 0 L5 5 L0 18 L-5 5 L-18 0 L-5 -5 Z" fill="#FFF7D6" opacity={0.85} />;
    })}
  </svg>
);

const Rumble: React.FC<{f: number; x: number; y: number}> = ({f, x, y}) => {
  const o = 0.5 + 0.5 * Math.sin(f * 0.4);
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      {[0, 1, 2].map((i) => (
        <path key={i} d={`M${x - 60 + i * 50} ${y - i * 18} q 10 -12 20 0 t 20 0`} stroke="#7A4A2A" strokeWidth={6} fill="none" strokeLinecap="round" opacity={o} />
      ))}
    </svg>
  );
};

const Badge: React.FC<{f: number; x: number; y: number; at: number}> = ({f, x, y, at}) => {
  const s = kf(f - at, [[0, 0], [8, 1.25, EASE.overshoot], [14, 1, EASE.out]]) * (1 + Math.sin(f * 0.3) * 0.04);
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <g transform={`translate(${x} ${y}) scale(${s}) rotate(${Math.sin(f * 0.2) * 6})`}>
        <circle r={70} fill="#FF5E5B" stroke="#fff" strokeWidth={10} />
        <rect x={-11} y={-44} width={22} height={58} rx={11} fill="#fff" />
        <circle cx={0} cy={34} r={12} fill="#fff" />
      </g>
    </svg>
  );
};

const Title: React.FC<{f: number; text: string; sub?: string; at: number}> = ({f, text, sub, at}) => {
  const s = kf(f - at, [[0, 0.6], [10, 1.08, EASE.overshoot], [18, 1, EASE.out]]);
  const o = interpolate(f - at, [0, 6], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', top: 330, left: 0, right: 0, textAlign: 'center', direction: 'rtl', opacity: o, scale: String(s)}}>
      <div style={{display: 'inline-block', background: '#FFE08A', borderRadius: 48, padding: '18px 56px', boxShadow: '0 12px 0 #E0A93B'}}>
        <div style={{fontFamily: 'Cairo', fontWeight: 800, fontSize: 96, color: '#3A2350', lineHeight: 1.3}}>{text}</div>
        {sub ? <div style={{fontFamily: 'Cairo', fontWeight: 800, fontSize: 58, color: '#7A4A2A', lineHeight: 1.2}}>{sub}</div> : null}
      </div>
    </div>
  );
};

/* ── actors ── */
const ActorView: React.FC<{a: Actor; f: number; fps: number; caps: Caption[]; speaking: boolean; dur: number}> = ({a, f, fps, caps, speaking, dur}) => {
  const at = a.enterOn ? onWord(caps, a.enterOn, fps, 0) - 6 : Math.round((a.enterAt ?? 0) * fps);
  const lf = f - at;
  const enter = a.enter ?? 'none';
  let dx = 0, dy = 0, sc = 1, rot = 0;
  if (enter === 'left' || enter === 'right') {
    const from = enter === 'left' ? -900 : 900;
    dx = kf(lf, [[0, from], [24, 0, EASE.out]]);
    if (lf < 26) dy = -Math.abs(Math.sin(lf * 0.45)) * 40;
  } else if (enter === 'fly') {
    dx = kf(lf, [[0, 700], [26, 0, EASE.out]]);
    dy = kf(lf, [[0, -600], [26, 0, EASE.out]]);
    rot = kf(lf, [[0, -20], [26, 0, EASE.out]]);
  } else if (enter === 'pop') {
    sc = kf(lf, [[0, 0], [10, 1.15, EASE.overshoot], [16, 1, EASE.out]]);
  }
  if (lf < 0 && enter !== 'none') return null;
  if (a.hop) dy += -Math.abs(Math.sin(f * 0.28)) * 22;
  const breathe = 1 + Math.sin(f * 0.09 + a.x) * 0.012;
  const switchAt = a.mood2On ? onWord(caps, a.mood2On, fps, dur) : dur;
  const mood: Mood = f >= switchAt && a.mood2 ? a.mood2 : a.mood ?? 'happy';
  const talk = speaking ? talkAt(caps, f, fps) : 0;
  const crestAt = a.crestOn ? onWord(caps, a.crestOn, fps, 0) : -1;
  const crest = a.crest ?? (crestAt >= 0 ? kf(f - crestAt, [[0, 0], [8, 1, EASE.overshoot]]) : 1);
  // squash on landing for entrances
  const land = enter !== 'none' && enter !== 'pop' ? kf(lf, [[24, 1], [28, 0.9, EASE.out], [34, 1, EASE.out]]) : 1;
  const fillAmt = a.basket === 'empty' ? Math.min(1, Math.max(0, (f - 15) / (dur - 30))) : 1;
  const eatBob = a.eat ? Math.abs(Math.sin(f * 0.25)) * 6 : 0;
  const s = a.s * sc;
  const flip = a.flip ? -1 : 1;
  return (
    <svg width={1080} height={1920} style={{position: 'absolute', overflow: 'visible'}}>
      <ellipse cx={a.x + dx} cy={a.y + 6} rx={120 * a.s} ry={18 * a.s} fill="#000" opacity={0.12} />
      <g transform={`translate(${a.x + dx} ${a.y + dy + eatBob}) rotate(${rot}) scale(${s * flip} ${s * breathe * land}) translate(-200 -390)`}>
        {a.who === 'suhail' && <Suhail f={f} talk={talk} mood={mood} look={a.look} />}
        {a.who === 'qamra' && <Qamra f={f} talk={talk} />}
        {a.who === 'jummul' && <Jummul f={f} talk={talk} mood={mood} extra={a.eat ? 1 : 0} />}
        {a.who === 'hudhud' && <Hudhud f={f} talk={talk} crest={crest} flap={a.flap || (enter === 'fly' && lf < 28) ? 1 : 0} />}
        {a.basket ? <g transform="translate(0 20)"><Basket full={a.basket === 'full'} fill={fillAmt} /></g> : null}
        {a.eat && a.who === 'suhail' ? <g transform={`translate(${200 - 200} ${-20 + eatBob})`}><DateFruit x={200} y={262} r={20} /></g> : null}
      </g>
    </svg>
  );
};

export const KidScene: React.FC<SceneProps> = ({scene, captions, durationInFrames}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sc = scene as unknown as {bg?: string; actors?: Actor[]; props?: Prop[]; cam?: {z0?: number; z1?: number; fx?: number; fy?: number}; speaker?: string; tint?: number};
  const cam = sc.cam ?? {};
  const z = interpolate(f, [0, durationInFrames], [cam.z0 ?? 1, cam.z1 ?? 1.06], {easing: EASE.smooth, extrapolateRight: 'clamp'});
  const props = sc.props ?? [];
  const before = props.filter((p) => p.type === 'palm');
  const after = props.filter((p) => p.type !== 'palm');
  return (
    <AbsoluteFill style={{overflow: 'hidden'}}>
      <AbsoluteFill style={{scale: String(z), transformOrigin: `${cam.fx ?? 540}px ${cam.fy ?? 900}px`}}>
        <Background kind={sc.bg ?? 'day'} f={f} />
        {before.map((p, i) => <Palm key={i} x={p.x ?? 250} y={p.y ?? 1100} s={p.s ?? 1} f={f} />)}
        {(sc.actors ?? []).map((a, i) => (
          <ActorView key={i} a={a} f={f} fps={fps} caps={captions} speaking={sc.speaker === a.who} dur={durationInFrames} />
        ))}
        {after.map((p, i) => {
          const at = onWord(captions, p.on, fps, 0);
          if (p.type === 'dates') return <FallingDates key={i} f={f} at={at} x={p.x ?? 300} y={p.y ?? 700} />;
          if (p.type === 'hearts') return <Hearts key={i} f={f} at={at} />;
          if (p.type === 'sparkles') return <Sparkles key={i} f={f} />;
          if (p.type === 'rumble') return <Rumble key={i} f={f} x={p.x ?? 300} y={p.y ?? 950} />;
          if (p.type === 'badge') return <Badge key={i} f={f} x={p.x ?? 800} y={p.y ?? 560} at={at} />;
          if (p.type === 'title') return <Title key={i} f={f} text={p.text ?? ''} sub={p.sub} at={at} />;
          return null;
        })}
      </AbsoluteFill>
      {sc.tint ? <AbsoluteFill style={{background: '#4A4A6A', opacity: sc.tint * interpolate(f, [0, 20], [0, 1], {extrapolateRight: 'clamp'}), mixBlendMode: 'multiply'}} /> : null}
    </AbsoluteFill>
  );
};

export const KIDS_SCENES = {kid: KidScene};
