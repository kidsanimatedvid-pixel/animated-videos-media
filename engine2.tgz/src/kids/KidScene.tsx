import React from 'react';
import type {Caption} from '@remotion/captions';
import {AbsoluteFill, interpolate, random, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {EASE, kf} from '../components/Motion';
import {Arnab, Batta, Ghurab, Hudhud, Jummul, Qamra, Suhail, Sulahfa, type Mood} from './Cast';

/* One data-driven scene for the kids channel. A storyboard scene sets:
   bg: 'day' | 'dusk' | 'night'
   actors: [{who, x, y, s, flip?, enter?, enterAt?, mood?, mood2?, mood2On?, basket?, hop?, eat?, crest?, crestOn?, flap?}]
   props: [{type: 'palm'|'dates'|'rumble'|'hearts'|'badge'|'title'|'sparkles', ...}]
   cam: {z0, z1, fx, fy}; captionTop.
   The actor whose `who` equals scene.speaker moves its mouth on every spoken word. */

type Actor = {
  who: 'suhail' | 'qamra' | 'jummul' | 'hudhud' | 'arnab' | 'sulahfa' | 'batta' | 'ghurab';
  x: number; y: number; s: number; flip?: boolean;
  enter?: 'left' | 'right' | 'fly' | 'pop' | 'none'; enterAt?: number; enterOn?: string;
  mood?: Mood; mood2?: Mood; mood2On?: string;
  basket?: 'empty' | 'full'; hop?: boolean; eat?: boolean; crest?: number; crestOn?: string; flap?: boolean; look?: number;
  /* turtle: upside = starts on its back, flipOn = rolls upright on that word; hide / hideOn / unhideOn = into the shell; paddle = flippers row */
  upside?: boolean; flipOn?: string; hide?: boolean; hideOn?: string; unhideOn?: string; paddle?: boolean;
  /* drift: move (dx, dy) and grow/shrink (ds) from word `on` (or scene start) to scene end */
  drift?: {dx?: number; dy?: number; ds?: number; on?: string};
  waddle?: boolean;
  /* story #4: mouthDate = Suhail holds a date in his mouth, dropOn = it falls to the ground on that word; openOn = mouth opens wide (singing) from that word; beakDate = crow holds a date */
  mouthDate?: boolean; dropOn?: string; openOn?: string; beakDate?: boolean;
};
type Prop = {type: string; x?: number; y?: number; s?: number; on?: string; text?: string; sub?: string; color?: string; count?: number; off?: string; items?: string[]; answer?: number};

const clean = (w: string) => w.replace(/[^\p{L}\p{N}]/gu, '');
const onWord = (caps: Caption[], word: string | undefined, fps: number, fallback = 0) => {
  if (!word) return fallback;
  const c = caps.find((c) => clean(c.text).startsWith(clean(word)));
  return c ? Math.round((c.startMs / 1000) * fps) : fallback;
};
const talkAt = (caps: Caption[], f: number, fps: number) => {
  const ms = (f / fps) * 1000;
  const w = caps.find((c) => ms >= c.startMs - 30 && ms < c.endMs - 40);
  return w ? 0.35 + 0.65 * Math.abs(Math.sin(f * 0.55)) : 0;
};

/* ── backgrounds ── */
const SKY: Record<string, [string, string, string]> = {
  day: ['#7FCBFF', '#BDE6FF', '#FFE9BF'],
  dusk: ['#5B5AA8', '#C98BB9', '#FFC59A'],
  night: ['#1E2257', '#38407F', '#6A5D9A'],
};
const Beach: React.FC<{night: boolean; f: number}> = ({night, f}) => {
  const [a, b, c] = night ? SKY.night : ['#7FCBFF', '#BDE6FF', '#DFF4FF'];
  const sea1 = night ? '#2C4F8A' : '#3FA9D8';
  const sea2 = night ? '#3A63A0' : '#5CC3E6';
  const sand = night ? '#7A6A86' : '#F7D9A0';
  const sand2 = night ? '#6A5A78' : '#F0CB88';
  const foam = 8 * Math.sin(f * 0.06);
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <defs>
        <linearGradient id={`sky-beach-${night}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={a} /><stop offset="0.6" stopColor={b} /><stop offset="1" stopColor={c} />
        </linearGradient>
      </defs>
      <rect width={1080} height={1920} fill={`url(#sky-beach-${night})`} />
      {night
        ? Array.from({length: 40}).map((_, i) => (
            <circle key={i} cx={random(`sx${i}`) * 1080} cy={random(`sy${i}`) * 760} r={2 + random(`sr${i}`) * 3}
              fill="#FFF7D6" opacity={0.4 + 0.6 * Math.abs(Math.sin(f * 0.05 + i))} />
          ))
        : (
          <>
            <circle cx={860} cy={320} r={90} fill="#FFE27A" opacity={0.9} />
            {[0, 1].map((i) => {
              const x = ((i * 600 + f * (0.6 + i * 0.2)) % 1500) - 250;
              return (
                <g key={i} transform={`translate(${x} ${220 + i * 160})`} opacity={0.9}>
                  <ellipse cx={0} cy={0} rx={90} ry={34} fill="#fff" /><ellipse cx={60} cy={-18} rx={60} ry={34} fill="#fff" /><ellipse cx={-55} cy={-8} rx={50} ry={26} fill="#fff" />
                </g>
              );
            })}
          </>
        )}
      <rect x={0} y={840} width={1080} height={260} fill={sea1} />
      <rect x={0} y={840} width={1080} height={40} fill={sea2} />
      {[0, 1, 2, 3].map((i) => (
        <path key={i} d={`M${((i * 300 + f * 1.2) % 1300) - 200} ${900 + (i % 2) * 70} q 30 -16 60 0 t 60 0`} stroke="#fff" strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.6} />
      ))}
      {/* a small dhow on the horizon */}
      <g transform={`translate(${180 + Math.sin(f * 0.03) * 10} 850)`} opacity={night ? 0.5 : 0.85}>
        <path d="M-60 0 Q 0 26 70 0 Z" fill="#8A5A34" />
        <path d="M0 -4 V -90 L 50 -10 Z" fill="#FFF7E6" />
      </g>
      <path d={`M0 ${1010 + foam} C 260 ${985 - foam}, 560 ${1035 + foam}, 1080 ${995 - foam} L1080 1920 L0 1920Z`} fill="#FFFFFF" opacity={0.85} />
      <path d={`M0 ${1030 + foam} C 300 ${1005 - foam}, 640 ${1055 + foam}, 1080 ${1015 - foam} L1080 1920 L0 1920Z`} fill={sand} />
      <path d="M0 1260 C 350 1220, 700 1290, 1080 1250 L1080 1920 L0 1920Z" fill={sand2} />
      {Array.from({length: 10}).map((_, i) => (
        <ellipse key={i} cx={random(`bp${i}`) * 1080} cy={1240 + random(`bq${i}`) * 450} rx={8 + random(`br${i}`) * 10} ry={3} fill="#000" opacity={0.06} />
      ))}
      {[[140, 1500, '#FF9E6B'], [930, 1580, '#FFC2D1']].map(([x, y, col], i) => (
        <path key={i} transform={`translate(${x} ${y})`} d="M-26 0 Q -20 -30 0 -32 Q 20 -30 26 0 Z M-26 0 h 52" fill={col as string} stroke="#E07A5A" strokeWidth={3} opacity={night ? 0.6 : 1} />
      ))}
    </svg>
  );
};

const Background: React.FC<{kind: string; f: number}> = ({kind, f}) => {
  if (kind === 'beach' || kind === 'beachNight') return <Beach night={kind === 'beachNight'} f={f} />;
  const [a, b, c] = SKY[kind] ?? SKY.day;
  const night = kind === 'night';
  const sand1 = night ? '#6E5A7E' : kind === 'dusk' ? '#E39A6A' : '#F2C27A';
  const sand2 = night ? '#58486A' : kind === 'dusk' ? '#D9875A' : '#E9AE62';
  const sand3 = night ? '#4A3C5C' : kind === 'dusk' ? '#CC7A50' : '#E0A055';
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <defs>
        <linearGradient id={`sky-${kind}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={a} /><stop offset="0.55" stopColor={b} /><stop offset="1" stopColor={c} />
        </linearGradient>
      </defs>
      <rect width={1080} height={1920} fill={`url(#sky-${kind})`} />
      {night
        ? Array.from({length: 40}).map((_, i) => (
            <circle key={i} cx={random(`sx${i}`) * 1080} cy={random(`sy${i}`) * 900} r={2 + random(`sr${i}`) * 3}
              fill="#FFF7D6" opacity={0.4 + 0.6 * Math.abs(Math.sin(f * 0.05 + i))} />
          ))
        : (
          <>
            <circle cx={860} cy={300} r={kind === 'dusk' ? 110 : 90} fill={kind === 'dusk' ? '#FFB37A' : '#FFE27A'} opacity={0.9} />
            {[0, 1, 2].map((i) => {
              const x = ((i * 420 + f * (0.6 + i * 0.2)) % 1500) - 250;
              return (
                <g key={i} transform={`translate(${x} ${200 + i * 140})`} opacity={kind === 'dusk' ? 0.55 : 0.9}>
                  <ellipse cx={0} cy={0} rx={90} ry={34} fill="#fff" /><ellipse cx={60} cy={-18} rx={60} ry={34} fill="#fff" /><ellipse cx={-55} cy={-8} rx={50} ry={26} fill="#fff" />
                </g>
              );
            })}
          </>
        )}
      <path d="M0 960 C 250 880, 520 990, 780 930 C 900 905, 1000 930, 1080 920 L1080 1920 L0 1920Z" fill={sand1} />
      <path d="M0 1060 C 300 1000, 640 1090, 1080 1030 L1080 1920 L0 1920Z" fill={sand2} />
      <path d="M0 1180 C 350 1130, 700 1200, 1080 1160 L1080 1920 L0 1920Z" fill={sand3} />
      {Array.from({length: 14}).map((_, i) => (
        <ellipse key={i} cx={random(`p${i}`) * 1080} cy={1200 + random(`q${i}`) * 500} rx={8 + random(`r${i}`) * 10} ry={3} fill="#000" opacity={0.06} />
      ))}
    </svg>
  );
};

/* ── props ── */
const Palm: React.FC<{x: number; y: number; s: number; f: number}> = ({x, y, s, f}) => (
  <svg width={1080} height={1920} style={{position: 'absolute'}}>
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <path d="M0 0 C -10 -150, 10 -300, 30 -420" stroke="#6B4630" strokeWidth={34} fill="none" strokeLinecap="round" />
      {[-60, -30, -10].map((yy, i) => <path key={i} d={`M-14 ${yy * 5} q 20 -8 40 0`} stroke="#53351F" strokeWidth={6} fill="none" />)}
      <g transform={`rotate(${Math.sin(f * 0.05) * 2} 30 -420)`}>
        {[[-150, -360], [-170, -460], [-60, -540], [110, -540], [220, -460], [200, -360]].map(([ex, ey], i) => (
          <path key={i} d={`M30 -420 Q ${(30 + ex) / 2} ${ey - 70} ${ex} ${ey} Q ${(30 + ex) / 2 + 10} ${ey - 20} 30 -420`} fill={i % 2 ? '#3E8E5A' : '#4FA86A'} />
        ))}
        {[[-5, -395], [25, -385], [55, -395], [10, -365], [42, -362]].map(([dx, dy], i) => (
          <ellipse key={i} cx={dx} cy={dy} rx={14} ry={19} fill="#8A3E1C" />
        ))}
      </g>
    </g>
  </svg>
);

const DateFruit: React.FC<{x: number; y: number; r?: number}> = ({x, y, r = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${r})`}>
    <ellipse cx={0} cy={0} rx={13} ry={18} fill="#8A3E1C" />
    <ellipse cx={-4} cy={-6} rx={4} ry={6} fill="#B5643A" opacity={0.7} />
  </g>
);

const FallingDates: React.FC<{f: number; at: number; x: number; y: number}> = ({f, at, x, y}) => {
  const d = f - at;
  if (d < 0) return null;
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      {Array.from({length: 7}).map((_, i) => {
        const delay = i * 3;
        const t = Math.max(0, d - delay);
        const yy = Math.min(y + 4.5 * t * t * 0.5, 1120 + (i % 3) * 25);
        const xx = x - 90 + i * 32 + Math.sin(i) * 20;
        const landed = yy >= 1120 + (i % 3) * 25;
        const bounce = landed ? Math.abs(Math.sin((t - 12) * 0.5)) * Math.max(0, 1 - (t - 12) / 20) * 30 : 0;
        return <DateFruit key={i} x={xx} y={yy - bounce} r={t * 8 * (i % 2 ? 1 : -1)} />;
      })}
    </svg>
  );
};

const Basket: React.FC<{full: boolean; fill: number}> = ({full, fill}) => (
  <g>
    {full || fill > 0
      ? [[170, 300], [200, 292], [230, 300], [185, 285], [215, 283], [200, 272]].slice(0, full ? 6 : Math.round(fill * 6)).map(([x, y], i) => <DateFruit key={i} x={x} y={y} r={i * 25} />)
      : null}
    <path d="M130 300 L 270 300 L 250 380 L 150 380 Z" fill="#C98A4A" />
    <path d="M136 322 H 264 M142 344 H 258 M147 364 H 253" stroke="#A86E33" strokeWidth={6} />
    <path d="M160 300 L 165 380 M200 300 V 380 M240 300 L 235 380" stroke="#A86E33" strokeWidth={5} />
    <rect x={124} y={292} width={152} height={16} rx={8} fill="#B87A3C" />
  </g>
);

const Hearts: React.FC<{f: number; at: number}> = ({f, at}) => {
  const d = f - at;
  if (d < 0) return null;
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      {Array.from({length: 10}).map((_, i) => {
        const t = d - i * 4;
        if (t < 0) return null;
        const x = 140 + random(`hx${i}`) * 800 + Math.sin(t * 0.08 + i) * 25;
        const y = 1000 - t * 5 - random(`hy${i}`) * 100;
        const o = interpolate(t, [0, 8, 70, 90], [0, 1, 1, 0], {extrapolateRight: 'clamp'});
        const c = i % 3 === 0 ? '#FF7A9C' : i % 3 === 1 ? '#FFD45A' : '#FF9E6B';
        return (
          <path key={i} transform={`translate(${x} ${y}) scale(${1.2 + random(`hs${i}`)})`} opacity={o} fill={c}
            d="M0 10 C -18 -6, -10 -22, 0 -12 C 10 -22, 18 -6, 0 10 Z" />
        );
      })}
    </svg>
  );
};

const Sparkles: React.FC<{f: number}> = ({f}) => (
  <svg width={1080} height={1920} style={{position: 'absolute'}}>
    {Array.from({length: 12}).map((_, i) => {
      const x = random(`k${i}`) * 1000 + 40;
      const y = 300 + random(`l${i}`) * 800;
      const s = 0.5 + 0.5 * Math.abs(Math.sin(f * 0.1 + i * 1.7));
      return <path key={i} transform={`translate(${x} ${y}) scale(${s})`} d="M0 -18 L5 -5 L18 0 L5 5 L0 18 L-5 5 L-18 0 L-5 -5 Z" fill="#FFF7D6" opacity={0.85} />;
    })}
  </svg>
);

const Rumble: React.FC<{f: number; x: number; y: number; color?: string}> = ({f, x, y, color = '#7A4A2A'}) => {
  const o = 0.5 + 0.5 * Math.sin(f * 0.4);
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      {[0, 1, 2].map((i) => (
        <path key={i} d={`M${x - 60 + i * 50} ${y - i * 18} q 10 -12 20 0 t 20 0`} stroke={color} strokeWidth={6} fill="none" strokeLinecap="round" opacity={o} />
      ))}
    </svg>
  );
};

const Badge: React.FC<{f: number; x: number; y: number; at: number}> = ({f, x, y, at}) => {
  const s = kf(f - at, [[0, 0], [8, 1.25, EASE.overshoot], [14, 1, EASE.out]]) * (1 + Math.sin(f * 0.3) * 0.04);
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <g transform={`translate(${x} ${y}) scale(${s}) rotate(${Math.sin(f * 0.2) * 6})`}>
        <circle r={70} fill="#FF5E5B" stroke="#fff" strokeWidth={10} />
        <rect x={-11} y={-44} width={22} height={58} rx={11} fill="#fff" />
        <circle cx={0} cy={34} r={12} fill="#fff" />
      </g>
    </svg>
  );
};

const Title: React.FC<{f: number; text: string; sub?: string; at: number}> = ({f, text, sub, at}) => {
  const s = kf(f - at, [[0, 0.6], [10, 1.08, EASE.overshoot], [18, 1, EASE.out]]);
  const o = interpolate(f - at, [0, 6], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', top: 330, left: 0, right: 0, textAlign: 'center', direction: 'rtl', opacity: o, scale: String(s)}}>
      <div style={{display: 'inline-block', background: '#FFE08A', borderRadius: 48, padding: '18px 56px', boxShadow: '0 12px 0 #E0A93B'}}>
        <div style={{fontFamily: 'Cairo', fontWeight: 800, fontSize: 96, color: '#3A2350', lineHeight: 1.3}}>{text}</div>
        {sub ? <div style={{fontFamily: 'Cairo', fontWeight: 800, fontSize: 58, color: '#7A4A2A', lineHeight: 1.2}}>{sub}</div> : null}
      </div>
    </div>
  );
};

/* Plate of dates: {type:'plate', x, y, count:3, off:'word'} — dates vanish one by one from the word `off` */
const Plate: React.FC<{f: number; x: number; y: number; count: number; offAt: number}> = ({f, x, y, count, offAt}) => (
  <svg width={1080} height={1920} style={{position: 'absolute'}}>
    <g transform={`translate(${x} ${y})`}>
      <ellipse cx={0} cy={10} rx={130} ry={30} fill="#000" opacity={0.1} />
      <ellipse cx={0} cy={0} rx={125} ry={34} fill="#FFFFFF" />
      <ellipse cx={0} cy={-4} rx={95} ry={22} fill="#EAF6FF" />
      {Array.from({length: count}).map((_, i) => {
        const gone = offAt >= 0 && f >= offAt + i * 6;
        const o = gone ? Math.max(0, 1 - (f - offAt - i * 6) / 6) : 1;
        return <g key={i} opacity={o}><DateFruit x={(i - (count - 1) / 2) * 44} y={-14} r={70 + i * 20} /></g>;
      })}
    </g>
  </svg>
);

/* Ants marching right along the ground, every second one carrying a date */
const Ants: React.FC<{f: number; at: number; y: number}> = ({f, at, y}) => {
  const d = f - at;
  if (d < 0) return null;
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      {Array.from({length: 7}).map((_, i) => {
        const x = 80 + d * 5 - i * 95;
        if (x < -60 || x > 1140) return null;
        const step = Math.sin(d * 0.9 + i) * 4;
        return (
          <g key={i} transform={`translate(${x} ${y + (i % 2) * 14}) scale(1.3)`}>
            {[-16, 0, 16].map((lx, k) => <path key={k} d={`M${lx} 4 l ${-6 + (k % 2 ? step : -step)} 14`} stroke="#2B1B12" strokeWidth={4} strokeLinecap="round" />)}
            <circle cx={-20} cy={0} r={11} fill="#3A2A20" /><circle cx={0} cy={-2} r={9} fill="#3A2A20" /><circle cx={18} cy={-4} r={11} fill="#3A2A20" />
            <circle cx={23} cy={-8} r={3} fill="#fff" />
            <path d="M24 -14 q 8 -12 16 -10 M18 -14 q 4 -14 12 -16" stroke="#3A2A20" strokeWidth={3} fill="none" />
            {i % 2 === 0 ? <DateFruit x={0} y={-30} r={80} /> : null}
          </g>
        );
      })}
    </svg>
  );
};

/* Answer cards for LEARN checks: {type:'choices', items:['ب','أ','ت'], answer:1, on:'word' (reveal)} */
const Choices: React.FC<{f: number; items: string[]; answer: number; at: number; y: number}> = ({f, items, answer, at, y}) => {
  const n = items.length;
  return (
    <div style={{position: 'absolute', top: y, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 40, direction: 'rtl'}}>
      {items.map((t, i) => {
        const pop = kf(f - i * 5, [[0, 0], [8, 1.1, EASE.overshoot], [14, 1, EASE.out]]);
        const rev = at >= 0 && f >= at;
        const k = rev ? kf(f - at, [[0, 0], [10, 1, EASE.overshoot]]) : 0;
        const right = i === answer;
        const scale = pop * (right ? 1 + 0.25 * k : 1 - 0.15 * k);
        const bg = right && rev ? '#3CC47C' : '#FFFFFF';
        return (
          <div key={i} style={{width: 220, height: 260, borderRadius: 40, background: bg, border: '10px solid #3A2350', display: 'flex', alignItems: 'center', justifyContent: 'center',
            scale: String(scale), opacity: right || !rev ? 1 : 1 - 0.5 * k, boxShadow: '0 12px 0 rgba(0,0,0,0.18)'}}>
            <span style={{fontFamily: 'Cairo', fontWeight: 800, fontSize: 170, color: right && rev ? '#fff' : '#3A2350', lineHeight: 1}}>{t}</span>
          </div>
        );
      })}
      {n === 0 ? null : null}
    </div>
  );
};

/* Big letter / number / word card for LEARN videos: {type:'bigtext', text:'بـ', sub:'بَطَّة', on:'word', y:420, color:'#FF7A9C'} */
const BigText: React.FC<{f: number; text: string; sub?: string; at: number; y: number; color?: string}> = ({f, text, sub, at, y, color = '#FF7A9C'}) => {
  const s = kf(f - at, [[0, 0], [10, 1.15, EASE.overshoot], [18, 1, EASE.out]]) * (1 + Math.sin(f * 0.15) * 0.02);
  if (f < at) return null;
  return (
    <div style={{position: 'absolute', top: y, left: 0, right: 0, textAlign: 'center', direction: 'rtl', scale: String(s)}}>
      <div style={{display: 'inline-block', background: '#FFFFFF', borderRadius: 60, padding: '10px 70px 24px', boxShadow: `0 14px 0 ${color}`, border: `10px solid ${color}`}}>
        <div style={{fontFamily: 'Cairo', fontWeight: 800, fontSize: 260, color, lineHeight: 1.25}}>{text}</div>
        {sub ? <div style={{fontFamily: 'Cairo', fontWeight: 800, fontSize: 90, color: '#3A2350', lineHeight: 1.2}}>{sub}</div> : null}
      </div>
    </div>
  );
};

/* Oasis pond: {type:'pond', x, y, s} — drawn behind the actors */
const Pond: React.FC<{f: number; x: number; y: number; s: number}> = ({f, x, y, s}) => (
  <svg width={1080} height={1920} style={{position: 'absolute'}}>
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <ellipse cx={0} cy={6} rx={300} ry={70} fill="#C99A55" opacity={0.5} />
      <ellipse cx={0} cy={0} rx={285} ry={60} fill="#4FB7E0" />
      <ellipse cx={0} cy={-8} rx={240} ry={40} fill="#79CDEB" />
      {[0, 1, 2].map((i) => {
        const r = ((f * 1.2 + i * 40) % 120);
        return <ellipse key={i} cx={-60 + i * 70} cy={-4} rx={r} ry={r * 0.22} stroke="#fff" strokeWidth={4} fill="none" opacity={Math.max(0, 0.6 - r / 200)} />;
      })}
      {[-250, 240].map((ex, i) => (
        <g key={i} transform={`translate(${ex} -20)`}>
          {[-14, 0, 14].map((k) => <path key={k} d={`M${k} 20 Q ${k * 2} -30 ${k * 3} -60`} stroke="#4FA86A" strokeWidth={8} fill="none" strokeLinecap="round" />)}
        </g>
      ))}
    </g>
  </svg>
);

/* Apple (letter ت — تُفَّاحَة): {type:'apple', x, y, s, on:'word'} pops in on the word, then sways */
const Apple: React.FC<{f: number; x: number; y: number; s: number; at: number}> = ({f, x, y, s, at}) => {
  if (f < at) return null;
  const k = kf(f - at, [[0, 0], [10, 1.15, EASE.overshoot], [16, 1, EASE.out]]);
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <g transform={`translate(${x} ${y}) scale(${s * k}) rotate(${Math.sin(f * 0.2) * 5})`}>
        <ellipse cx={0} cy={8} rx={80} ry={16} fill="#000" opacity={0.12} />
        <path d="M0 -112 C 30 -140, 95 -130, 95 -60 C 95 -10, 50 10, 25 4 C 12 0, -12 0, -25 4 C -50 10, -95 -10, -95 -60 C -95 -130, -30 -140, 0 -112 Z" fill="#E8453C" />
        <path d="M-30 -110 C -60 -110, -75 -85, -72 -60" stroke="#FF8A80" strokeWidth={14} fill="none" strokeLinecap="round" opacity={0.8} />
        <path d="M0 -112 C 2 -135, 8 -150, 16 -160" stroke="#7A4A2A" strokeWidth={9} fill="none" strokeLinecap="round" />
        <path d="M12 -146 C 30 -175, 70 -170, 78 -150 C 55 -135, 30 -135, 12 -146 Z" fill="#4FA86A" />
      </g>
    </svg>
  );
};

/* Egg: {type:'egg', x, y, s, on:'word'} pops in on the word, then wobbles */
const Egg: React.FC<{f: number; x: number; y: number; s: number; at: number}> = ({f, x, y, s, at}) => {
  if (f < at) return null;
  const k = kf(f - at, [[0, 0], [10, 1.15, EASE.overshoot], [16, 1, EASE.out]]);
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <g transform={`translate(${x} ${y}) scale(${s * k}) rotate(${Math.sin(f * 0.25) * 6})`}>
        <ellipse cx={0} cy={8} rx={70} ry={16} fill="#000" opacity={0.12} />
        <path d="M0 -150 C 50 -150, 80 -75, 80 -40 C 80 -5, 45 10, 0 10 C -45 10, -80 -5, -80 -40 C -80 -75, -50 -150, 0 -150 Z" fill="#FFF8EC" stroke="#E8D9BF" strokeWidth={5} />
        <ellipse cx={-30} cy={-80} rx={13} ry={24} fill="#fff" opacity={0.9} />
        {[[20, -60], [35, -30], [-10, -30]].map(([dx, dy], i) => <circle key={i} cx={dx} cy={dy} r={5} fill="#E8D9BF" />)}
      </g>
    </svg>
  );
};

/* Music notes floating up from (x, y) from the word `on`: {type:'notes', x, y, on} */
const Notes: React.FC<{f: number; at: number; x: number; y: number}> = ({f, at, x, y}) => {
  const d = f - at;
  if (d < 0) return null;
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      {[0, 1, 2].map((i) => {
        const t = d - i * 9;
        if (t < 0) return null;
        const yy = y - t * 3.2;
        const xx = x + i * 46 + Math.sin(t * 0.15 + i) * 22;
        const o = Math.max(0, Math.min(1, t / 6) * (1 - t / 55));
        const c = ['#FF7A9C', '#3FA9D8', '#F2B320'][i];
        return (
          <g key={i} transform={`translate(${xx} ${yy}) rotate(${Math.sin(t * 0.2) * 12})`} opacity={o}>
            <ellipse cx={0} cy={0} rx={17} ry={13} fill={c} transform="rotate(-20)" />
            <rect x={12} y={-62} width={7} height={62} rx={3} fill={c} />
            <path d="M15 -62 q 26 10 22 34 q -6 -16 -22 -16 z" fill={c} />
          </g>
        );
      })}
    </svg>
  );
};

/* ── actors ── */
const ActorView: React.FC<{a: Actor; f: number; fps: number; caps: Caption[]; speaking: boolean; dur: number}> = ({a, f, fps, caps, speaking, dur}) => {
  const at = a.enterOn ? onWord(caps, a.enterOn, fps, 0) - 6 : Math.round((a.enterAt ?? 0) * fps);
  const lf = f - at;
  const enter = a.enter ?? 'none';
  let dx = 0, dy = 0, sc = 1, rot = 0;
  if (enter === 'left' || enter === 'right') {
    const from = enter === 'left' ? -900 : 900;
    dx = kf(lf, [[0, from], [24, 0, EASE.out]]);
    if (lf < 26) dy = -Math.abs(Math.sin(lf * 0.45)) * 40;
  } else if (enter === 'fly') {
    dx = kf(lf, [[0, 700], [26, 0, EASE.out]]);
    dy = kf(lf, [[0, -600], [26, 0, EASE.out]]);
    rot = kf(lf, [[0, -20], [26, 0, EASE.out]]);
  } else if (enter === 'pop') {
    sc = kf(lf, [[0, 0], [10, 1.15, EASE.overshoot], [16, 1, EASE.out]]);
  }
  if (lf < 0 && enter !== 'none') return null;
  if (a.hop) dy += -Math.abs(Math.sin(f * 0.28)) * 22;
  let ds = 0;
  if (a.drift) {
    const d0 = a.drift.on ? onWord(caps, a.drift.on, fps, 0) : 0;
    const t = interpolate(f, [d0, dur], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.smooth});
    dx += (a.drift.dx ?? 0) * t; dy += (a.drift.dy ?? 0) * t; ds = (a.drift.ds ?? 0) * t;
  }
  if (a.waddle) rot += Math.sin(f * 0.3) * 4;
  const flipAt = a.flipOn ? onWord(caps, a.flipOn, fps, dur) : dur;
  const upside = a.upside ? 1 - kf(f - flipAt, [[0, 0], [18, 1, EASE.smooth]]) : 0;
  const hideAt = a.hideOn ? onWord(caps, a.hideOn, fps, dur) : dur;
  const unhideAt = a.unhideOn ? onWord(caps, a.unhideOn, fps, dur) : dur;
  let hide = a.hide ? 1 : 0;
  if (a.hideOn && f >= hideAt) hide = kf(f - hideAt, [[0, 0], [8, 1, EASE.out]]);
  if (a.unhideOn && f >= unhideAt) hide = 1 - kf(f - unhideAt, [[0, 0], [12, 1, EASE.out]]);
  const breathe = 1 + Math.sin(f * 0.09 + a.x) * 0.012;
  const switchAt = a.mood2On ? onWord(caps, a.mood2On, fps, dur) : dur;
  const mood: Mood = f >= switchAt && a.mood2 ? a.mood2 : a.mood ?? 'happy';
  const openAt = a.openOn ? onWord(caps, a.openOn, fps, dur) : dur;
  const talk = f >= openAt ? 0.75 + 0.2 * Math.sin(f * 0.3) : speaking ? talkAt(caps, f, fps) : 0;
  const dropAt = a.dropOn ? onWord(caps, a.dropOn, fps, dur) + 4 : dur;
  const dt = Math.max(0, f - dropAt);
  const dropY = Math.min(dt * dt * 0.9, 125);
  const dropBounce = dropY >= 125 ? Math.abs(Math.sin((dt - 12) * 0.5)) * Math.max(0, 1 - (dt - 12) / 16) * 18 : 0;
  const crestAt = a.crestOn ? onWord(caps, a.crestOn, fps, 0) : -1;
  const crest = a.crest ?? (crestAt >= 0 ? kf(f - crestAt, [[0, 0], [8, 1, EASE.overshoot]]) : 1);
  // squash on landing for entrances
  const land = enter !== 'none' && enter !== 'pop' ? kf(lf, [[24, 1], [28, 0.9, EASE.out], [34, 1, EASE.out]]) : 1;
  const fillAmt = a.basket === 'empty' ? Math.min(1, Math.max(0, (f - 15) / (dur - 30))) : 1;
  const eatBob = a.eat ? Math.abs(Math.sin(f * 0.25)) * 6 : 0;
  const s = (a.s + ds) * sc;
  const flip = a.flip ? -1 : 1;
  return (
    <svg width={1080} height={1920} style={{position: 'absolute', overflow: 'visible'}}>
      <ellipse cx={a.x + dx} cy={a.y + 6 + dy * (a.drift ? 1 : 0)} rx={120 * (a.s + ds)} ry={18 * a.s} fill="#000" opacity={0.12} />
      <g transform={`translate(${a.x + dx} ${a.y + dy + eatBob}) rotate(${rot}) scale(${s * flip} ${s * breathe * land}) translate(-200 -390)`}>
        {a.who === 'suhail' && <Suhail f={f} talk={talk} mood={mood} look={a.look} />}
        {a.who === 'qamra' && <Qamra f={f} talk={talk} />}
        {a.who === 'jummul' && <Jummul f={f} talk={talk} mood={mood} extra={a.eat ? 1 : 0} />}
        {a.who === 'arnab' && <Arnab f={f} talk={talk} />}
        {a.who === 'sulahfa' && <Sulahfa f={f} talk={talk} upside={upside} hide={hide} paddle={a.paddle ? 1 : 0} />}
        {a.who === 'batta' && <Batta f={f} talk={talk} />}
        {a.who === 'ghurab' && <Ghurab f={f} talk={talk} flap={a.flap || (enter === 'fly' && lf < 28) || (a.drift && f > 0) ? 1 : 0} beakDate={a.beakDate ? 1 : 0} />}
        {a.who === 'hudhud' && <Hudhud f={f} talk={talk} crest={crest} flap={a.flap || (enter === 'fly' && lf < 28) ? 1 : 0} />}
        {a.basket ? <g transform="translate(0 20)"><Basket full={a.basket === 'full'} fill={fillAmt} /></g> : null}
        {a.mouthDate ? <g transform={`translate(${200 + dt * 1.2} ${262 + dropY - dropBounce}) scale(1.7)`}><DateFruit x={0} y={0} r={90 + dt * 10} /></g> : null}
        {a.eat && a.who === 'suhail' ? <g transform={`translate(${200 - 200} ${-20 + eatBob})`}><DateFruit x={200} y={262} r={20} /></g> : null}
      </g>
    </svg>
  );
};

export const KidScene: React.FC<SceneProps> = ({scene, captions, durationInFrames}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sc = scene as unknown as {bg?: string; actors?: Actor[]; props?: Prop[]; cam?: {z0?: number; z1?: number; fx?: number; fy?: number}; speaker?: string; tint?: number};
  const cam = sc.cam ?? {};
  const z = interpolate(f, [0, durationInFrames], [cam.z0 ?? 1, cam.z1 ?? 1.06], {easing: EASE.smooth, extrapolateRight: 'clamp'});
  const props = sc.props ?? [];
  const before = props.filter((p) => p.type === 'palm' || p.type === 'pond');
  const after = props.filter((p) => p.type !== 'palm' && p.type !== 'pond');
  return (
    <AbsoluteFill style={{overflow: 'hidden'}}>
      <AbsoluteFill style={{scale: String(z), transformOrigin: `${cam.fx ?? 540}px ${cam.fy ?? 900}px`}}>
        <Background kind={sc.bg ?? 'day'} f={f} />
        {before.map((p, i) => p.type === 'pond'
          ? <Pond key={i} f={f} x={p.x ?? 540} y={p.y ?? 1180} s={p.s ?? 1} />
          : <Palm key={i} x={p.x ?? 250} y={p.y ?? 1100} s={p.s ?? 1} f={f} />)}
        {(sc.actors ?? []).map((a, i) => (
          <ActorView key={i} a={a} f={f} fps={fps} caps={captions} speaking={sc.speaker === a.who} dur={durationInFrames} />
        ))}
        {after.map((p, i) => {
          const at = onWord(captions, p.on, fps, 0);
          if (p.type === 'dates') return <FallingDates key={i} f={f} at={at} x={p.x ?? 300} y={p.y ?? 700} />;
          if (p.type === 'hearts') return <Hearts key={i} f={f} at={at} />;
          if (p.type === 'sparkles') return <Sparkles key={i} f={f} />;
          if (p.type === 'rumble') return <Rumble key={i} f={f} x={p.x ?? 300} y={p.y ?? 950} color={p.color} />;
          if (p.type === 'badge') return <Badge key={i} f={f} x={p.x ?? 800} y={p.y ?? 560} at={at} />;
          if (p.type === 'title') return <Title key={i} f={f} text={p.text ?? ''} sub={p.sub} at={at} />;
          if (p.type === 'plate') return <Plate key={i} f={f} x={p.x ?? 540} y={p.y ?? 1120} count={p.count ?? 3} offAt={p.off ? onWord(captions, p.off, fps, -1) : -1} />;
          if (p.type === 'ants') return <Ants key={i} f={f} at={at} y={p.y ?? 1170} />;
          if (p.type === 'choices') return <Choices key={i} f={f} items={p.items ?? []} answer={p.answer ?? 0} at={p.on ? at : -1} y={p.y ?? 420} />;
          if (p.type === 'apple') return <Apple key={i} f={f} x={p.x ?? 540} y={p.y ?? 1150} s={p.s ?? 1} at={p.on ? at : 0} />;
          if (p.type === 'egg') return <Egg key={i} f={f} x={p.x ?? 540} y={p.y ?? 1150} s={p.s ?? 1} at={p.on ? at : 0} />;
          if (p.type === 'notes') return <Notes key={i} f={f} at={at} x={p.x ?? 540} y={p.y ?? 900} />;
          if (p.type === 'bigtext') return <BigText key={i} f={f} text={p.text ?? ''} sub={p.sub} at={at} y={p.y ?? 420} color={p.color} />;
          return null;
        })}
      </AbsoluteFill>
      {sc.tint ? <AbsoluteFill style={{background: '#4A4A6A', opacity: sc.tint * interpolate(f, [0, 20], [0, 1], {extrapolateRight: 'clamp'}), mixBlendMode: 'multiply'}} /> : null}
    </AbsoluteFill>
  );
};

export const KIDS_SCENES = {kid: KidScene};
