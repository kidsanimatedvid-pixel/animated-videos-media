import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame} from 'remotion';

export const Grain: React.FC<{opacity?: number}> = ({opacity = 0.12}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{opacity, mixBlendMode: 'overlay', pointerEvents: 'none'}}>
      <svg width="100%" height="100%">
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={frame % 30} />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>
    </AbsoluteFill>
  );
};

export const Vignette: React.FC<{strength?: number}> = ({strength = 0.85}) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at 50% 45%, transparent 35%, rgba(0,0,0,${strength}) 100%)`,
      pointerEvents: 'none',
    }}
  />
);

export const Embers: React.FC<{count?: number; color?: string; seed?: string; rise?: number}> = ({
  count = 60, color = '#ff8a3d', seed = 'e', rise = 6,
}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {new Array(count).fill(0).map((_, i) => {
        const x0 = random(`${seed}x${i}`) * 1080;
        const speed = 0.4 + random(`${seed}s${i}`) * 1.2;
        const y = 1920 - (((frame * rise * speed) + random(`${seed}y${i}`) * 1920) % 2100);
        const size = 2 + random(`${seed}r${i}`) * 6;
        const x = x0 + Math.sin(frame / 18 + i) * 22;
        return (
          <div key={i} style={{position: 'absolute', left: x, top: y, width: size, height: size,
            borderRadius: '50%', background: color, boxShadow: `0 0 ${size * 3}px ${color}`,
            opacity: 0.35 + random(`${seed}o${i}`) * 0.65}} />
        );
      })}
    </AbsoluteFill>
  );
};

// Slow cinematic camera push applied to a whole scene
export const Camera: React.FC<{children: React.ReactNode; dur: number; from?: number; to?: number; panY?: number}> = ({
  children, dur, from = 1, to = 1.12, panY = 0,
}) => {
  const frame = useCurrentFrame();
  const p = Math.min(1, frame / Math.max(1, dur));
  return (
    <AbsoluteFill style={{scale: String(interpolate(p, [0, 1], [from, to])), translate: `0px ${p * panY}px`}}>
      {children}
    </AbsoluteFill>
  );
};

export const Shake: React.FC<{children: React.ReactNode; at: number; amount?: number}> = ({children, at, amount = 18}) => {
  const frame = useCurrentFrame();
  const d = frame - at;
  const k = d >= 0 && d < 14 ? (1 - d / 14) * amount : 0;
  return (
    <AbsoluteFill style={{translate: `${Math.sin(frame * 2.7) * k}px ${Math.cos(frame * 3.3) * k}px`}}>
      {children}
    </AbsoluteFill>
  );
};
