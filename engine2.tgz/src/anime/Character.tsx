import React, {useId} from 'react';

/* Anime-style bust character rig (front view, cel-shaded, outlined).
   One design per cast member (`look`), driven per frame by expression, mouth (0..1) and blink. */

export type Look = {
  skin: string; skinShade: string;
  hair: string; hairShade: string; hairHi?: string;
  hairStyle: 'spiky' | 'slick' | 'short' | 'hijab';
  eyes: string;
  outfit: string; outfitShade: string; trim?: string;
  kid?: boolean; beard?: boolean; shades?: boolean; headband?: string; scar?: boolean; number?: string;
};
export type Expression = 'neutral' | 'happy' | 'determined' | 'angry' | 'sad' | 'shock' | 'smug' | 'worried';

const INK = '#1b1020';

export const Character: React.FC<{
  look: Look; expression?: Expression; mouth?: number; blink?: boolean; lookX?: number;
  x: number; y: number; scale?: number; flip?: boolean; dim?: number;
}> = ({look, expression = 'neutral', mouth = 0, blink = false, lookX = 0, x, y, scale = 1, flip, dim = 0}) => {
  const id = useId().replace(/:/g, '');
  const kid = !!look.kid;
  const ex = expression;
  // face geometry
  const face = kid
    ? 'M188 300 C188 425 232 505 300 540 C368 505 412 425 412 300 C412 196 368 150 300 150 C232 150 188 196 188 300 Z'
    : 'M202 292 C202 432 242 522 300 562 C358 522 398 432 398 292 C398 186 358 144 300 144 C242 144 202 186 202 292 Z';
  const eyeY = kid ? 352 : 340;
  const eyeDX = kid ? 58 : 52;
  const erx = kid ? 36 : 29, ery = kid ? 44 : 30;
  const mouthY = kid ? 470 : 486;

  // expression → lids/brows
  const lid = blink ? 1 : ex === 'smug' ? 0.42 : ex === 'angry' ? 0.3 : ex === 'determined' ? 0.22 : ex === 'sad' ? 0.18 : ex === 'worried' ? 0.08 : 0;
  const lidTilt = ex === 'angry' || ex === 'determined' ? 14 : ex === 'sad' || ex === 'worried' ? -12 : 0; // + = inner corner lower
  const browInner = ex === 'angry' ? 26 : ex === 'determined' ? 16 : ex === 'sad' || ex === 'worried' ? -18 : ex === 'shock' ? -26 : 0;
  const browLift = ex === 'shock' ? -26 : ex === 'smug' ? -6 : 0;
  const irisScale = ex === 'shock' ? 0.45 : 0.78;
  const happyEyes = ex === 'happy' && !blink;

  const eye = (side: -1 | 1) => {
    const cx = 300 + side * eyeDX;
    const cid = `${id}e${side}`;
    if (happyEyes) {
      return <path d={`M${cx - erx} ${eyeY + 6} Q${cx} ${eyeY - ery} ${cx + erx} ${eyeY + 6}`} stroke={INK} strokeWidth={9} fill="none" strokeLinecap="round" />;
    }
    // lid cover polygon (skin) — tilted so inner corner (toward nose) is lower for angry
    const innerX = cx - side * erx, outerX = cx + side * erx;
    const top = eyeY - ery - 4;
    const lidY = eyeY - ery + lid * ery * 2;
    const innerY = lidY + lidTilt * (lid > 0 || lidTilt !== 0 ? 1 : 0);
    const outerY = lidY - lidTilt * 0.4;
    return (
      <g>
        <defs><clipPath id={cid}><ellipse cx={cx} cy={eyeY} rx={erx} ry={ery} /></clipPath></defs>
        <g clipPath={`url(#${cid})`}>
          <ellipse cx={cx} cy={eyeY} rx={erx} ry={ery} fill="#fbfbff" />
          <circle cx={cx + lookX * erx * 0.35} cy={eyeY + 4} r={ery * irisScale} fill={look.eyes} />
          <circle cx={cx + lookX * erx * 0.35} cy={eyeY + 10} r={ery * irisScale * 0.55} fill="rgba(0,0,0,0.25)" />
          {ex !== 'shock' && <circle cx={cx + lookX * erx * 0.35} cy={eyeY + 6} r={ery * irisScale * 0.42} fill={INK} />}
          {ex !== 'shock' && <circle cx={cx + lookX * erx * 0.35 - erx * 0.28} cy={eyeY - ery * 0.25} r={ery * 0.22} fill="#fff" />}
          {ex !== 'shock' && <circle cx={cx + lookX * erx * 0.35 + erx * 0.22} cy={eyeY + ery * 0.3} r={ery * 0.09} fill="#fff" />}
          {/* lid */}
          <path d={`M${innerX - side * 10} ${top - 30} L${outerX + side * 10} ${top - 30} L${outerX + side * 10} ${outerY} L${innerX - side * 10} ${innerY} Z`} fill={look.skin} />
        </g>
        {/* lash line */}
        <path d={blink
          ? `M${cx - erx} ${eyeY + 4} Q${cx} ${eyeY + 14} ${cx + erx} ${eyeY + 4}`
          : lid > 0.01 || lidTilt !== 0
            ? `M${innerX} ${innerY} L${outerX + side * 6} ${outerY - 4}`
            : `M${cx - erx - 2} ${eyeY - ery * 0.55} Q${cx} ${eyeY - ery - 8} ${cx + erx + 2} ${eyeY - ery * 0.55}`}
          stroke={INK} strokeWidth={blink ? 7 : 10} fill="none" strokeLinecap="round" />
        {/* outer lash flick */}
        {!blink && <path d={`M${outerX} ${eyeY - ery * 0.5} l${side * 12} ${-8}`} stroke={INK} strokeWidth={7} strokeLinecap="round" />}
      </g>
    );
  };

  const brow = (side: -1 | 1) => {
    const cx = 300 + side * eyeDX;
    const by = eyeY - ery - 26 + browLift;
    const inner = cx - side * (erx + 2), outer = cx + side * (erx + 8);
    const raise = ex === 'smug' && side === 1 ? -14 : 0;
    return <path d={`M${inner} ${by + browInner + raise} Q${cx} ${by - 10 + raise} ${outer} ${by + 6 + raise}`} stroke={look.hairShade} strokeWidth={kid ? 10 : 12} fill="none" strokeLinecap="round" />;
  };

  const mouthEl = (() => {
    const open = Math.max(0, Math.min(1, mouth));
    if (open > 0.08 || ex === 'shock') {
      const h = ex === 'shock' ? Math.max(20, open * 30) : 6 + open * 26;
      const w = ex === 'shock' ? 16 : 18 + open * 8;
      return (
        <g>
          <ellipse cx={300} cy={mouthY + 4} rx={w} ry={h / 2 + 2} fill="#5a1828" stroke={INK} strokeWidth={4} />
          <ellipse cx={300} cy={mouthY + 4 + h * 0.22} rx={w * 0.6} ry={h * 0.2} fill="#d9606f" />
        </g>
      );
    }
    if (ex === 'happy') return <path d={`M${276} ${mouthY - 4} Q300 ${mouthY + 22} ${324} ${mouthY - 4}`} stroke={INK} strokeWidth={6} fill="#7a2030" strokeLinecap="round" />;
    if (ex === 'sad' || ex === 'worried') return <path d={`M${282} ${mouthY + 8} Q300 ${mouthY - 4} ${318} ${mouthY + 8}`} stroke={INK} strokeWidth={6} fill="none" strokeLinecap="round" />;
    if (ex === 'smug') return <path d={`M${280} ${mouthY + 4} Q300 ${mouthY + 10} ${326} ${mouthY - 8}`} stroke={INK} strokeWidth={6} fill="none" strokeLinecap="round" />;
    if (ex === 'angry' || ex === 'determined') return <path d={`M${282} ${mouthY + 2} L${318} ${mouthY + 2}`} stroke={INK} strokeWidth={6} strokeLinecap="round" />;
    return <path d={`M${287} ${mouthY} Q300 ${mouthY + 6} ${313} ${mouthY}`} stroke={INK} strokeWidth={6} fill="none" strokeLinecap="round" />;
  })();

  /* ---------- hair ---------- */
  const hairBack = (() => {
    if (look.hairStyle === 'spiky')
      return <path d="M150 330 L120 250 L170 255 L140 170 L205 190 L200 100 L260 150 L300 60 L335 145 L400 95 L395 185 L465 165 L430 250 L480 250 L448 335 Z" fill={look.hair} stroke={INK} strokeWidth={5} strokeLinejoin="round" />;
    if (look.hairStyle === 'slick')
      return <path d="M185 330 Q170 160 300 120 Q440 110 430 230 L420 330 Z" fill={look.hair} stroke={INK} strokeWidth={5} />;
    if (look.hairStyle === 'hijab')
      return <path d="M150 900 L150 420 Q140 140 300 110 Q460 140 450 420 L450 900 Z" fill={look.outfit} stroke={INK} strokeWidth={5} />;
    return null;
  })();
  const hairFront = (() => {
    if (look.hairStyle === 'spiky')
      return (
        <g>
          <path d="M182 300 L190 215 Q230 150 300 150 Q370 150 410 215 L418 300 L392 255 L380 300 L350 240 L330 292 L300 232 L272 292 L250 240 L222 300 L208 255 Z" fill={look.hair} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <path d="M240 190 Q280 165 330 175" stroke={look.hairHi ?? '#4a4a7a'} strokeWidth={10} fill="none" strokeLinecap="round" />
        </g>
      );
    if (look.hairStyle === 'slick')
      return (
        <g>
          <path d="M196 290 Q190 170 300 150 Q400 140 420 200 Q360 180 300 215 Q240 245 214 300 Z" fill={look.hair} stroke={INK} strokeWidth={5} />
          <path d="M260 175 Q330 150 395 185" stroke={look.hairHi ?? '#ffe08a'} strokeWidth={14} fill="none" strokeLinecap="round" />
        </g>
      );
    if (look.hairStyle === 'short')
      return <path d="M204 270 Q200 160 300 146 Q400 160 396 270 Q380 205 300 200 Q220 205 204 270 Z" fill={look.hair} stroke={INK} strokeWidth={5} />;
    if (look.hairStyle === 'hijab')
      return <path d="M196 300 Q192 175 300 158 Q408 175 404 300 Q400 205 300 196 Q200 205 196 300 Z" fill={look.outfitShade} stroke={INK} strokeWidth={4} />;
    return null;
  })();

  return (
    <svg style={{position: 'absolute', left: x - 300 * scale, top: y - 900 * scale, overflow: 'visible', transform: flip ? 'scaleX(-1)' : undefined,
      filter: dim ? `brightness(${1 - dim * 0.6}) blur(${dim * 4}px)` : undefined}}
      width={600 * scale} height={900 * scale} viewBox="0 0 600 900">
      {hairBack}
      {/* neck + body */}
      <path d="M262 500 L262 600 L338 600 L338 500 Z" fill={look.skin} stroke={INK} strokeWidth={5} />
      <path d="M262 560 Q300 585 338 560 L338 600 L262 600 Z" fill={look.skinShade} />
      {look.hairStyle !== 'hijab' ? (
        <g>
          <path d="M70 900 Q80 650 230 600 Q300 640 370 600 Q520 650 530 900 Z" fill={look.outfit} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <path d="M70 900 Q80 650 230 600 L215 900 Z" fill={look.outfitShade} opacity={0.7} />
          <path d="M230 600 Q300 660 370 600" stroke={look.trim ?? '#fff'} strokeWidth={14} fill="none" />
          {look.number ? <text x={340} y={820} fontFamily="Anton" fontSize={130} fill={look.trim ?? '#fff'} opacity={0.9}>{look.number}</text> : null}
        </g>
      ) : (
        <path d="M60 900 Q90 640 300 600 Q510 640 540 900 Z" fill={look.outfit} stroke={INK} strokeWidth={6} />
      )}
      {/* head */}
      <path d={face} fill={look.skin} stroke={INK} strokeWidth={6} />
      {/* ears */}
      {look.hairStyle !== 'hijab' && <>
        <ellipse cx={kid ? 188 : 202} cy={360} rx={16} ry={30} fill={look.skin} stroke={INK} strokeWidth={5} />
        <ellipse cx={kid ? 412 : 398} cy={360} rx={16} ry={30} fill={look.skin} stroke={INK} strokeWidth={5} />
      </>}
      {/* cel shadow under fringe + jaw */}
      <path d={kid ? 'M196 290 Q300 330 404 290 L404 262 Q300 300 196 262 Z' : 'M208 280 Q300 318 392 280 L392 252 Q300 290 208 252 Z'} fill={look.skinShade} opacity={0.6} />
      {look.beard && <path d="M214 400 Q222 520 300 562 Q378 520 386 400 Q370 470 300 478 Q230 470 214 400 Z" fill={look.hairShade} opacity={0.9} />}
      {eye(-1)}{eye(1)}
      {brow(-1)}{brow(1)}
      {/* nose */}
      <path d={`M302 ${eyeY + 50} l-8 26 l10 2`} stroke={look.skinShade} strokeWidth={5} fill="none" strokeLinecap="round" />
      {mouthEl}
      {(ex === 'happy' || ex === 'shock') && <>
        <ellipse cx={300 - eyeDX - 8} cy={eyeY + 62} rx={26} ry={10} fill="#ff7a8a" opacity={0.45} />
        <ellipse cx={300 + eyeDX + 8} cy={eyeY + 62} rx={26} ry={10} fill="#ff7a8a" opacity={0.45} />
      </>}
      {look.scar && <path d="M370 300 l-26 70" stroke="#b5584e" strokeWidth={6} strokeLinecap="round" />}
      {hairFront}
      {look.headband && <>
        <path d="M188 262 Q300 228 412 262 L412 290 Q300 256 188 290 Z" fill={look.headband} stroke={INK} strokeWidth={5} />
        <path d="M412 268 q50 10 70 50 M412 280 q40 30 46 70" stroke={look.headband} strokeWidth={14} strokeLinecap="round" fill="none" />
      </>}
      {look.shades && (
        <g>
          <rect x={300 - eyeDX - 42} y={eyeY - 26} width={84} height={52} rx={18} fill="#0d0f18" stroke={INK} strokeWidth={5} />
          <rect x={300 + eyeDX - 42} y={eyeY - 26} width={84} height={52} rx={18} fill="#0d0f18" stroke={INK} strokeWidth={5} />
          <path d={`M${300 - eyeDX + 42} ${eyeY - 8} L${300 + eyeDX - 42} ${eyeY - 8}`} stroke={INK} strokeWidth={6} />
          <path d={`M${300 - eyeDX - 28} ${eyeY - 12} l22 -8`} stroke="#9fd8ff" strokeWidth={6} strokeLinecap="round" />
          <path d={`M${300 + eyeDX - 28} ${eyeY - 12} l22 -8`} stroke="#9fd8ff" strokeWidth={6} strokeLinecap="round" />
        </g>
      )}
    </svg>
  );
};
