import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig, Easing} from 'remotion';
import type {SceneProps} from '../types';
import {Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* "How deep is it?" kit: oceanDive — a cartoon submarine sinks; the water darkens with depth, a live depth counter runs,
   and one landmark per scene rises into view (tower, angler, wreck, everest, squeeze). */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const mix = (a: number[], b: number[], t: number) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
const waterAt = (d: number) => {
  const stops: [number, number[], number[]][] = [[0, [56, 189, 248], [14, 116, 189]], [200, [14, 116, 189], [12, 74, 140]], [1000, [10, 30, 80], [4, 12, 40]], [4000, [3, 8, 26], [1, 3, 12]], [11000, [1, 2, 8], [0, 0, 3]]];
  let i = 0;
  while (i < stops.length - 2 && d >= stops[i + 1][0]) i++;
  const t = Math.min(1, Math.max(0, (d - stops[i][0]) / (stops[i + 1][0] - stops[i][0])));
  return `linear-gradient(180deg, rgb(${mix(stops[i][1], stops[i + 1][1], t)}) 0%, rgb(${mix(stops[i][2], stops[i + 1][2], t)}) 100%)`;
};
const zoneAt = (d: number) => d < 200 ? 'SUNLIGHT ZONE' : d < 1000 ? 'TWILIGHT ZONE' : d < 4000 ? 'MIDNIGHT ZONE' : d < 6000 ? 'THE ABYSS' : 'THE TRENCHES';

const Sub: React.FC<{x: number; y: number; scared?: boolean; lamp?: number; squeeze?: number}> = ({x, y, scared, lamp = 0, squeeze = 0}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{position: 'absolute', left: x - 230, top: y - 150, width: 460, height: 300, rotate: `${Math.sin(frame / 11) * 3 + 6}deg`, scale: `${1 - squeeze * 0.08} ${1 + squeeze * 0.05}`}}>
      {lamp > 0 ? <div style={{position: 'absolute', left: 380, top: 60, width: 520, height: 260, background: `linear-gradient(90deg, rgba(253,230,138,${0.55 * lamp}), transparent)`, clipPath: 'polygon(0 42%, 100% 0, 100% 100%, 0 58%)'}} /> : null}
      <svg width={460} height={300} viewBox="0 0 460 300" style={{position: 'absolute', overflow: 'visible'}}>
        <g transform={`rotate(${frame * 30} 38 160)`}><path d="M38 110 L52 160 L38 210 L24 160 Z" fill="#94a3b8" stroke={OL} strokeWidth={7} /></g>
        <rect x={190} y={36} width={70} height={60} rx={12} fill="#f59e0b" stroke={OL} strokeWidth={10} /><path d="M225 36 V8 H262" stroke={OL} strokeWidth={12} fill="none" strokeLinecap="round" />
        <rect x={50} y={80} width={370} height={170} rx={85} fill="#facc15" stroke={OL} strokeWidth={12} />
        <path d="M90 232 Q230 262 380 232" stroke="#ca8a04" strokeWidth={12} fill="none" strokeLinecap="round" />
        <circle cx={150} cy={160} r={34} fill="#7dd3fc" stroke={OL} strokeWidth={9} /><circle cx={140} cy={150} r={9} fill="#fff" />
        <circle cx={300} cy={148} r={scared ? 40 : 34} fill="#fff" stroke={OL} strokeWidth={9} /><circle cx={scared ? 300 : 310} cy={scared ? 148 : 152} r={scared ? 10 : 15} fill={OL} />
        {scared ? <ellipse cx={370} cy={200} rx={14} ry={18} fill="#7a1f2b" stroke={OL} strokeWidth={7} /> : <path d="M344 198 Q372 216 394 190" stroke={OL} strokeWidth={9} fill="none" strokeLinecap="round" />}
        <circle cx={424} cy={128} r={15} fill={lamp > 0 ? '#fde68a' : '#e2e8f0'} stroke={OL} strokeWidth={7} />
      </svg>
    </div>
  );
};

/* oceanDive: { from, to, landmark?: 'surface'|'tower'|'angler'|'wreck'|'everest'|'squeeze', tag?, tagOnWord?, tag2?, tag2OnWord?, badge?, sweepOnWord? } */
const OceanDive: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const from = (scene.from as number) ?? 0, to = (scene.to as number) ?? from;
  const lm = (scene.landmark as string) ?? '';
  const sw = at(captions, scene.sweepOnWord, fps, 2);
  const end = Math.max(sw + 12, Math.min(dur - 8, sw + ((scene.sweepFrames as number | undefined) ?? dur * 0.6)));
  const p = interpolate(frame, [sw, end], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const d = from + (to - from) * p;
  const moving = p > 0.02 && p < 0.98;
  const tAt = at(captions, scene.tagOnWord, fps, end), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.75);
  const rise = spring({frame: frame - (end - 14), fps, config: {damping: 14}});
  const dark = Math.min(1, d / 900);
  const sq = lm === 'squeeze' ? interpolate(frame, [tAt, tAt + 10], [0, 1], clamp) * (1 + Math.sin(frame * 1.3) * 0.3) : 0;
  const LY = 1500 - rise * 380; // landmark baseline
  return (
    <Shake at={lm === 'surface' ? 0 : tAt} amount={lm === 'surface' ? 22 : 12}>
      <AbsoluteFill style={{background: waterAt(d)}} />
      {lm === 'surface' ? (
        <div style={{position: 'absolute', left: 0, top: -interpolate(frame, [0, dur], [0, 520], clamp), width: 1080, height: 520}}>
          <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(180deg, #7dd3fc, #e0f2fe)'}} />
          <div style={{position: 'absolute', left: 780, top: 150, width: 170, height: 170, borderRadius: '50%', background: '#fde047', border: `8px solid ${OL}`}} />
          <svg width={1080} height={90} style={{position: 'absolute', top: 450}}><path d={`M0 50 ${new Array(9).fill(0).map((_, i) => `Q${i * 120 + 60} ${10 + Math.sin(frame / 5 + i) * 18} ${(i + 1) * 120} 50`).join(' ')} L1080 90 L0 90 Z`} fill="#38bdf8" stroke={OL} strokeWidth={8} /></svg>
        </div>
      ) : null}
      {/* light rays near the surface, marine snow in the deep */}
      {d < 500 ? [0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: 80 + i * 260, top: -100, width: 120, height: 1500, background: 'linear-gradient(180deg, rgba(255,255,255,0.22), transparent)', rotate: '14deg', opacity: 1 - d / 500}} />) : null}
      {new Array(34).fill(0).map((_, i) => {
        const sp = moving ? 26 + random(`bv${i}`) * 30 : 3 + random(`bv${i}`) * 3;
        const y = 1920 - ((frame * sp + random(`by${i}`) * 2100) % 2100);
        const r = 8 + random(`br${i}`) * 18;
        return <div key={i} style={{position: 'absolute', left: random(`bx${i}`) * 1080, top: y, width: r, height: moving ? r * 3.5 : r, borderRadius: r, border: d < 1500 ? '3px solid #ffffffaa' : 'none', background: d < 1500 ? 'transparent' : '#ffffff55'}} />;
      })}
      {/* landmarks */}
      {lm === 'tower' ? (
        <svg width={420} height={900} viewBox="0 0 420 900" style={{position: 'absolute', left: 60, top: LY - 760}}>
          <path d="M210 20 L236 300 L286 600 L380 880 L300 880 Q210 700 120 880 L40 880 L134 600 L184 300 Z" fill="#475569" stroke={OL} strokeWidth={10} strokeLinejoin="round" />
          <path d="M150 600 H270 M172 300 H248 M100 760 H320" stroke={OL} strokeWidth={14} /><path d="M196 300 L224 600 M224 300 L196 600" stroke={OL} strokeWidth={5} opacity={0.6} />
        </svg>
      ) : null}
      {lm === 'angler' ? (
        <svg width={420} height={330} viewBox="0 0 420 330" style={{position: 'absolute', left: 1100 - rise * 560 + Math.sin(frame / 9) * 20, top: 1090 + Math.cos(frame / 8) * 16}}>
          <circle cx={70} cy={70} r={60} fill="#fde68a" opacity={0.35 + 0.2 * Math.sin(frame / 4)} /><circle cx={70} cy={70} r={22} fill="#fef08a" stroke={OL} strokeWidth={6} />
          <path d="M240 110 Q170 20 86 62" stroke={OL} strokeWidth={9} fill="none" strokeLinecap="round" />
          <path d="M400 190 L340 150 L340 250 Z" fill="#7c3aed" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
          <ellipse cx={230} cy={200} rx={140} ry={100} fill="#8b5cf6" stroke={OL} strokeWidth={10} />
          <path d="M96 210 Q150 190 190 230 Q150 280 104 260 Z" fill="#3b0764" stroke={OL} strokeWidth={8} strokeLinejoin="round" />{[112, 136, 160].map((x) => <path key={x} d={`M${x} ${214 + (x - 112) * 0.1} l8 22 l8 -20`} fill="#fff" stroke={OL} strokeWidth={4} />)}
          <circle cx={200} cy={160} r={22} fill="#fff" stroke={OL} strokeWidth={7} /><circle cx={194} cy={162} r={9} fill={OL} />
        </svg>
      ) : null}
      {lm === 'wreck' ? (
        <svg width={1080} height={520} viewBox="0 0 1080 520" style={{position: 'absolute', left: 0, top: LY - 330}}>
          <path d="M0 400 Q300 340 560 400 Q820 450 1080 380 L1080 520 L0 520 Z" fill="#1e293b" stroke={OL} strokeWidth={10} />
          <g transform="rotate(-7 520 300)"><path d="M160 300 L250 190 L760 190 L900 250 L860 400 L220 400 Z" fill="#7c2d12" stroke={OL} strokeWidth={10} strokeLinejoin="round" />
            <path d="M250 190 L760 190 L760 240 L212 240 Z" fill="#9a3412" stroke={OL} strokeWidth={8} />{[320, 400, 480, 560, 640, 720].map((x) => <circle key={x} cx={x} cy={300} r={15} fill="#0f172a" stroke={OL} strokeWidth={6} />)}
            {[380, 520, 660].map((x, i) => <rect key={x} x={x} y={i === 1 ? 90 : 110} width={60} height={i === 1 ? 100 : 80} fill="#57534e" stroke={OL} strokeWidth={8} transform={`rotate(${i === 2 ? 14 : 0} ${x} 190)`} />)}</g>
        </svg>
      ) : null}
      {lm === 'everest' ? <div style={{position: 'absolute', left: 0, top: LY + 280, width: 1080, height: 1400, background: '#0f172a'}} /> : null}
      {lm === 'everest' ? (
        <svg width={1080} height={900} viewBox="0 0 1080 900" style={{position: 'absolute', left: 0, top: LY - 600}}>
          <path d="M0 0 L0 900 L1080 900 L1080 0 L980 40 L900 300 L830 760 L250 760 L170 300 L100 40 Z" fill="#0f172a" stroke={OL} strokeWidth={10} strokeLinejoin="round" />
          <path d="M300 760 L520 250 L600 400 L650 330 L800 760 Z" fill="#94a3b8" stroke={OL} strokeWidth={10} strokeLinejoin="round" /><path d="M520 250 L560 340 L520 320 L484 334 Z" fill="#fff" stroke={OL} strokeWidth={6} strokeLinejoin="round" />
          <g opacity={interpolate(frame, [t2, t2 + 8], [0, 1], clamp)}><path d="M520 240 V40 M490 40 H550 M490 240 H550" stroke="#fde047" strokeWidth={10} strokeLinecap="round" /></g>
        </svg>
      ) : null}
      {lm === 'squeeze' ? [0, 1, 2, 3, 4, 5, 6, 7].map((i) => {
        const a = (i / 8) * Math.PI * 2, r = 380 - sq * 60 + Math.sin(frame / 3 + i) * 10;
        return <svg key={i} width={140} height={90} viewBox="0 0 140 90" style={{position: 'absolute', left: 540 + Math.cos(a) * r - 70, top: 820 + Math.sin(a) * r * 0.8 - 45, rotate: `${(a * 180) / Math.PI + 180}deg`, opacity: frame >= tAt ? 1 : 0}}>
          <path d="M10 45 H96 M70 14 L112 45 L70 76" stroke={OL} strokeWidth={26} fill="none" strokeLinecap="round" strokeLinejoin="round" /><path d="M10 45 H96 M70 14 L112 45 L70 76" stroke="#ef4444" strokeWidth={13} fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>;
      }) : null}
      <AbsoluteFill style={{background: '#000', opacity: dark * 0.35}} />
      <Sub x={lm === 'tower' ? 660 : lm === 'everest' ? 300 : 520} y={lm === 'surface' ? interpolate(frame, [0, 22], [300, 820], clamp) : lm === 'everest' ? 800 + rise * 70 : 820 + (moving ? Math.sin(frame / 2) * 6 : Math.sin(frame / 12) * 14)} scared={lm === 'squeeze' || lm === 'angler'} lamp={dark} squeeze={sq} />
      {lm === 'surface' ? new Array(12).fill(0).map((_, i) => { const t = Math.min(1, (frame - 6) / 20); if (t <= 0 || t >= 1) return null; const a = -Math.PI * (i / 11);
        return <div key={i} style={{position: 'absolute', left: 520 + Math.cos(a) * t * 300, top: 520 + Math.sin(a) * t * 240 + t * t * 200, width: 30, height: 30, borderRadius: 15, background: '#e0f2fe', border: `5px solid ${OL}`, opacity: 1 - t}} />; }) : null}
      {/* depth read-out */}
      <div style={{position: 'absolute', top: 210, width: '100%', textAlign: 'center'}}>
        <div><span style={{fontFamily: BODY, fontWeight: 800, fontSize: 38, color: '#111', background: '#7dd3fc', padding: '4px 22px', borderRadius: 30, border: `5px solid ${OL}`}}>{zoneAt(d)}</span></div>
        <div style={{fontFamily: DISPLAY, fontSize: 170, lineHeight: 1.15, color: '#fff', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill', fontVariantNumeric: 'tabular-nums'}}>{Math.round(d).toLocaleString('en-US')} M</div>
      </div>
      {scene.badge ? <Tag text={scene.badge as string} at={0} y={96} size={48} color="#111" fg="#ffcc4d" rot={0} /> : null}
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={(scene.tagY as number) ?? 520} size={(scene.tagSize as number) ?? 76} color={(scene.tagColor as string) ?? '#fde047'} /> : null}
      {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={(scene.tag2Y as number) ?? 640} size={62} color="#fff" rot={2} /> : null}
    </Shake>
  );
};

export const OCEAN_SCENES: Record<string, React.FC<SceneProps>> = {
  oceanDive: OceanDive,
};
