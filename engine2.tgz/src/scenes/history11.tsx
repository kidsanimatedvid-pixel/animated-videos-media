import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {DailyPill, SeriesBadge, Syn} from '../components/Host';
import {CameraRig, EASE, impulse, impulses, kf, Layer, Particles} from '../components/Motion';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Guess Who: History #11 · Ragnarok's Real Humans #3 — Nikola Tesla gives up his royalty deal (1891).
   Verified: 1891 he released Westinghouse from the royalty clause (Wikipedia, PBS, Smithsonian); the "tore it up on the spot" detail is told as legend.
   1893 Chicago fair lit with AC by Westinghouse, beating Edison-backed GE (PBS, History.com, Illinois State Museum).
   Later years in New York hotels with unpaid bills; from 1934 Westinghouse paid him $125/month + rent (Wikipedia, Smithsonian).
   Original cartoons only; identity lock = dark "?" silhouette until the reveal. Animation kit v2 camera + impacts. */
const OL = '#1a120b';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);
const BADGE = 'GUESS WHO: HISTORY #11';
const NIGHT = 'radial-gradient(circle at 50% 36%, #bae6fd 0%, #1e3a8a 30%, #0b1020 72%)';

const Tag: React.FC<{text: string; a: number; y: number; color?: string; size?: number; rot?: number}> = ({text, a, y, color = '#ffcc4d', size = 62, rot = -3}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < a) return null;
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: 40, right: 140, top: y, textAlign: 'center', scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: '#111', background: color, padding: '4px 26px', borderRadius: 14, border: `6px solid ${OL}`, boxShadow: `0 8px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Room: React.FC<{children?: React.ReactNode; bg?: string}> = ({children, bg = NIGHT}) => (
  <AbsoluteFill style={{background: bg}}>
    <div style={{position: 'absolute', left: 0, right: 0, top: 1080, height: 840, background: '#3b2414', borderTop: `8px solid ${OL}`}} />
    {children}
  </AbsoluteFill>
);

/* The royalty contract; tear 0..1 splits it into two halves flying apart. */
const Contract: React.FC<{x: number; y: number; s?: number; tear?: number; coins?: number}> = ({x, y, s = 1, tear = 0, coins = 0}) => {
  const half = (side: -1 | 1) => (
    <div style={{position: 'absolute', left: side < 0 ? 0 : 210 * s, top: 0, width: 210 * s, height: 540 * s, overflow: 'hidden', translate: `${side * tear * 160 * s}px ${tear * 40 * s}px`, rotate: `${side * tear * 16}deg`, transformOrigin: side < 0 ? '100% 0%' : '0% 0%'}}>
      <div style={{position: 'absolute', left: side < 0 ? 0 : -210 * s, top: 0, width: 420 * s, height: 540 * s, background: '#fffbeb', border: `${6 * s}px solid ${OL}`, borderRadius: 14 * s}}>
        <div style={{position: 'absolute', left: 0, right: 0, top: 30 * s, textAlign: 'center', fontFamily: DISPLAY, fontSize: 52 * s, color: '#1e3a8a'}}>ROYALTY DEAL</div>
        {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: 30 * s, right: 30 * s, top: (120 + i * 46) * s, height: 12 * s, borderRadius: 6 * s, background: '#d6d3d1'}} />)}
        <div style={{position: 'absolute', left: 20 * s, right: 20 * s, top: 320 * s, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 30 * s, color: OL}}>PAID FOR EVERY<br />HORSEPOWER</div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 430 * s, textAlign: 'center', fontFamily: DISPLAY, fontSize: 64 * s, color: '#16a34a'}}>${Math.round(coins).toLocaleString('en-US')}</div>
      </div>
    </div>
  );
  return <div style={{position: 'absolute', left: x, top: y, width: 420 * s, height: 540 * s}}>{half(-1)}{half(1)}</div>;
};

const Mystery: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 300 * s, height: 420 * s}}>
    <div style={{position: 'absolute', left: 80 * s, top: 0, width: 140 * s, height: 150 * s, borderRadius: '50%', background: '#0c0a09'}} />
    <div style={{position: 'absolute', left: 20 * s, top: 130 * s, width: 260 * s, height: 290 * s, borderRadius: `${120 * s}px ${120 * s}px ${30 * s}px ${30 * s}px`, background: '#0c0a09'}} />
    <div style={{position: 'absolute', left: 0, right: 0, top: 10 * s, textAlign: 'center', fontFamily: DISPLAY, fontSize: 120 * s, color: '#7dd3fc'}}>?</div>
  </div>
);

/* Original cartoon inventor (reveal only): slim, dark centre-parted hair, thin moustache, dark suit, white collar. */
const Inventor: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <svg style={{position: 'absolute', left: x, top: y}} width={320 * s} height={460 * s} viewBox="0 0 320 460">
    <path d="M40 460 L60 250 Q160 205 260 250 L280 460 Z" fill="#1f2937" stroke={OL} strokeWidth="8" />
    <path d="M130 238 L160 300 L190 238 Z" fill="#f8fafc" stroke={OL} strokeWidth="6" />
    <rect x="138" y="190" width="44" height="50" fill="#f1c9a5" stroke={OL} strokeWidth="6" />
    <ellipse cx="160" cy="130" rx="74" ry="92" fill="#f1c9a5" stroke={OL} strokeWidth="8" />
    <path d="M86 116 Q90 40 160 38 Q230 40 234 116 Q216 70 164 68 L160 92 L156 68 Q104 70 86 116 Z" fill="#1c1917" stroke={OL} strokeWidth="6" />
    <circle cx="132" cy="128" r="8" fill={OL} /><circle cx="188" cy="128" r="8" fill={OL} />
    <path d="M122 110 L146 106 M174 106 L198 110" stroke={OL} strokeWidth="6" strokeLinecap="round" />
    <path d="M128 178 Q160 166 192 178" stroke="#1c1917" strokeWidth="10" fill="none" strokeLinecap="round" />
    <path d="M140 196 Q160 206 180 196" stroke={OL} strokeWidth="5" fill="none" strokeLinecap="round" />
  </svg>
);

/* A zig-zag spark between two points (used by the coil + fair). */
const Spark: React.FC<{x1: number; y1: number; x2: number; y2: number; seed: number; color?: string}> = ({x1, y1, x2, y2, seed, color = '#bae6fd'}) => {
  const frame = useCurrentFrame();
  const pts = new Array(7).fill(0).map((_, i) => {
    const t = i / 6;
    const j = i === 0 || i === 6 ? 0 : Math.sin((frame + seed) * 1.7 + i * 2.3) * 26;
    return `${x1 + (x2 - x1) * t + j},${y1 + (y2 - y1) * t - j * 0.5}`;
  }).join(' ');
  return <svg style={{position: 'absolute', left: 0, top: 0}} width={1080} height={1920}><polyline points={pts} fill="none" stroke={color} strokeWidth="7" strokeLinejoin="round" style={{filter: 'drop-shadow(0 0 12px #38bdf8)'}} /></svg>;
};

/* dealHook (Arm B, current opening): frame 0 = silhouette at the lamp-lit desk, the contract's money counter already ticking up;
   punch-in at 1.2 s; on "gives" the contract rips in two (camera kick). */
const DealHook: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const gAt = at(captions, scene.giveOnWord, fps, dur * 0.75);
  const tear = kf(frame, [[gAt, 0], [gAt + 12, 1, EASE.out]]);
  const coins = kf(frame, [[0, 1200], [gAt, 48000, EASE.in]]);
  const cam = {x: 540, y: kf(frame, [[0, 900], [36, 860, EASE.smooth]]), zoom: (frame < 36 ? 1.0 : 1.14) + kf(frame, [[36, 0], [dur, 0.06, EASE.smooth]]) + impulses(frame, [36, gAt + 4], 0.05, 12, 1.4), roll: impulse(frame, gAt + 4, 1.4, 14, 1.1)};
  return (
    <Room>
      <CameraRig cam={cam}>
        <Layer depth={0.6}><div style={{position: 'absolute', left: 380, top: 140, width: 320, height: 320, borderRadius: '50%', background: 'radial-gradient(circle, rgba(254,240,138,0.55), transparent 70%)'}} /></Layer>
        <Layer depth={1}>
          <Mystery x={640} y={600} s={1.05} />
          <Contract x={150} y={560} s={0.95} tear={tear} coins={coins} />
          <Particles count={16} color="#facc15" size={10} speedY={-1.2} speedX={0.3} seed={11} opacity={frame < gAt ? 0.7 : 0} />
        </Layer>
      </CameraRig>
      <Tag text="1891" a={2} y={300} size={70} color="#7dd3fc" />
      <SeriesBadge text={BADGE} />
    </Room>
  );
};

/* sinkingCo: { begOnWord, tearOnWord } — a factory with a crashing debt arrow; a top-hatted boss bows to the silhouette; on "tore" the contract halves fly; tag THE STORY SAYS (legend flag). */
const SinkingCo: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const bAt = at(captions, scene.begOnWord, fps, dur * 0.35);
  const tAt = at(captions, scene.tearOnWord, fps, dur * 0.7);
  const drop = kf(frame, [[0, 0], [bAt, 1, EASE.in]]);
  const bow = kf(frame, [[bAt - 4, 0], [bAt + 8, 1, EASE.overshoot]]);
  const tear = kf(frame, [[tAt, 0], [tAt + 12, 1, EASE.out]]);
  const cam = {x: 540, y: 820, zoom: kf(frame, [[0, 1.08], [dur, 1.18, EASE.smooth]]) + impulse(frame, tAt + 4, 0.05, 12, 1.4)};
  return (
    <Room bg="linear-gradient(#1e293b, #0f172a)">
      <CameraRig cam={cam}>
        <Layer depth={0.6}>
          <div style={{position: 'absolute', left: 120, top: 380, width: 520, height: 330, background: '#475569', border: `8px solid ${OL}`}} />
          {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 170 + i * 150, top: 260, width: 60, height: 130, background: '#334155', border: `6px solid ${OL}`}} />)}
          <div style={{position: 'absolute', left: 120, top: 420, width: 520, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 34, color: '#e2e8f0'}}>HIS PARTNER'S COMPANY</div>
          <svg style={{position: 'absolute', left: 660, top: 300}} width={320} height={420}><polyline points={`20,40 120,${80 + drop * 120} 200,${60 + drop * 200} 290,${90 + drop * 290}`} fill="none" stroke="#ef4444" strokeWidth="16" strokeLinecap="round" /></svg>
          <div style={{position: 'absolute', left: 690, top: 250, fontFamily: DISPLAY, fontSize: 48, color: '#ef4444'}}>DEBT</div>
        </Layer>
        <Layer depth={1}>
          <div style={{position: 'absolute', left: 100, top: 760, width: 200, height: 330, rotate: `${bow * 22}deg`, transformOrigin: '50% 100%'}}>
            <div style={{position: 'absolute', left: 50, top: 0, width: 100, height: 60, background: '#111', borderRadius: 6}} />
            <div style={{position: 'absolute', left: 30, top: 50, width: 140, height: 20, background: '#111'}} />
            <div style={{position: 'absolute', left: 55, top: 70, width: 90, height: 90, borderRadius: '50%', background: '#e7c39f', border: `6px solid ${OL}`}} />
            <div style={{position: 'absolute', left: 25, top: 150, width: 150, height: 180, borderRadius: '60px 60px 16px 16px', background: '#57534e', border: `6px solid ${OL}`}} />
          </div>
          <Mystery x={680} y={690} s={1} />
          {frame >= tAt - 30 ? <Contract x={360} y={600} s={0.6} tear={tear} coins={48000} /> : null}
        </Layer>
      </CameraRig>
      <Tag text="PLEASE. WE'RE SINKING." a={bAt} y={1130} size={54} color="#fca5a5" rot={2} />
      <Tag text="THE STORY SAYS…" a={tAt - 18} y={1240} size={50} color="#e9d5ff" rot={-2} />
    </Room>
  );
};

/* fairLights: { beatOnWord, bulbsOnWord } — 1893 Chicago fair at night; on "beat" the white palaces light up in a wave left→right; "AC" beats "DC" scoreboard; tag 100,000+ BULBS. */
const FairLights: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const bAt = at(captions, scene.beatOnWord, fps, dur * 0.35);
  const uAt = at(captions, scene.bulbsOnWord, fps, dur * 0.75);
  const wave = kf(frame, [[bAt, 0], [bAt + 30, 1, EASE.smooth]]);
  const cam = {x: kf(frame, [[0, 480], [dur, 600, EASE.smooth]]), y: 760, zoom: kf(frame, [[0, 1.2], [dur, 1.05, EASE.smooth]]) + impulse(frame, bAt + 3, 0.04, 12, 1.4)};
  const bulbs = new Array(60).fill(0).map((_, i) => ({x: 60 + (i % 20) * 48, y: 640 + Math.floor(i / 20) * 70, on: (i % 20) / 20 < wave}));
  return (
    <AbsoluteFill style={{background: `linear-gradient(#020617, ${wave > 0.5 ? '#1e3a8a' : '#0b1020'})`}}>
      <CameraRig cam={cam}>
        <Layer depth={0.5}>{new Array(40).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: (i * 137) % 1080, top: 120 + ((i * 89) % 380), width: 5, height: 5, borderRadius: 3, background: '#e2e8f0', opacity: 0.6 - wave * 0.4}} />)}</Layer>
        <Layer depth={0.85}>
          {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 60 + i * 330, top: 600 - (i === 1 ? 80 : 0), width: 300, height: 420 + (i === 1 ? 80 : 0), background: wave > i / 3 ? '#f8fafc' : '#334155', border: `6px solid ${OL}`, borderRadius: i === 1 ? '150px 150px 0 0' : 0}} />)}
          {bulbs.map((b, i) => <div key={i} style={{position: 'absolute', left: b.x, top: b.y, width: 18, height: 18, borderRadius: 9, background: b.on ? '#fde68a' : '#475569', boxShadow: b.on ? '0 0 22px 8px rgba(253,230,138,0.8)' : 'none'}} />)}
          <div style={{position: 'absolute', left: 0, right: 0, top: 1020, height: 120, background: '#0f172a'}} />
        </Layer>
      </CameraRig>
      <Tag text="1893 · CHICAGO FAIR" a={4} y={300} size={58} color="#7dd3fc" />
      {frame >= bAt ? <div style={{position: 'absolute', left: 60, right: 160, top: 1150, display: 'flex', justifyContent: 'center', gap: 30, scale: String(kf(frame, [[bAt, 0.4], [bAt + 9, 1, EASE.overshoot]]))}}>
        <span style={{fontFamily: DISPLAY, fontSize: 64, color: '#111', background: '#86efac', padding: '4px 26px', borderRadius: 14, border: `6px solid ${OL}`}}>HIS AC ✓</span>
        <span style={{fontFamily: DISPLAY, fontSize: 64, color: '#fff', background: '#64748b', padding: '4px 26px', borderRadius: 14, border: `6px solid ${OL}`, textDecoration: 'line-through'}}>EDISON'S DC</span>
      </div> : null}
      <Tag text="100,000+ BULBS" a={uAt} y={420} size={60} color="#fde68a" rot={2} />
    </AbsoluteFill>
  );
};

/* hotelBills: { noOnWord, billsOnWord } — a row of hotel doors; unpaid bills slide under one door and pile up; big NO. */
const HotelBills: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const nAt = at(captions, scene.noOnWord, fps, dur * 0.25);
  const bAt = at(captions, scene.billsOnWord, fps, dur * 0.7);
  const cam = {x: kf(frame, [[0, 420], [dur, 640, EASE.smooth]]), y: 820, zoom: 1.12 + impulse(frame, nAt + 3, 0.05, 12, 1.4)};
  return (
    <Room bg="linear-gradient(#3f2a1d, #1c1410)">
      <CameraRig cam={cam}>
        <Layer depth={1}>
          {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: 40 + i * 260, top: 480, width: 200, height: 600, background: '#7c2d12', border: `7px solid ${OL}`, borderRadius: 10}}>
            <div style={{position: 'absolute', left: 60, top: 40, width: 80, height: 40, background: '#fbbf24', border: `4px solid ${OL}`, borderRadius: 6, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 26, color: OL}}>{301 + i * 101}</div>
            <div style={{position: 'absolute', left: 150, top: 300, width: 24, height: 24, borderRadius: 12, background: '#fbbf24'}} />
          </div>)}
          {new Array(9).fill(0).map((_, i) => {
            const t = Math.max(0, frame - bAt - i * 4);
            if (frame < bAt + i * 4) return null;
            return <div key={i} style={{position: 'absolute', left: 300 + (i % 3) * 70, top: 1040 - Math.min(1, t / 8) * 60 - i * 14, width: 150, height: 90, rotate: `${(i % 2 ? 8 : -6)}deg`, background: '#fef3c7', border: `4px solid ${OL}`, borderRadius: 6, textAlign: 'center', fontFamily: DISPLAY, fontSize: 30, color: '#dc2626', paddingTop: 22}}>UNPAID</div>;
          })}
        </Layer>
      </CameraRig>
      <Tag text="RICH? NO." a={nAt} y={320} size={80} color="#fca5a5" />
    </Room>
  );
};

/* rentLetter: { yearOnWord, rentOnWord } — an envelope from "the same company" slides in; the check reads RENT · EVERY MONTH; tag 1934. */
const RentLetter: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const yAt = at(captions, scene.yearOnWord, fps, dur * 0.1);
  const rAt = at(captions, scene.rentOnWord, fps, dur * 0.55);
  const slide = kf(frame, [[yAt, 0], [yAt + 14, 1, EASE.overshoot]]);
  const open = kf(frame, [[rAt - 4, 0], [rAt + 10, 1, EASE.out]]);
  const cam = {x: 540, y: 860, zoom: kf(frame, [[0, 1.0], [dur, 1.16, EASE.smooth]]) + impulse(frame, rAt + 6, 0.04, 12, 1.4)};
  return (
    <Room>
      <CameraRig cam={cam}>
        <Layer depth={1}>
          <div style={{position: 'absolute', left: 190, top: 560 + (1 - slide) * 700, width: 700, height: 420, background: '#fde68a', border: `8px solid ${OL}`, borderRadius: 16}}>
            <div style={{position: 'absolute', left: 0, right: 0, top: 40, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 34, color: OL}}>FROM: THE SAME COMPANY</div>
            <div style={{position: 'absolute', left: 60, right: 60, top: 120 - open * 90, height: 220, background: '#f0fdf4', border: `6px solid ${OL}`, borderRadius: 12, textAlign: 'center', opacity: open}}>
              <div style={{fontFamily: DISPLAY, fontSize: 64, color: '#15803d', marginTop: 30}}>$125 + RENT</div>
              <div style={{fontFamily: BODY, fontWeight: 900, fontSize: 34, color: OL, marginTop: 6}}>EVERY MONTH</div>
            </div>
          </div>
          <Mystery x={800} y={860} s={0.7} />
        </Layer>
      </CameraRig>
      <Tag text="1934" a={yAt} y={300} size={80} color="#7dd3fc" />
    </Room>
  );
};

/* teslaReveal: { nameOnWord, sendOnWord } — silhouette pops into the original cartoon inventor in front of a crackling coil; name card; send line; pill; loops into "1891." */
const TeslaReveal: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const nAt = at(captions, scene.nameOnWord, fps, dur * 0.3);
  const sAt = at(captions, scene.sendOnWord, fps, dur * 0.6);
  const pop = spring({frame: frame - nAt, fps, config: {damping: 9}});
  const cam = {x: 540, y: 860, zoom: kf(frame, [[0, 1.06], [nAt, 1.0, EASE.smooth], [dur, 1.08, EASE.smooth]]) + impulse(frame, nAt + 2, 0.06, 14, 1.3)};
  return (
    <Room>
      <CameraRig cam={cam}>
        <Layer depth={0.7}>
          <div style={{position: 'absolute', left: 120, top: 560, width: 60, height: 420, background: '#78716c', border: `6px solid ${OL}`}} />
          <div style={{position: 'absolute', left: 90, top: 520, width: 120, height: 70, borderRadius: '50%', background: '#a8a29e', border: `6px solid ${OL}`}} />
          {frame >= nAt ? <><Spark x1={150} y1={540} x2={330} y2={420} seed={1} /><Spark x1={150} y1={540} x2={60} y2={380} seed={7} /></> : null}
        </Layer>
        <Layer depth={1}>
          <Contract x={110} y={900} s={0.4} tear={1} coins={48000} />
          {frame < nAt ? <Mystery x={380} y={600} s={1.2} /> : <div style={{scale: String(0.6 + 0.4 * pop), transformOrigin: '540px 900px'}}><Inventor x={380} y={580} s={1.05} /></div>}
        </Layer>
      </CameraRig>
      {frame >= nAt ? <Tag text="NIKOLA TESLA" a={nAt} y={1100} size={96} color="#7dd3fc" rot={-2} /> : null}
      {frame >= nAt + 8 ? <div style={{position: 'absolute', left: 60, right: 160, top: 1250, textAlign: 'center', whiteSpace: 'nowrap'}}><span style={{fontFamily: BODY, fontWeight: 800, fontSize: 34, color: '#fff7ed', background: 'rgba(0,0,0,0.55)', padding: '6px 18px', borderRadius: 12}}>gave up his royalty deal · 1891</span></div> : null}
      {frame >= sAt ? <div style={{position: 'absolute', left: 50, right: 150, top: 330, textAlign: 'center', lineHeight: 1.5}}><span style={{fontFamily: BODY, fontWeight: 900, fontSize: 40, color: '#111', background: '#86efac', padding: '8px 22px', borderRadius: 14, border: `5px solid ${OL}`}}>📤 Send this to the friend who'd give up anything to help a mate</span></div> : null}
      <DailyPill from={Math.round(sAt + 10)} y={500} />
      <SeriesBadge text={BADGE} />
      <Syn x={790} y={860} size={180} pose="shock" from={Math.round(nAt + 6)} to={dur} />
    </Room>
  );
};

export const HISTORY11_SCENES: Record<string, React.FC<SceneProps>> = {dealHook: DealHook, sinkingCo: SinkingCo, fairLights: FairLights, hotelBills: HotelBills, rentLetter: RentLetter, teslaReveal: TeslaReveal};
