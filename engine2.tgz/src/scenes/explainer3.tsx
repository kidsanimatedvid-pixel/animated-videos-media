import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Explainer kit 3 ("What if?"): earthDive (POV plunge down a tunnel through the planet) and
   earthSection (cross-section of Earth with a falling traveller, several modes). */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const C = {cyan: '#3fe0ff', coral: '#ff6b6b', mint: '#5dffb0', gold: '#ffcc4d', ink: '#e9f6ff'};

const Readout: React.FC<{label: string; value: string; color?: string; top?: number; opacity?: number}> = ({label, value, color = C.cyan, top = 250, opacity = 1}) => (
  <div style={{position: 'absolute', top, width: '100%', textAlign: 'center', opacity}}>
    <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 36, color, letterSpacing: 6}}>{label}</div>
    <div style={{fontFamily: DISPLAY, fontSize: 150, lineHeight: 1, color: '#fff', WebkitTextStroke: '6px #000', paintOrder: 'stroke fill',
      textShadow: `0 0 50px ${color}aa`, fontVariantNumeric: 'tabular-nums'}}>{value}</div>
  </div>
);

/* earthDive: { bigText?, bigOnWord? } — first-person plunge: rock rings rush outward, the hero tumbles in the middle,
   a depth counter spins up. Opens with a white "jump" flash for an instant hook. */
const EarthDive: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const bigAt = scene.bigOnWord ? wordFrame(captions, scene.bigOnWord as string, fps, dur * 0.6) : 1e9;
  const big = spring({frame: frame - bigAt, fps, config: {damping: 10, stiffness: 170}});
  const speed = 1 + frame / 18;
  const depth = Math.floor(6371 * Math.pow(Math.min(1, frame / Math.max(1, dur - 4)), 2));
  const rings = 22;
  const intro = interpolate(frame, [0, 2, 10], [1, 0.9, 0], clamp);
  return (
    <Shake at={0} amount={20}>
      <AbsoluteFill style={{background: '#020203'}} />
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        {new Array(rings).fill(0).map((_, i) => {
          const z = ((i / rings + (frame * 0.012 * speed)) % 1);
          const r = Math.pow(z, 2.4) * 1500 + 10;
          const t = (i + Math.floor(frame * 0.012 * speed * rings)) % 7;
          const col = ['#5a3a22', '#7a4a26', '#9c4a1f', '#c2562b', '#e0732a', '#7a4a26', '#4a2e1c'][t];
          return <ellipse key={i} cx={540 + Math.sin(frame / 20) * 10} cy={960} rx={r} ry={r * 1.05} fill="none" stroke={col} strokeWidth={6 + z * 60} opacity={0.3 + z * 0.7} />;
        })}
        {new Array(60).fill(0).map((_, i) => {
          const a = random(`da${i}`) * Math.PI * 2;
          const z = ((random(`dz${i}`) + frame * 0.02 * speed) % 1);
          const r = Math.pow(z, 2) * 1100;
          return <line key={`s${i}`} x1={540 + Math.cos(a) * r} y1={960 + Math.sin(a) * r} x2={540 + Math.cos(a) * (r + 40 + z * 120)} y2={960 + Math.sin(a) * (r + 40 + z * 120)}
            stroke="#ffd9a8" strokeWidth={2 + z * 3} opacity={z * 0.8} />;
        })}
      </svg>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 50%, rgba(255,170,90,0.25), transparent 35%)'}} />
      <div style={{position: 'absolute', inset: 0, rotate: `${frame * 4}deg`, transformOrigin: '540px 960px', scale: String(1 + Math.sin(frame / 6) * 0.03)}}>
        <Boy x={540} y={1060} height={220} stage="adult" pose="cheer" phase={frame / 3} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={1} />
      </div>
      <Readout label="DEPTH" value={`${depth.toLocaleString('en-US')} KM`} top={250} />
      {scene.bigText ? (
        <div style={{position: 'absolute', top: 1450, width: '100%', textAlign: 'center', opacity: frame >= bigAt ? 1 : 0, scale: String(1.6 - big * 0.6)}}>
          <span style={{fontFamily: DISPLAY, fontSize: 120, color: C.gold, WebkitTextStroke: '6px #000', paintOrder: 'stroke fill'}}>{scene.bigText as string}</span>
        </div>
      ) : null}
      <AbsoluteFill style={{background: '#fff', opacity: intro}} />
    </Shake>
  );
};

/* earthSection: { mode: 'fall'|'center'|'exit'|'swing'|'heat', label?, labelOnWord?, flipOnWord?, maxSpeed? } */
const R = 380, CX = 540, CY = 840;
const Planet: React.FC<{heat?: number}> = ({heat = 0}) => {
  const frame = useCurrentFrame();
  const pulse = 1 + heat * 0.06 * Math.sin(frame / 4);
  return (
    <svg width={1080} height={1920} style={{position: 'absolute'}}>
      <defs>
        <radialGradient id="ic"><stop offset="0" stopColor="#fff6c0" /><stop offset="1" stopColor="#ffcf3a" /></radialGradient>
      </defs>
      <circle cx={CX} cy={CY} r={R + 26} fill="#1d5fa8" opacity={0.25} />
      <circle cx={CX} cy={CY} r={R} fill="#5a3a22" />
      <circle cx={CX} cy={CY} r={R * 0.97} fill="#b14a22" />
      <circle cx={CX} cy={CY} r={R * 0.55 * pulse} fill="#f08a24" />
      <circle cx={CX} cy={CY} r={R * 0.19 * pulse} fill="url(#ic)" />
      {heat > 0 ? <circle cx={CX} cy={CY} r={R * 0.6} fill="none" stroke="#ffd35a" strokeWidth={30} opacity={0.25 * heat} style={{filter: 'blur(14px)'}} /> : null}
      {/* tunnel */}
      <rect x={CX - 14} y={CY - R - 30} width={28} height={2 * R + 60} fill="#0b0f18" opacity={0.85} />
      <rect x={CX - 14} y={CY - R - 30} width={28} height={2 * R + 60} fill="none" stroke="rgba(255,255,255,0.35)" strokeWidth={2} />
      {/* layer labels */}
      <g fontFamily="Inter" fontWeight={800} fontSize={24} fill="rgba(255,255,255,0.75)">
        <text x={CX + 200} y={CY - 230}>MANTLE</text>
        <text x={CX + 60} y={CY - 120}>OUTER CORE</text>
        <text x={CX + 30} y={CY + 10}>INNER</text>
      </g>
    </svg>
  );
};

const Traveller: React.FC<{y: number; flip?: boolean; glow?: string}> = ({y, flip, glow = C.cyan}) => (
  <div style={{position: 'absolute', inset: 0, rotate: flip ? '180deg' : '0deg', transformOrigin: `${CX}px ${y}px`}}>
    <div style={{position: 'absolute', left: CX - 26, top: y - 26, width: 52, height: 52, borderRadius: '50%', background: `radial-gradient(circle, ${glow}, transparent 70%)`}} />
    <Boy x={CX} y={y + 30} height={64} stage="adult" pose="cheer" skin="#05070c" rim={glow} glow={1} />
  </div>
);

const Arrow: React.FC<{x: number; y: number; angle: number; len?: number; color?: string; opacity?: number}> = ({x, y, angle, len = 110, color = C.gold, opacity = 1}) => (
  <svg width={1080} height={1920} style={{position: 'absolute', opacity}}>
    <g transform={`translate(${x} ${y}) rotate(${angle})`}>
      <line x1={0} y1={0} x2={len} y2={0} stroke={color} strokeWidth={12} strokeLinecap="round" />
      <path d={`M${len + 22} 0 L${len - 8} -20 L${len - 8} 20 Z`} fill={color} />
    </g>
  </svg>
);

const EarthSection: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'fall';
  const maxSpeed = (scene.maxSpeed as number) ?? 28000;
  const labelAt = scene.labelOnWord ? wordFrame(captions, scene.labelOnWord as string, fps, dur * 0.5) : dur * 0.5;
  const flipAt = scene.flipOnWord ? wordFrame(captions, scene.flipOnWord as string, fps, dur * 0.3) : dur * 0.3;
  const lab = spring({frame: frame - labelAt, fps, config: {damping: 12}});
  let theta = 0; // 0 = top surface, PI/2 = centre, PI = far side
  let speedTxt = '';
  let trail: number[] = [];
  if (mode === 'fall') {
    const p = interpolate(frame, [6, dur - 8], [0, 1], clamp);
    theta = p * (Math.PI / 2);
  } else if (mode === 'center') {
    theta = Math.PI / 2;
  } else if (mode === 'exit') {
    const p = interpolate(frame, [Math.max(4, flipAt - 6), dur - 8], [0, 1], clamp);
    theta = Math.PI / 2 + p * (Math.PI / 2);
  } else if (mode === 'swing') {
    theta = (frame / 26) * Math.PI;
    trail = [1, 2, 3, 4, 5, 6].map((k) => (frame - k * 1.5) / 26 * Math.PI);
  } else if (mode === 'heat') {
    theta = Math.PI / 2;
  }
  const yOf = (th: number) => CY - R * Math.cos(th);
  const y = yOf(theta);
  const v = Math.abs(Math.sin(theta)) * maxSpeed;
  speedTxt = `${Math.round(v / 100) * 100 > 0 ? (Math.round(v / 100) * 100).toLocaleString('en-US') : '0'}`;
  const gravityUp = mode === 'exit' ? frame >= flipAt : mode === 'swing' ? Math.cos(theta) < 0 : false;
  const bob = mode === 'center' ? Math.sin(frame / 8) * 10 : 0;
  return (
    <Shake at={mode === 'exit' ? flipAt : mode === 'heat' ? labelAt : 1e9} amount={14}>
      <Camera dur={dur} from={1.0} to={1.06}>
        <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, #0b1730 0%, #04060c 65%)'}} />
        {new Array(70).fill(0).map((_, i) => (
          <div key={i} style={{position: 'absolute', left: random(`st${i}`) * 1080, top: random(`sy${i}`) * 1920, width: 3, height: 3, borderRadius: 2, background: '#fff',
            opacity: 0.2 + 0.5 * Math.abs(Math.sin(frame / 20 + i))}} />
        ))}
        <Planet heat={mode === 'heat' ? interpolate(frame, [labelAt - 5, labelAt + 10], [0, 1], clamp) : 0} />
        {trail.map((th, k) => (
          <div key={k} style={{position: 'absolute', left: CX - 14, top: yOf(th) - 14, width: 28, height: 28, borderRadius: '50%', background: C.cyan, opacity: 0.35 - k * 0.05}} />
        ))}
        <Traveller y={y + bob} flip={gravityUp && mode !== 'center'} />
        {/* gravity arrows */}
        {mode === 'center' ? (
          new Array(8).fill(0).map((_, k) => (
            <Arrow key={k} x={CX + Math.cos((k / 8) * Math.PI * 2) * 70} y={CY + Math.sin((k / 8) * Math.PI * 2) * 70} angle={(k / 8) * 360} len={120}
              opacity={interpolate(frame, [labelAt - 10 + k * 2, labelAt + k * 2], [0, 1], clamp)} color={C.mint} />
          ))
        ) : mode !== 'heat' ? (
          <Arrow x={CX + 90} y={y} angle={gravityUp ? -90 : 90} len={100} color={gravityUp ? C.coral : C.gold} />
        ) : null}
        {mode !== 'heat' && mode !== 'center' ? <Readout label="SPEED (KM/H)" value={speedTxt} color={gravityUp ? C.coral : C.cyan} /> : null}
        {scene.label ? (
          <div style={{position: 'absolute', top: mode === 'center' || mode === 'heat' ? 270 : 1260 - 60, width: '100%', textAlign: 'center', opacity: lab, scale: String(0.7 + lab * 0.3)}}>
            <span style={{fontFamily: DISPLAY, fontSize: mode === 'center' || mode === 'heat' ? 130 : 84, color: mode === 'heat' ? '#ffb347' : C.mint,
              WebkitTextStroke: '6px #000', paintOrder: 'stroke fill'}}>{scene.label as string}</span>
          </div>
        ) : null}
        {mode === 'heat' && scene.subLabel ? (
          <div style={{position: 'absolute', top: 420, width: '100%', textAlign: 'center', opacity: lab, fontFamily: BODY, fontWeight: 800, fontSize: 46, color: C.ink}}>{scene.subLabel as string}</div>
        ) : null}
      </Camera>
    </Shake>
  );
};

export const EXPLAINER3_SCENES: Record<string, React.FC<SceneProps>> = {
  earthDive: EarthDive,
  earthSection: EarthSection,
};
