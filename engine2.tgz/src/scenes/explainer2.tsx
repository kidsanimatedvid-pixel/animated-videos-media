import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Explainer kit 2: brainScan (hex-cell brain that lights up by region) and energySplit (2% weight vs 20% energy). */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const C = {cyan: '#3fe0ff', coral: '#ff6b6b', mint: '#5dffb0', gold: '#ffcc4d', ink: '#e9f6ff'};

const Lab: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 40%, #0d2a4d 0%, #061325 55%, #03070f 100%)'}}>
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.18}}>
        {new Array(24).fill(0).map((_, i) => (
          <line key={`h${i}`} x1={0} x2={1080} y1={i * 80 + (frame % 80)} y2={i * 80 + (frame % 80)} stroke={C.cyan} strokeWidth={1} />
        ))}
      </svg>
    </AbsoluteFill>
  );
};

/* Side-view brain outline (front = left), in a 900×640 box. */
const BRAIN = 'M170 420 C90 380 70 260 140 190 C190 100 300 60 420 70 C520 40 650 60 730 120 C820 170 860 260 840 340 C860 400 820 460 760 470 C720 520 640 530 590 500 L560 560 C540 600 500 610 470 590 L470 520 C400 540 300 530 240 490 C200 470 180 450 170 420 Z';
const CEREB = 'M600 480 C640 470 720 470 760 470 C770 520 720 560 660 560 C620 560 590 530 600 480 Z';
type Region = 'frontal' | 'parietal' | 'occipital' | 'temporal' | 'cerebellum' | 'motor';
const REGION_COLOR: Record<Region, string> = {
  frontal: C.cyan, motor: C.mint, parietal: C.gold, occipital: '#b38cff', temporal: C.coral, cerebellum: '#ff9ad5',
};
const regionOf = (x: number, y: number): Region => {
  if (x > 590 && y > 455) return 'cerebellum';
  if (y > 330 && x > 250 && x < 620) return 'temporal';
  if (x < 360) return 'frontal';
  if (x < 470) return 'motor';
  if (x < 690) return 'parietal';
  return 'occipital';
};

const CELLS = (() => {
  const out: {x: number; y: number; r: Region; k: number}[] = [];
  const s = 34;
  let k = 0;
  for (let row = 0; row < 20; row++) {
    for (let col = 0; col < 28; col++) {
      const x = 60 + col * s + (row % 2) * (s / 2);
      const y = 50 + row * s * 0.87;
      out.push({x, y, r: regionOf(x, y), k: k++});
    }
  }
  return out;
})();

/* brainScan: { mode: 'ten'|'all', allOnWord?, labels?: [{text, region, onWord}], bigText?, bigOnWord? }
   'ten' = only a scattered 10% of cells glow; 'all' = starts at 10%, then every region lights up in a wave on allOnWord. */
const BrainScan: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'all';
  const allAt = mode === 'all' ? (scene.allOnWord ? wordFrame(captions, scene.allOnWord as string, fps, 15) : 10) : 1e9;
  const labels = (scene.labels as {text: string; region: Region; onWord?: string}[]) ?? [];
  const labelAts = labels.map((l, i) => (l.onWord ? wordFrame(captions, l.onWord, fps, 20 + i * 15) : 20 + i * 15));
  const bigAt = scene.bigOnWord ? wordFrame(captions, scene.bigOnWord as string, fps, dur * 0.4) : 1e9;
  const big = spring({frame: frame - bigAt, fps, config: {damping: 10, stiffness: 180}});
  const ox = 90, oy = 380, sc = 1.0;
  const anchor: Record<Region, [number, number]> = {
    frontal: [230, 250], motor: [410, 130], parietal: [600, 180], occipital: [790, 330], temporal: [440, 430], cerebellum: [680, 520],
  };
  return (
    <Shake at={Math.min(allAt, bigAt)} amount={12}>
      <Camera dur={dur} from={1.04} to={1.0}>
        <Lab />
        <svg width={1080} height={900} style={{position: 'absolute', left: ox - 60, top: oy, scale: String(sc)}} viewBox="0 0 1000 680">
          <defs>
            <clipPath id="brainClip"><path d={BRAIN} /><path d={CEREB} /></clipPath>
            <filter id="glw"><feGaussianBlur stdDeviation="6" /></filter>
          </defs>
          <path d={BRAIN} fill="#0a1b33" />
          <path d={CEREB} fill="#0a1b33" />
          <g clipPath="url(#brainClip)">
            {CELLS.map((c) => {
              const tenOn = random(`b10-${c.k}`) < 0.1;
              const wave = allAt + (c.x / 900) * 18 + random(`bw${c.k}`) * 6;
              const on = interpolate(frame, [wave, wave + 8], [0, 1], clamp);
              const flick = 0.6 + 0.4 * Math.sin(frame / 5 + c.k);
              const lit = Math.max(tenOn ? 0.9 * flick : 0, on * (0.65 + 0.35 * flick));
              const col = on > 0 ? REGION_COLOR[c.r] : C.cyan;
              return (
                <polygon key={c.k}
                  points={[0, 1, 2, 3, 4, 5].map((j) => `${c.x + 16 * Math.cos((Math.PI / 3) * j + Math.PI / 6)},${c.y + 16 * Math.sin((Math.PI / 3) * j + Math.PI / 6)}`).join(' ')}
                  fill={col} fillOpacity={0.06 + lit * 0.8} stroke={col} strokeOpacity={0.25 + lit * 0.5} strokeWidth={1.5} />
              );
            })}
          </g>
          <path d={BRAIN} fill="none" stroke={C.cyan} strokeWidth={5} strokeOpacity={0.9} />
          <path d={CEREB} fill="none" stroke={C.cyan} strokeWidth={4} strokeOpacity={0.9} />
          {/* folds */}
          <path d="M300 120 C320 200 280 260 330 330 M480 90 C470 170 520 220 490 300 M640 120 C600 190 660 250 620 320" stroke="#061325" strokeWidth={8} fill="none" opacity={0.7} />
          {labels.map((l, i) => {
            const s = spring({frame: frame - labelAts[i], fps, config: {damping: 12}});
            const [ax, ay] = anchor[l.region];
            return (
              <g key={i} opacity={s} transform={`translate(${ax} ${ay}) scale(${0.7 + s * 0.3})`}>
                <rect x={-120} y={-34} width={240} height={60} rx={30} fill="#000" fillOpacity={0.7} stroke={REGION_COLOR[l.region]} strokeWidth={4} />
                <text x={0} y={8} textAnchor="middle" fill="#fff" fontSize={30} fontFamily="Inter" fontWeight={800}>{l.text}</text>
              </g>
            );
          })}
        </svg>
        {scene.bigText ? (
          <div style={{position: 'absolute', top: 230, width: '100%', textAlign: 'center', opacity: frame >= bigAt ? 1 : 0, scale: String(1.6 - big * 0.6)}}>
            <span style={{fontFamily: DISPLAY, fontSize: 150, color: (scene.bigColor as string) ?? C.coral, WebkitTextStroke: '6px #000', paintOrder: 'stroke fill',
              textShadow: '0 0 60px rgba(255,107,107,0.6)'}}>{scene.bigText as string}</span>
          </div>
        ) : null}
      </Camera>
    </Shake>
  );
};

/* energySplit: { leftOnWord, rightOnWord } — two gauges: brain = 2% of body weight vs 20% of the body's energy. */
const EnergySplit: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lAt = scene.leftOnWord ? wordFrame(captions, scene.leftOnWord as string, fps, 10) : 10;
  const rAt = scene.rightOnWord ? wordFrame(captions, scene.rightOnWord as string, fps, dur * 0.55) : dur * 0.55;
  const bars = [
    {at: lAt, to: 2, label: 'OF YOUR WEIGHT', color: C.cyan, x: 150},
    {at: rAt, to: 20, label: 'OF YOUR ENERGY', color: C.coral, x: 600},
  ];
  const H = 680, top = 400;
  return (
    <Shake at={rAt} amount={14}>
      <Camera dur={dur} from={1.0} to={1.06}>
        <Lab />
        <div style={{position: 'absolute', top: 250, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 84, color: C.ink, letterSpacing: 2}}>YOUR BRAIN IS…</div>
        {bars.map((b, i) => {
          const p = interpolate(frame, [b.at, b.at + 22], [0, 1], {...clamp, easing: (t) => 1 - Math.pow(1 - t, 3)});
          const v = Math.round(b.to * p);
          const fill = (b.to / 25) * H * p;
          return (
            <React.Fragment key={i}>
              <div style={{position: 'absolute', left: b.x, top, width: 330, height: H, borderRadius: 30, border: `4px solid ${b.color}55`, background: '#0a1b33', overflow: 'hidden'}}>
                <div style={{position: 'absolute', bottom: 0, width: '100%', height: fill, background: `linear-gradient(180deg, ${b.color}, ${b.color}66)`, boxShadow: `0 0 50px ${b.color}`}} />
                {new Array(5).fill(0).map((_, k) => (
                  <div key={k} style={{position: 'absolute', left: 0, right: 0, bottom: (k + 1) * (H / 5), height: 2, background: 'rgba(255,255,255,0.08)'}} />
                ))}
              </div>
              <div style={{position: 'absolute', left: b.x, width: 330, top: top + H - fill - 170, textAlign: 'center', opacity: p > 0 ? 1 : 0,
                fontFamily: DISPLAY, fontSize: 150, color: '#fff', WebkitTextStroke: '6px #000', paintOrder: 'stroke fill'}}>{v}%</div>
              <div style={{position: 'absolute', left: b.x - 30, width: 390, top: top + H + 24, textAlign: 'center', opacity: p,
                fontFamily: BODY, fontWeight: 800, fontSize: 38, color: b.color}}>{b.label}</div>
            </React.Fragment>
          );
        })}
      </Camera>
    </Shake>
  );
};

export const EXPLAINER2_SCENES: Record<string, React.FC<SceneProps>> = {
  brainScan: BrainScan,
  energySplit: EnergySplit,
};
