import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Story scenes, set 11 (cartoon): bathTub, raffleDrum, academyGate, tunnelDebut, curlGoal. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Stamp: React.FC<{text: string; at: number; y: number; size?: number; rot?: number; color?: string}> = ({text, at: a, y, size = 160, rot = -8, color = '#ef4444'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 8, stiffness: 200}});
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(2.4 - s * 1.4), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color, border: `14px solid ${color}`, padding: '0 34px', borderRadius: 26, background: '#000000a8'}}>{text}</span>
    </div>
  );
};

/* Cartoon baby (original): big head, tiny fists, laughing. */
const Baby: React.FC<{x: number; y: number; s?: number; skin?: string; hair?: string}> = ({x, y, s = 1, skin = '#a8693f', hair = '#1a1a1a'}) => {
  const frame = useCurrentFrame();
  const kick = Math.sin(frame / 4) * 10;
  return (
    <svg width={360 * s} height={360 * s} viewBox="-180 -200 360 360" style={{position: 'absolute', left: x - 180 * s, top: y - 200 * s}}>
      <ellipse cx={-70} cy={60 + kick * 0.3} rx={34} ry={26} fill={skin} stroke={OL} strokeWidth={8} transform={`rotate(${-30 + kick} -70 60)`} />
      <ellipse cx={70} cy={60 - kick * 0.3} rx={34} ry={26} fill={skin} stroke={OL} strokeWidth={8} transform={`rotate(${30 - kick} 70 60)`} />
      <ellipse cx={0} cy={50} rx={78} ry={70} fill={skin} stroke={OL} strokeWidth={9} />
      <circle cx={0} cy={-70} r={98} fill={skin} stroke={OL} strokeWidth={9} />
      <path d="M-60 -150 Q-20 -185 10 -160 Q30 -190 60 -150" stroke={hair} strokeWidth={14} fill="none" strokeLinecap="round" />
      <circle cx={-36} cy={-80} r={14} fill={OL} /><circle cx={36} cy={-80} r={14} fill={OL} />
      <circle cx={-31} cy={-85} r={5} fill="#fff" /><circle cx={41} cy={-85} r={5} fill="#fff" />
      <circle cx={-62} cy={-45} r={16} fill="#ff8fa3" opacity={0.6} /><circle cx={62} cy={-45} r={16} fill="#ff8fa3" opacity={0.6} />
      <path d="M-34 -36 Q0 4 34 -36 Z" fill="#7a1f2b" stroke={OL} strokeWidth={7} strokeLinejoin="round" />
    </svg>
  );
};

/* bathTub: { year, tag, tagOnWord?, flashOnWord? } — HOOK. A dressing room; a baby laughs in a plastic tub full of bubbles with a rubber duck;
   two big grown-up arms (no face, plain sleeves) scrub with a sponge; camera flashes pop. */
const BathTub: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.5);
  const fAt = at(captions, scene.flashOnWord, fps, dur * 0.3);
  const flash = (k: number) => interpolate(frame - fAt - k * 9, [0, 2, 8], [0, 0.8, 0], clamp);
  const scrub = Math.sin(frame / 3.2) * 26;
  return (
    <Shake at={tAt} amount={14}>
      <Camera dur={dur} from={1.16} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e3a5f 0%, #274b74 60%, #16304e 100%)'}} />
        {/* lockers */}
        {new Array(6).fill(0).map((_, i) => (
          <div key={i} style={{position: 'absolute', left: 20 + i * 178, top: 120, width: 160, height: 860, background: '#36597f', border: `7px solid ${OL}`, borderRadius: 10}}>
            {[0, 1, 2].map((k) => <div key={k} style={{position: 'absolute', left: 24, right: 24, top: 40 + k * 18, height: 8, background: OL, opacity: 0.45, borderRadius: 4}} />)}
            <div style={{position: 'absolute', right: 20, top: 420, width: 16, height: 60, background: '#cbd5e1', border: `4px solid ${OL}`, borderRadius: 6}} />
          </div>
        ))}
        <div style={{position: 'absolute', left: 0, right: 0, top: 960, height: 34, background: '#a16207', borderTop: `8px solid ${OL}`, borderBottom: `8px solid ${OL}`}} />
        <div style={{position: 'absolute', left: 0, top: 1000, width: 1080, height: 920, background: 'repeating-linear-gradient(90deg, #cbd5e1 0 118px, #b6c2d1 118px 120px)'}} />
        {/* tub */}
        <svg width={900} height={520} viewBox="0 0 900 520" style={{position: 'absolute', left: 90, top: 880}}>
          <path d="M60 140 L840 140 L780 470 Q770 500 740 500 L160 500 Q130 500 120 470 Z" fill="#38bdf8" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
          <path d="M60 140 L840 140" stroke="#7dd3fc" strokeWidth={30} strokeLinecap="round" />
          <path d="M60 140 L840 140" stroke={OL} strokeWidth={10} strokeLinecap="round" opacity={0.0} />
        </svg>
        <Baby x={520} y={905} s={1.3} skin={(scene.babySkin as string) ?? '#a8693f'} />
        {/* bubbles over the tub rim */}
        {new Array(26).fill(0).map((_, i) => {
          const bx = 140 + random(`bx${i}`) * 800, r = 30 + random(`br${i}`) * 42;
          const bob = Math.sin(frame / 6 + i) * 6;
          return <div key={i} style={{position: 'absolute', left: bx - r, top: 990 + random(`by${i}`) * 50 - r + bob, width: r * 2, height: r * 2, borderRadius: '50%', background: 'radial-gradient(circle at 35% 30%, #ffffff, #e0f2fe 60%, #bae6fd)', border: `5px solid ${OL}`}} />;
        })}
        {/* floating bubbles */}
        {new Array(10).fill(0).map((_, i) => {
          const t = ((frame + i * 13) % 70) / 70;
          return <div key={i} style={{position: 'absolute', left: 160 + random(`fb${i}`) * 760 + Math.sin(frame / 8 + i) * 20, top: 960 - t * 700, width: 34, height: 34, borderRadius: '50%', border: '4px solid #e0f2fe', opacity: 1 - t}} />;
        })}
        {/* rubber duck */}
        <svg width={170} height={150} viewBox="0 0 170 150" style={{position: 'absolute', left: 760, top: 920 + Math.sin(frame / 7) * 8}}>
          <ellipse cx={80} cy={100} rx={70} ry={42} fill="#facc15" stroke={OL} strokeWidth={8} />
          <circle cx={110} cy={48} r={36} fill="#facc15" stroke={OL} strokeWidth={8} />
          <path d="M140 52 L166 58 L142 68 Z" fill="#fb923c" stroke={OL} strokeWidth={6} strokeLinejoin="round" />
          <circle cx={118} cy={40} r={7} fill={OL} />
        </svg>
        {/* big grown-up arms from the top, scrubbing (no face) */}
        {[-1, 1].map((side) => (
          <svg key={side} width={420} height={760} viewBox="0 0 420 760" style={{position: 'absolute', left: side < 0 ? 100 + scrub * 0.4 : 560 - scrub * 0.4, top: 360 + Math.abs(scrub) * 0.3, scale: side < 0 ? '1 1' : '-1 1'}}>
            <path d="M120 0 L240 0 L250 420 L150 440 Z" fill="#f8fafc" stroke={OL} strokeWidth={10} strokeLinejoin="round" />
            <path d="M150 420 Q160 600 230 650 L290 610 Q230 560 250 420 Z" fill="#c68642" stroke={OL} strokeWidth={10} strokeLinejoin="round" />
            <ellipse cx={265} cy={640} rx={52} ry={40} fill="#c68642" stroke={OL} strokeWidth={9} />
          </svg>
        ))}
        <div style={{position: 'absolute', left: 300 + scrub, top: 930, width: 120, height: 80, borderRadius: 22, background: '#fde047', border: `8px solid ${OL}`}} />
        {/* camera flashes */}
        <AbsoluteFill style={{background: '#fff', opacity: Math.max(flash(0), flash(1), flash(3))}} />
        <Tag text={(scene.year as string) ?? '2007'} at={-12} x={250} y={170} size={110} color="#fff" rot={-5} />
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={340} size={78} color="#ffcc4d" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* raffleDrum: { tag?, stampOnWord, stamp? } — a spinning raffle drum; one golden ticket shoots out and gets a WINNER stamp. */
const RaffleDrum: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sAt = at(captions, scene.stampOnWord, fps, dur * 0.5);
  const out = spring({frame: frame - (sAt - 14), fps, config: {damping: 11}});
  const spin = frame * 9;
  return (
    <Shake at={sAt} amount={16}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 40%, #7c3aed 0%, #3b0764 75%)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.14}}>
          {new Array(16).fill(0).map((_, i) => {
            const a = (i / 16) * Math.PI * 2 + frame / 60;
            return <path key={i} d={`M540 760 L${540 + Math.cos(a) * 1700} ${760 + Math.sin(a) * 1700} L${540 + Math.cos(a + 0.2) * 1700} ${760 + Math.sin(a + 0.2) * 1700} Z`} fill="#fff" />;
          })}
        </svg>
        {/* drum */}
        <svg width={700} height={700} viewBox="-350 -350 700 700" style={{position: 'absolute', left: 190, top: 640}}>
          <path d="M-200 300 L-120 60 M200 300 L120 60" stroke={OL} strokeWidth={22} strokeLinecap="round" />
          <path d="M-200 300 L-120 60 M200 300 L120 60" stroke="#94a3b8" strokeWidth={10} strokeLinecap="round" />
          <g transform={`rotate(${spin})`}>
            <polygon points="0,-230 199,-115 199,115 0,230 -199,115 -199,-115" fill="#fbbf24" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
            <polygon points="0,-170 147,-85 147,85 0,170 -147,85 -147,-85" fill="#fde68a" stroke={OL} strokeWidth={6} opacity={0.7} />
            {new Array(9).fill(0).map((_, i) => <rect key={i} x={-120 + (i % 3) * 80} y={-90 + Math.floor(i / 3) * 70} width={56} height={30} rx={5} fill={['#f472b6', '#60a5fa', '#4ade80'][i % 3]} stroke={OL} strokeWidth={4} transform={`rotate(${i * 37})`} />)}
          </g>
          <circle cx={0} cy={0} r={26} fill={OL} />
          <path d="M0 0 L250 -60" stroke={OL} strokeWidth={18} strokeLinecap="round" />
          <circle cx={250} cy={-60} r={22} fill="#ef4444" stroke={OL} strokeWidth={8} />
        </svg>
        {/* the winning ticket */}
        <div style={{position: 'absolute', left: 540 - 300, top: interpolate(out, [0, 1], [950, 270]), width: 600, height: 260, rotate: `${interpolate(out, [0, 1], [-40, -4])}deg`, scale: String(0.3 + out * 0.7),
          background: '#fef3c7', border: `10px solid ${OL}`, borderRadius: 22, boxShadow: `0 14px 0 ${OL}`, opacity: frame >= sAt - 14 ? 1 : 0}}>
          <div style={{position: 'absolute', left: 120, top: 0, bottom: 0, borderLeft: `8px dashed ${OL}`, opacity: 0.5}} />
          <div style={{position: 'absolute', left: 150, top: 40, fontFamily: DISPLAY, fontSize: 96, color: '#b45309'}}>RAFFLE</div>
          <div style={{position: 'absolute', left: 150, top: 150, fontFamily: BODY, fontWeight: 800, fontSize: 40, color: OL}}>{(scene.ticketText as string) ?? 'PHOTO WITH A STAR'}</div>
          <div style={{position: 'absolute', left: 20, top: 70, fontFamily: DISPLAY, fontSize: 90, color: '#b45309', rotate: '-90deg'}}>№1</div>
        </div>
        <Stamp text={(scene.stamp as string) ?? 'WINNER!'} at={sAt} y={560} size={150} rot={-10} color="#22c55e" />
        {scene.tag ? <Tag text={scene.tag as string} at={6} y={170} size={72} color="#fff" rot={-2} /> : null}
      </Camera>
    </Shake>
  );
};

/* academyGate: { age, sign?, openOnWord? } — huge iron gates swing open; light floods out; a small boy with a ball walks in. */
const AcademyGate: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const oAt = at(captions, scene.openOnWord, fps, dur * 0.3);
  const open = interpolate(frame, [oAt, oAt + 24], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const walk = interpolate(frame, [oAt + 6, dur], [0, 1], clamp);
  return (
    <Camera dur={dur} from={1.0} to={1.12} panY={-30}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #0f172a 0%, #1e293b 60%, #334155 100%)'}} />
      {/* the glow behind the gate */}
      <div style={{position: 'absolute', left: 190, top: 440, width: 700, height: 840, background: 'radial-gradient(ellipse at 50% 60%, #fff7d6 0%, #fde68a 35%, #f59e0b00 75%)', opacity: 0.2 + open * 0.8}} />
      {new Array(14).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: 540 + (random(`gl${i}`) - 0.5) * 600, top: 1200 - ((frame * 3 + i * 60) % 700), width: 10, height: 10, borderRadius: 5, background: '#fde68a', opacity: open * 0.8}} />)}
      {/* wall + arch */}
      <div style={{position: 'absolute', left: 0, top: 380, width: 1080, height: 920, background: 'repeating-linear-gradient(0deg, #78350f 0 58px, #92400e 58px 62px)', clipPath: 'polygon(0 0, 100% 0, 100% 100%, 82% 100%, 82% 22%, 18% 22%, 18% 100%, 0 100%)', borderTop: `10px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 170, top: 330, width: 740, height: 120, background: '#b45309', border: `9px solid ${OL}`, borderRadius: 20, textAlign: 'center'}}>
        <span style={{fontFamily: DISPLAY, fontSize: 80, color: '#fde68a', WebkitTextStroke: `5px ${OL}`, paintOrder: 'stroke fill', lineHeight: '110px'}}>{(scene.sign as string) ?? 'ACADEMY'}</span>
      </div>
      {/* gates */}
      {[-1, 1].map((side) => (
        <div key={side} style={{position: 'absolute', left: side < 0 ? 194 : 540, top: 580, width: 346, height: 720, transformOrigin: side < 0 ? '0% 50%' : '100% 50%',
          transform: `perspective(1400px) rotateY(${side * -open * 78}deg)`}}>
          <svg width={346} height={720} viewBox="0 0 346 720">
            <rect x={6} y={6} width={334} height={708} fill="none" stroke={OL} strokeWidth={16} />
            {new Array(7).fill(0).map((_, i) => <line key={i} x1={30 + i * 48} y1={10} x2={30 + i * 48} y2={710} stroke="#475569" strokeWidth={14} />)}
            {new Array(7).fill(0).map((_, i) => <line key={`o${i}`} x1={30 + i * 48} y1={10} x2={30 + i * 48} y2={710} stroke={OL} strokeWidth={4} opacity={0.6} />)}
            <line x1={6} y1={240} x2={340} y2={240} stroke="#475569" strokeWidth={18} />
            <line x1={6} y1={480} x2={340} y2={480} stroke="#475569" strokeWidth={18} />
          </svg>
        </div>
      ))}
      <div style={{position: 'absolute', left: 0, top: 1300, width: 1080, height: 700, background: '#14532d', borderTop: `10px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 400, top: 1300, width: 280, height: 700, background: '#d6d3d1', clipPath: 'polygon(30% 0, 70% 0, 100% 100%, 0 100%)', opacity: 0.6}} />
      <div style={{scale: String(1 - walk * 0.45), transformOrigin: '540px 1300px', translate: `0px ${-walk * 40}px`}}>
        <Boy x={520} y={1420} height={420} stage="child" pose={walk > 0 ? 'run' : 'stand'} phase={frame / 3} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="laugh" />
        <div style={{position: 'absolute', left: 600, top: 1360 + Math.abs(Math.sin(frame / 3)) * -24, width: 56, height: 56, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #d4d4d4)', border: `5px solid ${OL}`}} />
      </div>
      <Tag text={(scene.age as string) ?? 'AGE 7'} at={4} x={260} y={190} size={110} color="#fff" rot={-5} />
    </Camera>
  );
};

/* tunnelDebut: { age, stamp, stampOnWord? } — a stadium tunnel; floodlights at the end; a skinny teen runs out; a giant age number + DEBUT stamp. */
const TunnelDebut: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sAt = at(captions, scene.stampOnWord, fps, dur * 0.5);
  const ageS = spring({frame: frame - 2, fps, config: {damping: 9, stiffness: 170}});
  const run = interpolate(frame, [0, dur], [0, 1], clamp);
  return (
    <Shake at={sAt} amount={18}>
      <AbsoluteFill style={{background: '#020617'}} />
      {/* tunnel rings */}
      {new Array(9).fill(0).map((_, i) => {
        const k = ((i + frame / 14) % 9) / 9;
        const s = 0.15 + k * 1.6;
        return <div key={i} style={{position: 'absolute', left: 540 - 520 * s, top: 900 - 700 * s, width: 1040 * s, height: 1400 * s, borderRadius: `${520 * s}px ${520 * s}px 0 0`, border: `${6 + k * 22}px solid #334155`, opacity: k}} />;
      })}
      <div style={{position: 'absolute', left: 390, top: 650, width: 300, height: 420, borderRadius: '150px 150px 0 0', background: 'radial-gradient(ellipse at 50% 70%, #ffffff 0%, #bbf7d0 45%, #22c55e 100%)', boxShadow: '0 0 160px 60px rgba(255,255,255,0.5)'}} />
      <div style={{position: 'absolute', left: 0, top: 1300, width: 1080, height: 700, background: 'linear-gradient(180deg, #1e293b, #0f172a)', borderTop: `10px solid ${OL}`}} />
      <div style={{scale: String(1.25 - run * 0.55), transformOrigin: '540px 1350px'}}>
        <Boy x={540} y={1420} height={620} stage="teen" pose="run" phase={frame / 2.4} skin={sb.character.palette.skin} rim="#bbf7d0" glow={0.9} mood="determined" />
      </div>
      <div style={{position: 'absolute', top: 120, width: '100%', textAlign: 'center', scale: String(0.4 + ageS * 0.6), opacity: ageS}}>
        <span style={{fontFamily: DISPLAY, fontSize: 330, lineHeight: 1, color: '#ffcc4d', WebkitTextStroke: `14px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.age as string) ?? '15'}</span>
        <div style={{fontFamily: DISPLAY, fontSize: 70, color: '#fff', WebkitTextStroke: `6px ${OL}`, paintOrder: 'stroke fill', marginTop: -20}}>YEARS OLD</div>
      </div>
      <Stamp text={(scene.stamp as string) ?? 'FIRST-TEAM DEBUT'} at={sAt} y={640} size={104} rot={-7} color="#22c55e" />
    </Shake>
  );
};

/* curlGoal: { age, tag, tagOnWord?, shotOnWord? } — a curling shot from outside the box bends into the top corner; net bulges; giant age. */
const CurlGoal: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const shot = at(captions, scene.shotOnWord, fps, 4);
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.6);
  const p = interpolate(frame, [shot, shot + 22], [0, 1], {...clamp, easing: Easing.inOut(Easing.quad)});
  const hit = shot + 22;
  const bulge = interpolate(frame, [hit, hit + 5, hit + 22], [0, 1, 0.4], clamp);
  const flash = interpolate(frame, [hit, hit + 2, hit + 10], [0, 0.75, 0], clamp);
  // quadratic bezier: start bottom-left, control far right, end top-right corner of goal
  const P0 = {x: 200, y: 1240}, P1 = {x: 1150, y: 780}, P2 = {x: 790, y: 470};
  const bx = (1 - p) ** 2 * P0.x + 2 * (1 - p) * p * P1.x + p * p * P2.x;
  const by = (1 - p) ** 2 * P0.y + 2 * (1 - p) * p * P1.y + p * p * P2.y;
  const ageS = spring({frame: frame - hit, fps, config: {damping: 9, stiffness: 170}});
  return (
    <Shake at={hit} amount={24}>
      <Camera dur={dur} from={1.04} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0b1220 0%, #1e3a8a 45%, #15803d 46%, #166534 100%)'}} />
        {/* crowd dots */}
        {new Array(90).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`cx${i}`) * 1080, top: 120 + random(`cy${i}`) * 230, width: 14, height: 14, borderRadius: 7, background: ['#f8fafc', '#fde047', '#ef4444', '#60a5fa'][i % 4], opacity: 0.5 + (frame > hit ? Math.abs(Math.sin(frame / 3 + i)) * 0.5 : 0)}} />)}
        {/* goal */}
        <svg width={760} height={420} viewBox="0 0 760 420" style={{position: 'absolute', left: 160, top: 420}}>
          {new Array(16).fill(0).map((_, i) => <line key={i} x1={30 + i * 46} y1={20} x2={30 + i * 46 + (i > 11 ? bulge * 30 : 0)} y2={400} stroke="#e2e8f0" strokeWidth={3} opacity={0.6} />)}
          {new Array(8).fill(0).map((_, i) => <line key={`h${i}`} x1={20} y1={30 + i * 50} x2={740} y2={30 + i * 50 - (i < 3 ? bulge * 20 : 0)} stroke="#e2e8f0" strokeWidth={3} opacity={0.6} />)}
          <path d="M20 410 L20 20 L740 20 L740 410" stroke="#fff" strokeWidth={22} fill="none" strokeLinejoin="round" />
          <path d="M20 410 L20 20 L740 20 L740 410" stroke={OL} strokeWidth={6} fill="none" opacity={0.5} />
        </svg>
        {/* keeper diving the wrong way-ish */}
        <div style={{rotate: `${interpolate(frame, [shot + 6, shot + 20], [0, -70], clamp)}deg`, transformOrigin: '540px 840px'}}>
          <Boy x={540} y={860} height={360} stage="adult" skin="#keeper-2" rim="#fff" glow={0} mood="shock" />
        </div>
        {/* trail + ball */}
        {new Array(10).fill(0).map((_, i) => {
          const q = Math.max(0, p - i * 0.03);
          const tx = (1 - q) ** 2 * P0.x + 2 * (1 - q) * q * P1.x + q * q * P2.x, ty = (1 - q) ** 2 * P0.y + 2 * (1 - q) * q * P1.y + q * q * P2.y;
          return <div key={i} style={{position: 'absolute', left: tx - 22, top: ty - 22, width: 44, height: 44, borderRadius: 22, background: '#ffcc4d', opacity: frame >= shot && frame < hit + 6 ? 0.5 - i * 0.05 : 0}} />;
        })}
        <div style={{position: 'absolute', left: bx - 34, top: by - 34, width: 68, height: 68, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #d4d4d4)', border: `6px solid ${OL}`, rotate: `${frame * 25}deg`}} />
        {/* shooter from behind */}
        <Boy x={170} y={1440} height={520} stage="teen" pose={frame < shot + 6 ? 'kick' : 'cheer'} phase={frame / 4} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.4} mood="laugh" />
        <div style={{position: 'absolute', right: 160, top: 1000, textAlign: 'center', scale: String(0.3 + ageS * 0.7), opacity: frame >= hit ? 1 : 0}}>
          <span style={{fontFamily: DISPLAY, fontSize: 300, lineHeight: 1, color: '#ffcc4d', WebkitTextStroke: `14px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.age as string) ?? '16'}</span>
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={190} size={78} color="#ffcc4d" rot={-3} /> : null}
        <AbsoluteFill style={{background: '#fff', opacity: flash}} />
      </Camera>
    </Shake>
  );
};

export const STORY11_SCENES: Record<string, React.FC<SceneProps>> = {
  bathTub: BathTub,
  raffleDrum: RaffleDrum,
  academyGate: AcademyGate,
  tunnelDebut: TunnelDebut,
  curlGoal: CurlGoal,
};
