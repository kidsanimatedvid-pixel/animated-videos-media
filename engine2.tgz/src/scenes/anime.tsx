import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Character, type Expression, type Look} from '../anime/Character';
import {Boy} from '../components/Boy';
import {Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Anime motion-comic scenes. Cast looks live in storyboard.cast[name].look. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
type Cast = Record<string, {label?: string; color?: string; voice?: string; look?: Look}>;
const castOf = (sb: SceneProps['sb']) => ((sb as unknown as {cast?: Cast}).cast ?? {});

/* ---------- backgrounds ---------- */
export const Background: React.FC<{kind: string; frame: number}> = ({kind, frame}) => {
  if (kind === 'rooftop') {
    return (
      <AbsoluteFill>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #3b1d5a 0%, #c2457a 38%, #ff9a52 62%, #ffd27a 75%)'}} />
        <div style={{position: 'absolute', left: 640, top: 760, width: 300, height: 300, borderRadius: '50%', background: '#fff1c4', boxShadow: '0 0 200px 80px rgba(255,200,120,0.6)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          {/* far city */}
          {new Array(14).fill(0).map((_, i) => {
            const w = 60 + random(`fc${i}`) * 90, h = 160 + random(`fh${i}`) * 260;
            return <rect key={i} x={i * 80 - 20} y={1080 - h} width={w} height={h + 900} fill="#6a2f5c" opacity={0.75} />;
          })}
          {/* domes + minaret */}
          <circle cx={230} cy={1000} r={70} fill="#5a2550" />
          <rect x={860} y={760} width={34} height={320} fill="#5a2550" />
          <circle cx={877} cy={760} r={22} fill="#5a2550" />
          {/* near rooftops */}
          <rect x={0} y={1120} width={1080} height={800} fill="#2a1430" />
          <rect x={60} y={1010} width={140} height={110} fill="#2a1430" />
          <ellipse cx={130} cy={1010} rx={74} ry={18} fill="#3a1c40" />
          <path d="M860 1060 l40 -60 l40 60 Z" fill="#2a1430" />
          <line x1={880} y1={1000} x2={880} y2={1120} stroke="#2a1430" strokeWidth={8} />
          {/* laundry line */}
          <path d="M0 980 Q540 1030 1080 960" stroke="#1a0c20" strokeWidth={4} fill="none" />
          {[160, 380, 610, 820].map((x, i) => (
            <rect key={i} x={x} y={995 + Math.sin(frame / 12 + i) * 4} width={70} height={90} fill={['#ff6b6b', '#ffe08a', '#7fd6ff', '#fff'][i]} opacity={0.85}
              transform={`rotate(${Math.sin(frame / 15 + i) * 4} ${x + 35} 995)`} />
          ))}
        </svg>
      </AbsoluteFill>
    );
  }
  if (kind === 'night') {
    return (
      <AbsoluteFill>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #050816 0%, #0d1a3a 60%, #1a2a50 100%)'}} />
        <div style={{position: 'absolute', left: 120, top: 980, width: 840, height: 300, borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(200,230,255,0.5), transparent 70%)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          <path d="M140 1180 Q540 980 940 1180 Z" fill="#101830" />
          {[260, 820].map((x, i) => <g key={i}><rect x={x} y={860} width={14} height={300} fill="#101830" /><rect x={x - 40} y={850} width={94} height={30} fill="#e8f4ff" /></g>)}
          <rect x={0} y={1180} width={1080} height={800} fill="#070b18" />
        </svg>
        {new Array(110).fill(0).map((_, i) => {
          const x = random(`rnx${i}`) * 1200 - 60, y = ((random(`rny${i}`) * 2100 + frame * 40) % 2100) - 100;
          return <div key={i} style={{position: 'absolute', left: x, top: y, width: 3, height: 50, background: 'rgba(180,210,255,0.4)', rotate: '14deg'}} />;
        })}
      </AbsoluteFill>
    );
  }
  if (kind === 'stairs') {
    return (
      <AbsoluteFill>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #4a2a1a 0%, #8a4a26 60%, #3a2014 100%)'}} />
        <div style={{position: 'absolute', left: 380, top: 300, width: 320, height: 760, background: 'linear-gradient(180deg,#ffd9a0,#ff9a52)', borderRadius: '160px 160px 0 0',
          boxShadow: '0 0 160px 40px rgba(255,180,100,0.5)', border: '18px solid #2a160a'}} />
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          {new Array(8).fill(0).map((_, i) => <rect key={i} x={0} y={1100 + i * 60} width={1080} height={60} fill={i % 2 ? '#2a160a' : '#3a2014'} />)}
        </svg>
      </AbsoluteFill>
    );
  }
  if (kind === 'trial') {
    return (
      <AbsoluteFill>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #4aa8ff 0%, #a8dcff 50%, #e8f6ff 62%)'}} />
        {[[180, 300], [700, 420]].map(([x, y], i) => (
          <div key={i} style={{position: 'absolute', left: x + Math.sin(frame / 80 + i) * 20, top: y, width: 260, height: 70, borderRadius: 40, background: '#fff', opacity: 0.9,
            boxShadow: '60px -20px 0 -6px #fff, 120px 0 0 -10px #fff'}} />
        ))}
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          <rect x={0} y={1000} width={1080} height={920} fill="#2f9e4a" />
          {new Array(6).fill(0).map((_, i) => <rect key={i} x={0} y={1000 + i * 150} width={1080} height={75} fill="#37b056" />)}
          {new Array(24).fill(0).map((_, i) => <line key={i} x1={i * 46} y1={900} x2={i * 46} y2={1000} stroke="#5a6a7a" strokeWidth={4} />)}
          <line x1={0} y1={910} x2={1080} y2={910} stroke="#5a6a7a" strokeWidth={6} />
          {[200, 480, 760].map((x, i) => <path key={i} d={`M${x} 1100 l24 -50 l24 50 Z`} fill="#ff8a1e" />)}
        </svg>
      </AbsoluteFill>
    );
  }
  // 'speed' focus lines (default)
  return (
    <AbsoluteFill style={{background: '#fff'}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        {new Array(70).fill(0).map((_, i) => {
          const a = (i / 70) * Math.PI * 2 + random(`sl${i}`) * 0.05;
          const r0 = 380 + random(`sr${i}-${Math.floor(frame / 2)}`) * 160;
          const w = 0.012 + random(`sw${i}`) * 0.02;
          const p = (ang: number, r: number) => `${540 + Math.cos(ang) * r} ${960 + Math.sin(ang) * r}`;
          return <path key={i} d={`M${p(a - w, 1800)} L${p(a, r0)} L${p(a + w, 1800)} Z`} fill="#111" />;
        })}
      </svg>
    </AbsoluteFill>
  );
};

const Sparkles: React.FC<{frame: number; color?: string}> = ({frame, color = '#fff6c4'}) => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    {new Array(14).fill(0).map((_, i) => {
      const t = (frame / 20 + random(`sp${i}`)) % 1;
      const s = Math.sin(t * Math.PI) * (20 + random(`ss${i}`) * 30);
      return <div key={i} style={{position: 'absolute', left: random(`spx${i}`) * 1000 + 40, top: random(`spy${i}`) * 900 + 200, width: s, height: s, rotate: '45deg',
        background: color, clipPath: 'polygon(50% 0, 60% 40%, 100% 50%, 60% 60%, 50% 100%, 40% 60%, 0 50%, 40% 40%)', opacity: 0.9}} />;
    })}
  </AbsoluteFill>
);

/* bust: { speaker, expression, bg, side?, zoomFrom?, zoomTo?, fx?: string[], other?: {who, expression, side},
          exprAt?: [{onWord, expression}] , lookX? } */
const Bust: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur, mouth}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cast = castOf(sb);
  const who = scene.speaker as string;
  const look = cast[who]?.look;
  let expression = (scene.expression as Expression) ?? 'neutral';
  ((scene.exprAt as {onWord: string; expression: Expression}[]) ?? []).forEach((e) => {
    if (frame >= wordFrame(captions, e.onWord, fps, 99999)) expression = e.expression;
  });
  const m = mouth?.[frame] ?? 0;
  const blink = frame % 95 > 90;
  const side = (scene.side as string) ?? 'center';
  const cx = side === 'left' ? 400 : side === 'right' ? 680 : 540;
  const z = interpolate(frame, [0, dur], [(scene.zoomFrom as number) ?? 1.0, (scene.zoomTo as number) ?? 1.08], clamp);
  const fx = (scene.fx as string[]) ?? [];
  const enter = spring({frame, fps, config: {damping: 15}});
  const other = scene.other as {who: string; expression?: Expression; side?: string} | undefined;
  const bob = Math.sin(frame / 18) * 4 + m * 5;
  const shockAt = fx.includes('shock') ? (scene.shockOnWord ? wordFrame(captions, scene.shockOnWord as string, fps, 0) : 0) : -1;
  const flash = shockAt >= 0 ? interpolate(frame - shockAt, [0, 2, 10], [0, 0.9, 0], clamp) : 0;
  return (
    <Shake at={shockAt >= 0 ? shockAt : 99999} amount={22}>
      <AbsoluteFill style={{scale: String(z)}}>
        <Background kind={(scene.bg as string) ?? 'rooftop'} frame={frame} />
        {fx.includes('speedlines') && <AbsoluteFill style={{opacity: 0.35, mixBlendMode: 'multiply'}}><Background kind="speed" frame={frame} /></AbsoluteFill>}
        {fx.includes('redglow') && <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 55%, rgba(255,60,40,0.45), transparent 60%)'}} />}
        {other && cast[other.who]?.look ? (
          <Character look={cast[other.who].look!} expression={other.expression ?? 'neutral'} x={other.side === 'left' ? 230 : 860} y={1150} scale={0.72} dim={0.55}
            blink={(frame + 40) % 110 > 105} />
        ) : null}
        {look ? (
          <div style={{translate: `${(1 - enter) * (side === 'left' ? -200 : side === 'right' ? 200 : 0)}px ${bob}px`}}>
            <Character look={look} expression={expression} mouth={m} blink={blink} lookX={(scene.lookX as number) ?? 0} x={cx} y={1370} scale={1.2} />
          </div>
        ) : null}
        {fx.includes('sparkle') && <Sparkles frame={frame} />}
      </AbsoluteFill>
      {fx.includes('rain') && <AbsoluteFill>{new Array(80).fill(0).map((_, i) => {
        const x = random(`brx${i}`) * 1200 - 60, y = ((random(`bry${i}`) * 2100 + frame * 44) % 2100) - 100;
        return <div key={i} style={{position: 'absolute', left: x, top: y, width: 3, height: 54, background: 'rgba(190,215,255,0.45)', rotate: '14deg'}} />;
      })}</AbsoluteFill>}
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </Shake>
  );
};

/* action: { impactOnWord?, sfxText?, pose?: 'run' | 'kick', color? } — focus lines, hero in motion, ball trail, impact frame. */
const Action: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = scene.impactOnWord ? wordFrame(captions, scene.impactOnWord as string, fps, Math.round(dur * 0.6)) : Math.round(dur * 0.6);
  const after = frame >= at;
  const inv = after && frame - at < 4; // inverted impact frame
  const col = (scene.color as string) ?? '#ff3b30';
  const txt = spring({frame: frame - at, fps, config: {damping: 8, stiffness: 220}});
  const dribble = Math.sin(frame / 3);
  return (
    <Shake at={at} amount={34}>
      <AbsoluteFill style={{filter: inv ? 'invert(1)' : undefined}}>
        <Background kind="speed" frame={frame} />
        <AbsoluteFill style={{background: `radial-gradient(circle at 50% 50%, ${col}55, transparent 55%)`}} />
        {/* defenders whooshing past */}
        {[0, 1, 2].map((i) => {
          const x = ((frame * 22 + i * 420) % 1500) - 300;
          return <div key={i} style={{opacity: 0.55, filter: 'blur(3px)'}}><Boy x={1080 - x} y={1350 + i * 30} height={420} stage="teen" pose="run" phase={frame / 2 + i} skin="#333" rim="#777" glow={0} /></div>;
        })}
        <Boy x={520} y={1380} height={640} stage="child" hair="short" pose={(scene.pose as 'run' | 'kick') ?? 'run'} phase={frame / 2.2} skin="#111" rim={col} glow={1} />
        {/* ball + trail */}
        {new Array(6).fill(0).map((_, i) => (
          <div key={i} style={{position: 'absolute', left: 640 - i * 40 + dribble * 20, top: 1290 - Math.abs(dribble) * 60, width: 80, height: 80, borderRadius: '50%',
            background: i === 0 ? 'radial-gradient(circle at 35% 30%, #fff, #bbb 60%, #555)' : col, opacity: i === 0 ? 1 : 0.18 * (6 - i)}} />
        ))}
        {after && (
          <div style={{position: 'absolute', top: 300, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 230, color: '#fff', rotate: '-8deg',
            WebkitTextStroke: '14px #111', paintOrder: 'stroke fill', scale: String(interpolate(txt, [0, 1], [2.4, 1])), opacity: txt,
            textShadow: `10px 10px 0 ${col}`}}>{(scene.sfxText as string) ?? 'SWOOSH!'}</div>
        )}
      </AbsoluteFill>
    </Shake>
  );
};

/* establishing: { bg, title?, subtitle? } — wide shot with kids playing on the roofs + episode title. */
const Establishing: React.FC<SceneProps> = ({scene, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - 8, fps, config: {damping: 13}});
  const ball = Math.abs(Math.sin(frame / 8));
  return (
    <AbsoluteFill style={{scale: String(interpolate(frame, [0, dur], [1.15, 1.0], clamp))}}>
      <Background kind={(scene.bg as string) ?? 'rooftop'} frame={frame} />
      {[0, 1, 2, 3].map((i) => (
        <Boy key={i} x={260 + i * 170} y={1120} height={200} stage="child" pose="run" phase={frame / 3 + i * 1.3} flip={i % 2 === 1} skin="#1a0c20" rim="#ffb3c8" glow={0.4} />
      ))}
      <div style={{position: 'absolute', left: 520, top: 1060 - ball * 160, width: 34, height: 34, borderRadius: '50%', background: '#fff'}} />
      {scene.title ? (
        <div style={{position: 'absolute', top: 300, width: '100%', textAlign: 'center', opacity: s, translate: `0px ${(1 - s) * 60}px`}}>
          <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 44, letterSpacing: 12, color: '#fff', textShadow: '0 4px 20px rgba(0,0,0,0.6)'}}>{String(scene.subtitle ?? '')}</div>
          <div style={{fontFamily: DISPLAY, fontSize: 150, lineHeight: 1.05, color: '#fff', WebkitTextStroke: '8px #2a1430', paintOrder: 'stroke fill',
            textShadow: '8px 8px 0 #ff6b6b'}}>{String(scene.title)}</div>
        </div>
      ) : null}
    </AbsoluteFill>
  );
};

/* bootTear: { tearOnWord, freezeOnWord, next } — close-up strike: the old boot's sole rips off,
   then the frame freezes (sepia) into a TO BE CONTINUED card. */
const BootTear: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tear = scene.tearOnWord ? wordFrame(captions, scene.tearOnWord as string, fps, Math.round(dur * 0.3)) : Math.round(dur * 0.3);
  const freeze = scene.freezeOnWord ? wordFrame(captions, scene.freezeOnWord as string, fps, Math.round(dur * 0.55)) : Math.round(dur * 0.55);
  const f = Math.min(frame, freeze); // everything stops at the freeze
  const swing = interpolate(f, [0, tear], [-40, 0], {...clamp, easing: Easing.in(Easing.cubic)});
  const rip = interpolate(f, [tear, tear + 10], [0, 1], clamp);
  const ballX = interpolate(f, [tear, freeze], [0, 110], clamp);
  const frozen = frame >= freeze;
  const card = spring({frame: frame - freeze - 6, fps, config: {damping: 13}});
  const flash = interpolate(frame - tear, [0, 2, 8], [0, 1, 0], clamp);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{filter: frozen ? 'sepia(0.85) contrast(1.15) brightness(0.9)' : undefined}}>
        <Background kind="speed" frame={f} />
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 50%, rgba(255,60,40,0.4), transparent 60%)'}} />
        {/* leg + old boot (close-up) */}
        <div style={{position: 'absolute', left: 120, top: 520, width: 700, height: 700, transformOrigin: '20% 0%', rotate: `${swing}deg`}}>
          <div style={{position: 'absolute', left: 140, top: 0, width: 150, height: 420, background: '#2a2f4a', border: '8px solid #111', borderRadius: 30}} />
          {/* boot upper */}
          <div style={{position: 'absolute', left: 90, top: 380, width: 420, height: 170, background: '#5a3a22', border: '9px solid #111', borderRadius: '40px 120px 60px 30px'}}>
            {/* tape patches */}
            <div style={{position: 'absolute', left: 170, top: 30, width: 120, height: 38, background: '#c9c2b2', rotate: '-8deg', border: '4px solid #111'}} />
            <div style={{position: 'absolute', left: 60, top: 90, width: 90, height: 30, background: '#c9c2b2', rotate: '12deg', border: '4px solid #111'}} />
          </div>
          {/* sole: rips away */}
          <div style={{position: 'absolute', left: 90, top: 540, width: 430, height: 46, background: '#1a1a1a', border: '8px solid #111', borderRadius: 20,
            transformOrigin: '0% 50%', rotate: `${rip * 38}deg`, translate: `${rip * 60}px ${rip * 90}px`}} />
          {rip > 0 && new Array(8).fill(0).map((_, i) => (
            <div key={i} style={{position: 'absolute', left: 300 + random(`tp${i}`) * 200, top: 540 + rip * (40 + random(`ty${i}`) * 200), width: 22, height: 10, background: '#111',
              rotate: `${random(`tr${i}`) * 180}deg`, opacity: 1 - rip * 0.3}} />
          ))}
        </div>
        {/* ball */}
        <div style={{position: 'absolute', left: 600 + ballX, top: 860 - ballX * 0.9, width: 170, height: 170, borderRadius: '50%',
          background: 'radial-gradient(circle at 35% 30%, #fff, #bbb 60%, #555)', border: '8px solid #111', rotate: `${f * 20}deg`}} />
        {rip > 0 && !frozen && (
          <div style={{position: 'absolute', top: 260, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 250, color: '#fff', rotate: '6deg',
            WebkitTextStroke: '14px #111', paintOrder: 'stroke fill', textShadow: '10px 10px 0 #ff3b30'}}>RRRIP!</div>
        )}
      </AbsoluteFill>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
      {frozen && (
        <>
          <AbsoluteFill style={{backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.12) 0 2px, transparent 2px 6px)'}} />
          <div style={{position: 'absolute', left: 60, top: 1040, opacity: card, translate: `${(1 - card) * -300}px 0px`}}>
            <div style={{fontFamily: DISPLAY, fontSize: 104, color: '#fff', background: '#111', padding: '10px 36px', border: '6px solid #fff', rotate: '-3deg',
              boxShadow: '10px 10px 0 #ff3b30'}}>TO BE CONTINUED ▶</div>
          </div>
          <div style={{position: 'absolute', left: 0, right: 0, top: 1240, textAlign: 'center', opacity: card}}>
            <span style={{fontFamily: BODY, fontWeight: 800, fontSize: 46, color: '#000', background: sb.palette.gold, padding: '14px 36px', borderRadius: 50}}>
              {(scene.next as string) ?? 'EPISODE 2 · TOMORROW'}
            </span>
          </div>
        </>
      )}
    </AbsoluteFill>
  );
};

export const ANIME_SCENES: Record<string, React.FC<SceneProps>> = {
  bust: Bust,
  action: Action,
  establishing: Establishing,
  bootTear: BootTear,
};
