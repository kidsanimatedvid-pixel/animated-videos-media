import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy, type Mood} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Story scenes, set 5 (built for the cartoon style, also work with silhouettes):
   trialLine, tornBoots, villageRun, buildHome. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x: number; y: number; color?: string; size?: number; rot?: number}> = ({text, at: a, x, y, color = '#ffcc4d', size = 64, rot = -4}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 480, width: 960, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: '#111', background: color, padding: '4px 26px', borderRadius: 14, border: '5px solid #111', boxShadow: '0 8px 0 #111'}}>{text}</span>
    </div>
  );
};

const Clouds: React.FC<{y?: number; tint?: string}> = ({y = 330, tint = '#ffffff'}) => {
  const frame = useCurrentFrame();
  return (
    <>
      {[0, 1, 2, 3].map((i) => {
        const cx = ((i * 380 + frame * (0.5 + i * 0.15)) % 1500) - 200;
        const s = 0.8 + (i % 3) * 0.3;
        return (
          <svg key={i} width={320 * s} height={130 * s} viewBox="0 0 320 130" style={{position: 'absolute', left: cx, top: y + (i % 2) * 190 + i * 40, opacity: 0.9}}>
            <g fill={tint}><ellipse cx={90} cy={80} rx={80} ry={40} /><ellipse cx={170} cy={60} rx={90} ry={52} /><ellipse cx={240} cy={86} rx={70} ry={36} /></g>
          </svg>
        );
      })}
    </>
  );
};

const SunnySky: React.FC<{dawn?: boolean}> = ({dawn}) => (
  <>
    <AbsoluteFill style={{background: dawn
      ? 'linear-gradient(180deg, #3a2f7a 0%, #c0588c 36%, #ffb36b 58%, #ffd9a0 100%)'
      : 'linear-gradient(180deg, #2f9bff 0%, #7cc9ff 40%, #c9ecff 62%, #ffe9c2 100%)'}} />
    <Clouds tint={dawn ? '#ffd0c0' : '#ffffff'} />
  </>
);

const Ground: React.FC<{y: number; color?: string; pitch?: boolean}> = ({y, color = '#d39a55', pitch}) => (
  <div style={{position: 'absolute', left: 0, top: y, width: 1080, height: 1920 - y, background: `linear-gradient(180deg, ${color} 0%, #b57a3c 45%, #7a4f24 100%)`, borderTop: '8px solid #1b1b22'}}>
    {pitch ? <div style={{position: 'absolute', left: -40, right: -40, top: 150, height: 14, background: '#fff8e6', opacity: 0.7, borderRadius: 8}} /> : null}
    {new Array(22).fill(0).map((_, i) => (
      <div key={i} style={{position: 'absolute', left: random(`gx${i}`) * 1080, top: 30 + random(`gy${i}`) * 700, width: 26 + random(`gw${i}`) * 40, height: 8, borderRadius: 4, background: '#00000022'}} />
    ))}
  </div>
);

const Hut: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <svg width={260 * s} height={260 * s} viewBox="0 0 260 260" style={{position: 'absolute', left: x - 130 * s, top: y - 240 * s}}>
    <rect x={50} y={120} width={160} height={120} rx={10} fill="#e6b176" stroke="#1b1b22" strokeWidth={6} />
    <rect x={150} y={120} width={60} height={120} fill="#000" opacity={0.1} />
    <path d="M24 134 L130 26 L236 134 Z" fill="#b9822f" stroke="#1b1b22" strokeWidth={6} strokeLinejoin="round" />
    {new Array(7).fill(0).map((_, i) => <line key={i} x1={50 + i * 27} y1={130} x2={130} y2={38} stroke="#8a5f1e" strokeWidth={3} />)}
    <rect x={108} y={168} width={44} height={72} rx={8} fill="#5a3a1c" stroke="#1b1b22" strokeWidth={5} />
  </svg>
);

const Tree: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <svg width={240 * s} height={380 * s} viewBox="0 0 240 380" style={{position: 'absolute', left: x - 120 * s, top: y - 380 * s}}>
    <rect x={108} y={170} width={24} height={210} fill="#6b4423" stroke="#1b1b22" strokeWidth={5} />
    <ellipse cx={120} cy={120} rx={108} ry={84} fill="#2f9e58" stroke="#1b1b22" strokeWidth={6} />
    <ellipse cx={90} cy={96} rx={50} ry={34} fill="#55c57a" opacity={0.7} />
  </svg>
);

/* faceClose: { fx: 'mock'|'fire', moodFrom?, moodTo?, onWord? } — big close-up of the hero. 'mock': cold blue, HA HA flying in,
   a tear. 'fire': the mood flips on cue, warm burst + speed lines. */
const FaceClose: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fx = (scene.fx as string) ?? 'mock';
  const on = at(captions, scene.onWord, fps, dur * 0.4);
  const p = spring({frame: frame - on, fps, config: {damping: 14}});
  const mood = (frame >= on ? scene.moodTo : scene.moodFrom) as Mood | undefined;
  const fire = fx === 'fire' ? p : 0;
  const zoom = interpolate(frame, [0, dur], [1.0, 1.1]) + (fx === 'fire' ? p * 0.06 : 0);
  return (
    <Shake at={fx === 'fire' ? on : 0} amount={fx === 'fire' ? 18 : 12}>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 42%, #7aa7d9 0%, #3b5f8f 55%, #1d2f4d 100%)'}} />
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 42%, #ffe08a 0%, #ff9a3c 50%, #c2410c 100%)', opacity: fire}} />
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.25 + fire * 0.5}}>
        {new Array(28).fill(0).map((_, i) => {
          const a = (i / 28) * Math.PI * 2 + frame / (fx === 'fire' ? 40 : 200);
          return <path key={i} d={`M540 820 L${540 + Math.cos(a) * 1600} ${820 + Math.sin(a) * 1600} L${540 + Math.cos(a + 0.06) * 1600} ${820 + Math.sin(a + 0.06) * 1600} Z`} fill="#fff" opacity={0.5} />;
        })}
      </svg>
      <div style={{position: 'absolute', inset: 0, scale: String(zoom), transformOrigin: '540px 900px', translate: `0px ${Math.sin(frame / 12) * 6}px`}}>
        <Boy x={540} y={2080} height={1500} stage="teen" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.4} mood={mood ?? (fx === 'mock' ? 'cry' : 'determined')} />
      </div>
      {fx === 'mock' ? new Array(9).fill(0).map((_, i) => {
        const t0 = i * 7;
        const t = (frame - t0) / 26;
        if (t < 0) return null;
        const left = i % 2 === 0;
        const yy = 330 + ((i * 173) % 620);
        const xx = left ? -260 + Math.min(1, t) * 330 : 1080 - Math.min(1, t) * 400;
        return <div key={i} style={{position: 'absolute', left: xx + Math.sin(frame / 5 + i) * 8, top: yy, rotate: `${(left ? -1 : 1) * (8 + (i % 3) * 6)}deg`,
          fontFamily: DISPLAY, fontSize: 96 + (i % 3) * 22, color: '#fff', WebkitTextStroke: '8px #1b1b22', paintOrder: 'stroke fill', opacity: 0.95}}>HA HA</div>;
      }) : null}
      {scene.tag ? <Tag text={scene.tag as string} at={on} x={540} y={290} size={84} /> : null}
    </Shake>
  );
};

/* trialLine: { mode?: 'laugh'|'play', laughOnWord?, playOnWord?, label?, labelOnWord?, sign?, count? } */
const TrialLine: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mode = (scene.mode as string) ?? 'laugh';
  const laughAt = at(captions, scene.laughOnWord, fps, 0);
  const playAt = at(captions, scene.playOnWord, fps, 6);
  const labelAt = at(captions, scene.labelOnWord, fps, dur * 0.6);
  const laughing = mode === 'laugh' && frame >= laughAt;
  const kids = [100, 235, 370, 710, 845, 980];
  const heroX = mode === 'play' ? interpolate(frame, [playAt, dur], [120, 960], clamp) : 540;
  const ballX = heroX + 70 + Math.abs(Math.sin(frame / 3)) * 26;
  const gy = 1130;
  return (
    <Shake at={mode === 'laugh' ? laughAt : labelAt} amount={10}>
      <Camera dur={dur} from={1.08} to={1.0}>
        <SunnySky />
        {/* back row: far queue of tiny kids to sell "200" */}
        <svg width={1080} height={200} style={{position: 'absolute', top: gy - 150}}>
          {new Array(46).fill(0).map((_, i) => (
            <g key={i} transform={`translate(${14 + i * 23.5} ${70 + (i % 2) * 14})`}>
              <circle cx={0} cy={0} r={11} fill={['#8d5524', '#c68642', '#6b4423', '#a0663a'][i % 4]} stroke="#1b1b22" strokeWidth={3} />
              <rect x={-10} y={11} width={20} height={34} rx={6} fill={['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6'][i % 5]} stroke="#1b1b22" strokeWidth={3} />
            </g>
          ))}
        </svg>
        {/* goal */}
        <svg width={1080} height={400} style={{position: 'absolute', top: gy - 330}}>
          <path d="M300 330 L300 90 L780 90 L780 330" stroke="#fff" strokeWidth={16} fill="none" strokeLinejoin="round" />
          <path d="M300 330 L300 90 L780 90 L780 330" stroke="#1b1b22" strokeWidth={4} fill="none" transform="translate(0 0)" opacity={0.25} />
        </svg>
        <Ground y={gy} pitch />
        {kids.map((kx, i) => {
          const m: Mood = mode === 'play' ? (frame > playAt + 8 ? 'shock' : 'neutral') : laughing ? 'laugh' : 'happy';
          const bounce = laughing ? Math.abs(Math.sin(frame / 3 + i * 1.3)) * 16 : 0;
          return <Boy key={kx} x={kx} y={1240 - bounce + (i % 2) * 14} height={470 + (i % 3) * 26} stage="teen" skin={`#kid${i}`} rim="#ffffff" glow={0.1}
            mood={m} pose={laughing && i % 2 === 0 ? 'cheer' : 'stand'} phase={frame / 4 + i} flip={kx > 540} />;
        })}
        <Boy x={heroX} y={1300} height={560} stage="teen" pose={mode === 'play' ? 'run' : 'stand'} phase={frame / 2.4}
          skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood={mode === 'play' ? 'determined' : laughing ? 'sad' : 'neutral'} />
        {mode === 'play' ? <div style={{position: 'absolute', left: ballX, top: 1236 - Math.abs(Math.sin(frame / 3)) * 30, width: 58, height: 58, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #d8d8d8)', border: '5px solid #1b1b22'}} /> : null}
        {mode === 'play' ? new Array(6).fill(0).map((_, i) => {
          const t = ((frame + i * 5) % 24) / 24;
          return <div key={i} style={{position: 'absolute', left: heroX - 70 - t * 200, top: 1250 - t * 50, width: 36 + t * 50, height: 36 + t * 50, borderRadius: '50%', background: '#f0d3a2', opacity: 0.7 * (1 - t)}} />;
        }) : null}
        {laughing ? kids.map((kx, i) => {
          const t = ((frame - laughAt + i * 9) % 44) / 44;
          return <div key={i} style={{position: 'absolute', left: kx - 90, top: 690 - t * 150 + (i % 2) * 30, opacity: Math.sin(t * Math.PI),
            fontFamily: DISPLAY, fontSize: 70, color: '#fff', WebkitTextStroke: '6px #1b1b22', paintOrder: 'stroke fill', rotate: `${(i % 2 ? 1 : -1) * 10}deg`}}>HA HA</div>;
        }) : null}
        {scene.sign ? <Tag text={scene.sign as string} at={0} x={540} y={300} color="#ffffff" size={66} rot={0} /> : null}
        {scene.count ? <Tag text={scene.count as string} at={at(captions, scene.countOnWord, fps, 4)} x={540} y={430} color="#ffcc4d" size={84} rot={-3} /> : null}
        {scene.label ? <Tag text={scene.label as string} at={labelAt} x={540} y={420} color="#5dffb0" size={110} rot={-5} /> : null}
      </Camera>
    </Shake>
  );
};

/* tornBoots: { tags: [{text, onWord}] } — giant close-up of a ripped boot held together with wire. */
const TornBoots: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tags = (scene.tags as {text: string; onWord?: string}[]) ?? [];
  const ats = tags.map((t, i) => at(captions, t.onWord, fps, 10 + i * 30));
  const wobble = Math.sin(frame / 10) * 2;
  return (
    <Shake at={ats[0] ?? 0} amount={10}>
      <Camera dur={dur} from={1.15} to={1.0}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 50%, #ffe2a8 0%, #d9a066 55%, #8a5a2c 100%)'}} />
        <svg width={1080} height={900} viewBox="0 0 1080 900" style={{position: 'absolute', top: 480, rotate: `${wobble}deg`}}>
          {/* sole */}
          <path d="M120 600 Q120 680 220 690 L900 690 Q980 690 980 630 L960 590 Z" fill="#2b2b2b" stroke="#1b1b22" strokeWidth={10} />
          {new Array(7).fill(0).map((_, i) => <rect key={i} x={240 + i * 100} y={690} width={34} height={36} rx={8} fill="#444" stroke="#1b1b22" strokeWidth={6} />)}
          {/* upper */}
          <path d="M140 600 Q130 420 300 380 L520 330 Q600 320 640 380 L760 470 Q900 520 960 590 L140 600 Z" fill="#3a3a3a" stroke="#1b1b22" strokeWidth={10} strokeLinejoin="round" />
          <path d="M300 380 Q330 300 420 300 L520 330" fill="#3a3a3a" stroke="#1b1b22" strokeWidth={10} />
          {/* laces */}
          {new Array(5).fill(0).map((_, i) => <line key={i} x1={420 + i * 50} y1={330 + i * 22} x2={470 + i * 50} y2={360 + i * 22} stroke="#e8e8e8" strokeWidth={8} />)}
          {/* rips */}
          <path d="M600 520 L640 480 L660 540 L700 500 L720 560 L680 590 Z" fill="#c98b4a" stroke="#1b1b22" strokeWidth={6} />
          <path d="M240 520 L280 470 L310 530 L330 490 L350 560 L260 580 Z" fill="#c98b4a" stroke="#1b1b22" strokeWidth={6} />
          {/* wire stitches */}
          {[[600, 520, 720, 560], [240, 520, 350, 560]].map(([x1, y1, x2, y2], k) => (
            <g key={k} opacity={interpolate(frame, [(ats[1] ?? 40) - 4, (ats[1] ?? 40) + 6], [0, 1], clamp)}>
              {new Array(6).fill(0).map((_, i) => {
                const px = x1 + ((x2 - x1) * i) / 5, py = y1 + ((y2 - y1) * i) / 5;
                return <path key={i} d={`M${px - 14} ${py - 26} L${px + 14} ${py + 26}`} stroke="#c8c8d0" strokeWidth={7} strokeLinecap="round" />;
              })}
            </g>
          ))}
        </svg>
        {tags.map((t, i) => <Tag key={i} text={t.text} at={ats[i]} x={540} y={320 + i * 120} color={i === 0 ? '#ff6b6b' : '#ffcc4d'} rot={i % 2 ? 3 : -4} />)}
      </Camera>
    </Shake>
  );
};

/* villageRun: { tagText?, tagOnWord? } — dawn village; the hero sprints past huts with a sports bag. */
const VillageRun: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tagAt = at(captions, scene.tagOnWord, fps, dur * 0.5);
  const scroll = frame * 9;
  const gy = 1150;
  return (
    <Camera dur={dur} from={1.0} to={1.06}>
      <SunnySky dawn />
      <div style={{position: 'absolute', left: 600, top: 700, width: 340, height: 340, borderRadius: '50%', background: 'radial-gradient(circle, #fff6d0 0%, #ffd27a 45%, #ffb36b00 72%)'}} />
      {[0, 1].map((k) => (
        <div key={k} style={{position: 'absolute', left: k * 1400 - (scroll % 1400), top: 0, width: 1400, height: 1920}}>
          <Tree x={360} y={gy + 6} s={1.1} /><Tree x={1010} y={gy + 6} s={0.9} />
          <Hut x={170} y={gy + 8} s={1.5} /><Hut x={680} y={gy + 8} s={1.25} /><Hut x={1230} y={gy + 8} s={1.6} />
        </div>
      ))}
      <Ground y={gy} />
      {new Array(10).fill(0).map((_, i) => (
        <div key={i} style={{position: 'absolute', left: ((i * 150 - frame * 20) % 1500 + 1500) % 1500 - 150, top: 1330 + (i % 3) * 60, width: 90, height: 10, borderRadius: 5, background: '#ffffff55'}} />
      ))}
      {new Array(8).fill(0).map((_, i) => {
        const t = ((frame + i * 5) % 28) / 28;
        return <div key={i} style={{position: 'absolute', left: 440 - t * 260, top: 1250 - t * 60, width: 40 + t * 70, height: 40 + t * 70, borderRadius: '50%', background: '#f0d3a2', opacity: 0.75 * (1 - t)}} />;
      })}
      <div style={{position: 'absolute', left: 392, top: 990 + Math.abs(Math.cos(frame / 2.4)) * 14, width: 110, height: 70, background: '#2563eb', border: '7px solid #1b1b22', borderRadius: 22, rotate: '-8deg'}}>
        <div style={{position: 'absolute', left: 14, right: 14, top: 26, height: 7, background: '#1b1b22', opacity: 0.5}} />
      </div>
      <Boy x={540} y={1300} height={560} stage="teen" pose="run" phase={frame / 2.4}
        skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="determined" />
      {scene.tagText ? <Tag text={scene.tagText as string} at={tagAt} x={540} y={300} size={110} color="#ffcc4d" /> : null}
    </Camera>
  );
};

const Confetti: React.FC<{from?: number; count?: number}> = ({from = 0, count = 60}) => {
  const frame = useCurrentFrame();
  if (frame < from) return null;
  return (
    <>
      {new Array(count).fill(0).map((_, i) => {
        const x = random(`cfx${i}`) * 1080 + Math.sin(frame / 12 + i) * 30;
        const y = ((random(`cfy${i}`) * 2000 + (frame - from) * (8 + random(`cfv${i}`) * 10)) % 2000) - 60;
        return <div key={i} style={{position: 'absolute', left: x, top: y, width: 18, height: 30, rotate: `${frame * 7 + i * 40}deg`, borderRadius: 4,
          background: ['#ffcc4d', '#ff6b6b', '#5dffb0', '#3fe0ff', '#ffffff'][i % 5], border: '3px solid #1b1b22'}} />;
      })}
    </>
  );
};

const Burst: React.FC<{c1: string; c2: string; cy?: number}> = ({c1, c2, cy = 800}) => {
  const frame = useCurrentFrame();
  return (
    <>
      <AbsoluteFill style={{background: `radial-gradient(circle at 50% ${(cy / 1920) * 100}%, ${c1} 0%, ${c2} 80%)`}} />
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.22}}>
        {new Array(20).fill(0).map((_, i) => {
          const a = (i / 20) * Math.PI * 2 + frame / 90;
          return <path key={i} d={`M540 ${cy} L${540 + Math.cos(a) * 1700} ${cy + Math.sin(a) * 1700} L${540 + Math.cos(a + 0.16) * 1700} ${cy + Math.sin(a + 0.16) * 1700} Z`} fill="#fff" />;
        })}
      </svg>
    </>
  );
};

/* trophyLift: { label, labelOnWord?, stamp?, stampOnWord?, sub? } — the grown-up hero lifts a trophy; bright burst + confetti. */
const TrophyLift: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const labelAt = at(captions, scene.labelOnWord, fps, 8);
  const stampAt = at(captions, scene.stampOnWord, fps, dur * 0.7);
  const st = spring({frame: frame - stampAt, fps, config: {damping: 8, stiffness: 200}});
  const rise = spring({frame: frame - 2, fps, config: {damping: 12}});
  return (
    <Shake at={stampAt} amount={18}>
      <Camera dur={dur} from={1.06} to={1.0}>
        <Burst c1="#ffe9a8" c2="#f59e0b" cy={760} />
        <Confetti from={labelAt} />
        <Boy x={540} y={1290} height={640} stage="adult" pose="cheer" phase={frame / 5} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="laugh" />
        <svg width={300} height={320} viewBox="0 0 260 300" style={{position: 'absolute', left: 390, top: 700 - rise * 375 + Math.sin(frame / 5) * 5}}>
          <path d="M60 30 H200 V90 C200 160 160 190 130 195 C100 190 60 160 60 90 Z" fill="#ffd34d" stroke="#1b1b22" strokeWidth={8} strokeLinejoin="round" />
          <path d="M150 40 H190 V95 C190 140 170 170 150 180 Z" fill="#000" opacity={0.12} />
          <path d="M60 50 C6 50 10 124 72 142 M200 50 C254 50 250 124 188 142" stroke="#1b1b22" strokeWidth={22} fill="none" />
          <path d="M60 50 C6 50 10 124 72 142 M200 50 C254 50 250 124 188 142" stroke="#ffd34d" strokeWidth={10} fill="none" />
          <rect x={116} y={193} width={28} height={50} fill="#ffd34d" stroke="#1b1b22" strokeWidth={8} />
          <rect x={70} y={240} width={120} height={40} rx={8} fill="#8b5a2b" stroke="#1b1b22" strokeWidth={8} />
          <path d="M84 52 Q80 100 96 130" stroke="#fff" strokeWidth={10} strokeLinecap="round" opacity={0.7} fill="none" />
        </svg>
        {scene.label ? <Tag text={scene.label as string} at={labelAt} x={540} y={235} size={84} color="#ffffff" rot={-3} /> : null}
        {scene.stamp ? (
          <div style={{position: 'absolute', left: 740, top: 560, opacity: frame >= stampAt ? 1 : 0, scale: String(2.4 - st * 1.4), rotate: '12deg'}}>
            <span style={{fontFamily: DISPLAY, fontSize: 200, color: '#ef4444', WebkitTextStroke: '10px #1b1b22', paintOrder: 'stroke fill'}}>{scene.stamp as string}</span>
          </div>
        ) : null}
        {scene.sub ? <div style={{position: 'absolute', top: 400, width: '100%', textAlign: 'center', fontFamily: BODY, fontWeight: 800, fontSize: 50, color: '#1b1b22', opacity: interpolate(frame, [labelAt + 6, labelAt + 14], [0, 1], clamp)}}>{scene.sub as string}</div> : null}
      </Camera>
    </Shake>
  );
};

/* podium: { place: 2, small?, big?, onWord? } — three-step podium; the hero celebrates on his step, others dimmed. */
const Podium: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const on = at(captions, scene.onWord, fps, dur * 0.4);
  const place = (scene.place as number) ?? 2;
  const steps = [
    {n: 2, x: 90, top: 1010, c: '#cbd5e1'},
    {n: 1, x: 390, top: 900, c: '#ffd34d'},
    {n: 3, x: 690, top: 1080, c: '#d9a066'},
  ];
  const s = spring({frame: frame - on, fps, config: {damping: 10, stiffness: 180}});
  return (
    <Shake at={on} amount={14}>
      <Camera dur={dur} from={1.0} to={1.07}>
        <Burst c1="#5b7cfa" c2="#1e1b4b" cy={900} />
        <Confetti from={on} count={40} />
        {steps.map((st) => {
          const mine = st.n === place;
          return (
            <React.Fragment key={st.n}>
              <div style={{opacity: mine ? 1 : 0.5, filter: mine ? 'none' : 'saturate(0.4)'}}>
                <Boy x={st.x + 150} y={st.top + 6} height={450} stage="adult" skin={mine ? sb.character.palette.skin : `#pod${st.n}`} rim="#fff" glow={mine ? 0.8 : 0}
                  pose={mine && frame >= on ? 'cheer' : 'stand'} phase={frame / 5} mood={mine ? (frame >= on ? 'laugh' : 'happy') : 'neutral'} />
              </div>
              <div style={{position: 'absolute', left: st.x, top: st.top, width: 300, height: 1320 - st.top, background: st.c, border: '8px solid #1b1b22', borderRadius: '14px 14px 0 0',
                boxShadow: mine ? `0 0 ${40 + s * 60}px ${st.c}` : 'none', opacity: mine ? 1 : 0.75}}>
                <div style={{textAlign: 'center', fontFamily: DISPLAY, fontSize: 150, color: '#1b1b22', lineHeight: 1.25}}>{st.n}</div>
              </div>
            </React.Fragment>
          );
        })}
        <div style={{position: 'absolute', top: 240, width: '100%', textAlign: 'center', fontFamily: BODY, fontWeight: 800, fontSize: 48, color: '#ffd34d', letterSpacing: 4}}>{(scene.small as string) ?? ''}</div>
        <div style={{position: 'absolute', top: 300, width: '100%', textAlign: 'center', opacity: frame >= on ? 1 : 0, scale: String(1.7 - s * 0.7)}}>
          <span style={{fontFamily: DISPLAY, fontSize: 124, color: '#fff', WebkitTextStroke: '8px #1b1b22', paintOrder: 'stroke fill'}}>{(scene.big as string) ?? ''}</span>
        </div>
      </Camera>
    </Shake>
  );
};

/* buildHome: { items: [{label, onWord, color}] } — new buildings pop up in the village one by one; kids cheer. */
const BuildHome: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const items = (scene.items as {label: string; onWord?: string; color?: string}[]) ?? [];
  const ats = items.map((it, i) => at(captions, it.onWord, fps, 15 + i * 30));
  const xs = items.length === 1 ? [540] : [285, 795];
  const cheer = frame >= (ats[0] ?? 0);
  const gy = 1130;
  return (
    <Shake at={ats.at(-1) ?? 0} amount={10}>
      <Camera dur={dur} from={1.05} to={1.0}>
        <SunnySky />
        <Hut x={70} y={gy + 8} s={0.9} /><Hut x={1010} y={gy + 8} s={0.9} />
        {items.map((it, i) => {
          const s = spring({frame: frame - ats[i], fps, config: {damping: 9, stiffness: 130}});
          return (
            <div key={i} style={{position: 'absolute', left: xs[i] - 215, top: gy - 600, width: 430, height: 608, transformOrigin: '50% 100%', scale: `${0.6 + s * 0.4} ${s}`}}>
              <div style={{position: 'absolute', bottom: 0, width: 430, height: 430, background: '#fffaf0', border: '8px solid #1b1b22', borderRadius: 12, overflow: 'hidden'}}>
                <div style={{position: 'absolute', right: 0, top: 0, bottom: 0, width: 110, background: '#00000012'}} />
                {new Array(6).fill(0).map((_, k) => (
                  <div key={k} style={{position: 'absolute', left: 42 + (k % 3) * 124, top: 44 + Math.floor(k / 3) * 128, width: 92, height: 88, background: '#8fd3ff', border: '7px solid #1b1b22', borderRadius: 8}} />
                ))}
                <div style={{position: 'absolute', left: 168, bottom: 0, width: 94, height: 120, background: '#8b5a2b', border: '7px solid #1b1b22', borderBottom: 'none', borderRadius: '10px 10px 0 0'}} />
              </div>
              <div style={{position: 'absolute', bottom: 430, left: -14, width: 458, height: 40, background: it.color ?? '#ef4444', border: '8px solid #1b1b22', borderRadius: 10}} />
              <div style={{position: 'absolute', top: 30, width: 430, textAlign: 'center'}}>
                <span style={{fontFamily: DISPLAY, fontSize: 70, color: '#fff', background: it.color ?? '#ef4444', padding: '2px 24px', border: '7px solid #1b1b22', borderRadius: 14, boxShadow: '0 8px 0 #1b1b22'}}>{it.label}</span>
              </div>
            </div>
          );
        })}
        <Ground y={gy} />
        <Confetti from={ats.at(-1) ?? 0} count={36} />
        {[130, 300, 780, 950].map((kx, i) => (
          <Boy key={kx} x={kx} y={1270 + (i % 2) * 20} height={400} stage="child" skin={`#vk${i}`} rim="#ffffff" glow={0.1} pose={cheer ? 'cheer' : 'stand'} phase={frame / 4 + i} mood={cheer ? 'laugh' : 'happy'} flip={kx > 540} />
        ))}
        <Boy x={540} y={1310} height={600} stage="adult" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="happy" />
      </Camera>
    </Shake>
  );
};

export const STORY5_SCENES: Record<string, React.FC<SceneProps>> = {
  faceClose: FaceClose,
  trialLine: TrialLine,
  tornBoots: TornBoots,
  villageRun: VillageRun,
  trophyLift: TrophyLift,
  podium: Podium,
  buildHome: BuildHome,
};
