import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* "Sounds fake, is true" kit (history/time facts): factLine (cartoon timeline with icons + gap brackets),
   sameTime (two worlds stacked, happening at once), factsEnd (numbered recap card). */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Rays: React.FC<{c1: string; c2: string; cy?: number}> = ({c1, c2, cy = 820}) => {
  const frame = useCurrentFrame();
  return (
    <>
      <AbsoluteFill style={{background: `radial-gradient(circle at 50% ${(cy / 1920) * 100}%, ${c1} 0%, ${c2} 80%)`}} />
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.12}}>
        {new Array(18).fill(0).map((_, i) => {
          const a = (i / 18) * Math.PI * 2 + frame / 80;
          return <path key={i} d={`M540 ${cy} L${540 + Math.cos(a) * 1700} ${cy + Math.sin(a) * 1700} L${540 + Math.cos(a + 0.17) * 1700} ${cy + Math.sin(a + 0.17) * 1700} Z`} fill="#fff" />;
        })}
      </svg>
    </>
  );
};

/* Simple cartoon icons, all drawn in a 200×200 box. */
export const Icon: React.FC<{name: string}> = ({name}) => {
  const frame = useCurrentFrame();
  const S = {stroke: OL, strokeWidth: 8, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
  switch (name) {
    case 'pyramid': return <g><path d="M100 30 L185 165 L15 165 Z" fill="#fbbf24" {...S} /><path d="M100 30 L185 165 L120 165 Z" fill="#d97706" {...S} />{[70, 105, 140].map((y) => <path key={y} d={`M${100 - (y - 30) * 0.6} ${y} H${100 + (y - 30) * 0.62}`} stroke={OL} strokeWidth={4} opacity={0.4} />)}</g>;
    case 'crown': return <g><path d="M30 150 L22 60 L66 100 L100 40 L134 100 L178 60 L170 150 Z" fill="#fde047" {...S} /><rect x={30} y={140} width={140} height={28} rx={8} fill="#f59e0b" {...S} />{[[22, 60], [100, 40], [178, 60]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={12} fill={['#ef4444', '#38bdf8', '#22c55e'][i]} {...S} strokeWidth={6} />)}</g>;
    case 'rocket': return <g transform="rotate(35 100 100)"><path d="M100 14 Q150 60 140 140 L60 140 Q50 60 100 14 Z" fill="#f1f5f9" {...S} /><path d="M60 110 L28 160 L64 140 Z M140 110 L172 160 L136 140 Z" fill="#ef4444" {...S} /><circle cx={100} cy={78} r={20} fill="#38bdf8" {...S} strokeWidth={6} />
      <path d={`M78 142 Q100 ${186 + Math.sin(frame / 2) * 10} 122 142 Z`} fill="#fb923c" {...S} strokeWidth={6} /></g>;
    case 'college': return <g><path d="M20 78 L100 26 L180 78 Z" fill="#cbd5e1" {...S} /><rect x={28} y={78} width={144} height={18} fill="#e2e8f0" {...S} />{[44, 82, 120, 150].map((x) => <rect key={x} x={x} y={96} width={18} height={60} fill="#f8fafc" {...S} strokeWidth={6} />)}<rect x={20} y={156} width={160} height={20} rx={4} fill="#94a3b8" {...S} /></g>;
    case 'temple': return <g>{[0, 1, 2, 3].map((i) => <rect key={i} x={20 + i * 22} y={140 - i * 30} width={160 - i * 44} height={32} fill={i % 2 ? '#b45309' : '#d97706'} {...S} strokeWidth={7} />)}<rect x={84} y={28} width={32} height={26} fill="#78350f" {...S} strokeWidth={7} /><path d="M92 172 L92 54 M108 172 L108 54" stroke={OL} strokeWidth={4} opacity={0.5} /></g>;
    case 'mammoth': return <g><path d="M60 150 L60 176 M88 152 L88 176 M130 152 L130 176 M156 146 L156 176" stroke={OL} strokeWidth={22} strokeLinecap="round" /><path d="M60 150 L60 172 M88 152 L88 172 M130 152 L130 172 M156 146 L156 172" stroke="#92400e" strokeWidth={13} strokeLinecap="round" />
      <path d="M40 120 Q36 50 100 46 Q170 44 176 110 Q178 150 150 152 L60 152 Q42 150 40 120 Z" fill="#a16207" {...S} /><path d="M40 110 Q14 104 16 138 Q18 164 34 170" fill="none" stroke={OL} strokeWidth={24} strokeLinecap="round" /><path d="M40 110 Q14 104 16 138 Q18 164 34 170" fill="none" stroke="#a16207" strokeWidth={13} strokeLinecap="round" />
      <path d="M52 124 Q40 160 76 150" fill="none" stroke={OL} strokeWidth={15} strokeLinecap="round" /><path d="M52 124 Q40 160 76 150" fill="none" stroke="#fff" strokeWidth={7} strokeLinecap="round" /><circle cx={62} cy={92} r={8} fill={OL} /><path d="M92 50 Q100 30 116 46 Q126 28 140 50" fill="#a16207" {...S} strokeWidth={6} /></g>;
    case 'trex': return <g><path d="M30 150 Q10 120 40 96 Q56 130 86 120 Z" fill="#22c55e" {...S} /><path d="M78 150 L78 178 M112 150 L112 178" stroke={OL} strokeWidth={24} strokeLinecap="round" /><path d="M78 150 L78 174 M112 150 L112 174" stroke="#16a34a" strokeWidth={14} strokeLinecap="round" />
      <path d="M58 132 Q54 76 108 70 L112 40 Q116 18 150 20 L178 26 Q190 34 182 52 L150 62 L176 70 L146 80 Q150 128 126 150 L74 152 Q60 150 58 132 Z" fill="#22c55e" {...S} /><circle cx={146} cy={38} r={8} fill={OL} /><path d="M152 60 l6 8 l6 -8 l6 8" stroke="#fff" strokeWidth={5} fill="none" /><path d="M128 100 l20 6" stroke={OL} strokeWidth={9} strokeLinecap="round" /></g>;
    case 'stego': return <g><path d="M40 150 L40 176 M70 152 L70 176 M120 152 L120 176 M146 148 L146 176" stroke={OL} strokeWidth={22} strokeLinecap="round" /><path d="M40 150 L40 172 M70 152 L70 172 M120 152 L120 172 M146 148 L146 172" stroke="#0d9488" strokeWidth={13} strokeLinecap="round" />
      {[[56, 84], [84, 66], [116, 66], [144, 86]].map(([x, y], i) => <path key={i} d={`M${x - 16} ${y + 24} L${x} ${y - 22} L${x + 16} ${y + 24} Z`} fill="#fb923c" {...S} strokeWidth={7} />)}
      <path d="M14 140 Q30 96 100 90 Q160 92 176 132 L196 150 L170 148 Q150 158 100 156 L40 154 Q18 152 14 140 Z" fill="#14b8a6" {...S} /><circle cx={30} cy={128} r={7} fill={OL} /></g>;
    case 'you': return <g><circle cx={100} cy={96} r={62} fill="#d99a5b" {...S} /><path d="M40 92 Q40 26 100 28 Q160 26 160 92 Q130 60 100 66 Q70 60 40 92 Z" fill="#3a2614" {...S} /><circle cx={78} cy={100} r={9} fill={OL} /><circle cx={122} cy={100} r={9} fill={OL} /><path d="M78 126 Q100 148 122 126" stroke={OL} strokeWidth={8} fill="none" strokeLinecap="round" /><path d="M58 158 Q100 196 142 158 L150 190 L50 190 Z" fill="#ff7a1a" {...S} /></g>;
    default: return <circle cx={100} cy={100} r={70} fill="#fff" {...S} />;
  }
};

type Item = {label: string; sub?: string; icon: string; pos: number; onWord?: string};
type Span = {a: number; b: number; label: string; win?: boolean; onWord?: string; tag?: string};

/* factLine: { fact?, badge?, colors:[c1,c2], items: Item[], spans: Span[] } — icons pop in on their words along a timeline;
   brackets show the gaps, the winning (shorter/older) one turns green. */
const FactLine: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const items = (scene.items as Item[]) ?? [], spans = (scene.spans as Span[]) ?? [];
  const cols = (scene.colors as string[]) ?? ['#fcd34d', '#92400e'];
  const X = (p: number) => 190 + p * 700;
  const LY = 930;
  const iAts = items.map((it, i) => at(captions, it.onWord, fps, 6 + i * 16));
  const sAts = spans.map((sp, i) => at(captions, sp.onWord, fps, dur * 0.6 + i * 12));
  const lineP = interpolate(frame, [0, 14], [0, 1], clamp);
  return (
    <Shake at={sAts[sAts.length - 1] ?? 0} amount={12}>
      <Camera dur={dur} from={1.06} to={1.0}>
        <Rays c1={cols[0]} c2={cols[1]} cy={800} />
        {scene.badge ? <Tag text={scene.badge as string} at={0} y={200} size={56} color="#111" fg="#ffcc4d" rot={0} /> : null}
        {scene.fact ? <Tag text={scene.fact as string} at={0} y={190} size={80} color="#fff" rot={-3} /> : null}
        <div style={{position: 'absolute', left: 60, top: LY - 10, width: 960 * lineP, height: 20, background: '#fff', border: `6px solid ${OL}`, borderRadius: 12}} />
        <svg width={60} height={80} style={{position: 'absolute', left: 1010, top: LY - 40, opacity: lineP}}><path d="M10 10 L50 40 L10 70 Z" fill="#fff" stroke={OL} strokeWidth={7} strokeLinejoin="round" /></svg>
        {items.map((it, i) => {
          const s = spring({frame: frame - iAts[i], fps, config: {damping: 9, stiffness: 170}});
          const x = X(it.pos);
          return (
            <div key={i} style={{opacity: frame >= iAts[i] ? 1 : 0}}>
              <div style={{position: 'absolute', left: x - 8, top: LY - 150, width: 16, height: 150, background: OL}} />
              <div style={{position: 'absolute', left: x - 24, top: LY - 24, width: 48, height: 48, borderRadius: '50%', background: '#ef4444', border: `8px solid ${OL}`}} />
              <div style={{position: 'absolute', left: x - 125, top: LY - 400, width: 250, height: 250, borderRadius: '50%', background: '#fffdf5', border: `10px solid ${OL}`, boxShadow: `0 10px 0 ${OL}`, scale: String(s), rotate: `${(1 - s) * -30}deg`}}>
                <svg width={200} height={200} viewBox="0 0 200 200" style={{position: 'absolute', left: 15, top: 15}}><Icon name={it.icon} /></svg>
              </div>
              <div style={{position: 'absolute', left: x - 170, width: 340, top: LY - 560, textAlign: 'center', scale: String(s)}}>
                <div style={{fontFamily: DISPLAY, fontSize: 58, lineHeight: 1.05, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>{it.label}</div>
                {it.sub ? <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 36, color: '#fde68a', WebkitTextStroke: `5px ${OL}`, paintOrder: 'stroke fill'}}>{it.sub}</div> : null}
              </div>
            </div>
          );
        })}
        {spans.map((sp, i) => {
          const s = spring({frame: frame - sAts[i], fps, config: {damping: 12, stiffness: 150}});
          const xa = X(sp.a), xb = X(sp.b), c = sp.win ? '#22c55e' : '#ef4444';
          return (
            <div key={i} style={{opacity: frame >= sAts[i] ? 1 : 0}}>
              <svg width={1080} height={200} style={{position: 'absolute', top: LY + 30}}>
                <path d={`M${xa + 14} 10 L${xa + 14} 50 L${xa + 14 + (xb - xa - 28) * s} 50 ${s > 0.98 ? `L${xb - 14} 10` : ''}`} stroke={OL} strokeWidth={22} fill="none" strokeLinejoin="round" strokeLinecap="round" />
                <path d={`M${xa + 14} 10 L${xa + 14} 50 L${xa + 14 + (xb - xa - 28) * s} 50 ${s > 0.98 ? `L${xb - 14} 10` : ''}`} stroke={c} strokeWidth={11} fill="none" strokeLinejoin="round" strokeLinecap="round" />
              </svg>
              <div style={{position: 'absolute', left: (xa + xb) / 2 - 300, width: 600, top: LY + 105, textAlign: 'center', scale: String(0.6 + s * 0.4)}}>
                <span style={{fontFamily: DISPLAY, fontSize: 56, color: '#fff', background: c, padding: '2px 18px', borderRadius: 14, border: `6px solid ${OL}`, whiteSpace: 'nowrap'}}>{sp.label}</span>
                {sp.tag ? <div style={{marginTop: 14, fontFamily: DISPLAY, fontSize: 64, color: '#bbf7d0', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill', rotate: '-4deg'}}>{sp.tag}</div> : null}
              </div>
            </div>
          );
        })}
      </Camera>
    </Shake>
  );
};

/* sameTime: { fact?, top: {label, sub}, bottom: {label, sub}, bannerOnWord, banner } — Egypt on top, the Arctic below, same moment. */
const SameTime: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const T = scene.top as {label: string; sub?: string}, B = scene.bottom as {label: string; sub?: string};
  const bAt = at(captions, scene.bannerOnWord, fps, dur * 0.5), botAt = at(captions, scene.bottomOnWord, fps, dur * 0.35);
  const bs = spring({frame: frame - bAt, fps, config: {damping: 9, stiffness: 180}});
  const blocks = Math.floor(interpolate(frame, [0, dur], [3, 15], clamp));
  const mx = interpolate(frame, [botAt, dur], [1150, 380], clamp);
  return (
    <Shake at={bAt} amount={14}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #38bdf8 0%, #fde68a 100%)'}} />
      {/* Egypt */}
      <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 830, overflow: 'hidden'}}>
        <div style={{position: 'absolute', left: 820, top: 250, width: 150, height: 150, borderRadius: '50%', background: '#fff7c2', border: `8px solid ${OL}`}} />
        <div style={{position: 'absolute', left: 0, top: 700, width: 1080, height: 140, background: '#f59e0b', borderTop: `9px solid ${OL}`}} />
        {new Array(15).fill(0).map((_, k) => {
          const row = k < 5 ? 0 : k < 9 ? 1 : k < 12 ? 2 : k < 14 ? 3 : 4, inRow = k - [0, 5, 9, 12, 14][row], n = 5 - row;
          if (k >= blocks) return null;
          return <div key={k} style={{position: 'absolute', left: 540 - (n * 96) / 2 + inRow * 96, top: 612 - row * 84, width: 96, height: 88, background: row % 2 ? '#fbbf24' : '#fcd34d', border: `7px solid ${OL}`, borderRadius: 6}} />;
        })}
        <div style={{position: 'absolute', left: 60, top: 250, fontFamily: DISPLAY, fontSize: 76, color: '#fff', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>{T.label}</div>
        <div style={{position: 'absolute', left: 64, top: 340, fontFamily: BODY, fontWeight: 800, fontSize: 40, color: '#111', background: '#fde047', padding: '2px 16px', borderRadius: 10, border: `5px solid ${OL}`}}>{T.sub}</div>
      </div>
      {/* Arctic island */}
      <div style={{position: 'absolute', left: 0, top: 830, width: 1080, height: 1090, overflow: 'hidden', background: 'linear-gradient(180deg, #1e3a8a 0%, #60a5fa 55%, #e0f2fe 56%, #f8fafc 100%)', borderTop: `12px solid ${OL}`}}>
        {new Array(40).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: (random(`sn${i}`) * 1080 + Math.sin(frame / 20 + i) * 30), top: (random(`sy${i}`) * 700 + frame * (2 + random(`sv${i}`) * 3)) % 700, width: 12, height: 12, borderRadius: 6, background: '#fff', opacity: 0.85}} />)}
        <svg width={1080} height={300} style={{position: 'absolute', top: 330}}><path d="M0 290 L160 120 L300 240 L470 60 L650 250 L800 130 L1080 290 Z" fill="#bfdbfe" stroke={OL} strokeWidth={9} strokeLinejoin="round" /><path d="M470 60 L520 120 L470 110 L430 130 Z" fill="#fff" /></svg>
        <svg width={420} height={420} viewBox="0 0 200 200" style={{position: 'absolute', left: mx - 210, top: 420 + Math.abs(Math.sin(frame / 5)) * 10}}><Icon name="mammoth" /></svg>
        <div style={{position: 'absolute', right: 50, top: 140, textAlign: 'right', fontFamily: DISPLAY, fontSize: 76, color: '#fff', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>{B.label}</div>
        <div style={{position: 'absolute', right: 54, top: 230, fontFamily: BODY, fontWeight: 800, fontSize: 40, color: '#111', background: '#bae6fd', padding: '2px 16px', borderRadius: 10, border: `5px solid ${OL}`}}>{B.sub}</div>
      </div>
      {scene.fact ? <Tag text={scene.fact as string} at={0} y={140} size={76} color="#fff" rot={-3} /> : null}
      <div style={{position: 'absolute', left: 0, right: 0, top: 770, textAlign: 'center', opacity: frame >= bAt ? 1 : 0, scale: String(2 - bs), rotate: '-4deg'}}>
        <span style={{fontFamily: DISPLAY, fontSize: 84, color: '#fff', background: '#ef4444', padding: '2px 34px', borderRadius: 18, border: `9px solid ${OL}`, boxShadow: `0 10px 0 ${OL}`}}>{(scene.banner as string) ?? 'AT THE SAME TIME'}</span>
      </div>
    </Shake>
  );
};

/* factsEnd: { title, items: [{n, icon}], cta } */
const FactsEnd: React.FC<SceneProps> = ({scene, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const items = (scene.items as {n: string; icon: string}[]) ?? [];
  return (
    <Camera dur={dur} from={1.05} to={1.0}>
      <Rays c1="#3b2a6b" c2="#120c26" cy={860} />
      <div style={{position: 'absolute', top: 250, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 104, lineHeight: 1.05, color: '#fde047', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill', padding: '0 70px', boxSizing: 'border-box'}}>{(scene.title as string) ?? ''}</div>
      {items.map((it, i) => {
        const s = spring({frame: frame - 6 - i * 5, fps, config: {damping: 10}});
        const x = 150 + (i % 2) * 420, y = 540 + Math.floor(i / 2) * 330;
        return (
          <div key={i} style={{position: 'absolute', left: x, top: y, width: 360, height: 290, background: '#fffdf5', border: `10px solid ${OL}`, borderRadius: 40, boxShadow: `0 12px 0 ${OL}`, scale: String(s * (1 + Math.sin(frame / 6 + i) * 0.02))}}>
            <svg width={190} height={190} viewBox="0 0 200 200" style={{position: 'absolute', right: 14, top: 50}}><Icon name={it.icon} /></svg>
            <div style={{position: 'absolute', left: 26, top: 20, fontFamily: DISPLAY, fontSize: 170, lineHeight: 1, color: '#ef4444', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>{it.n}</div>
          </div>
        );
      })}
      <div style={{position: 'absolute', top: 1220, width: '100%', textAlign: 'center', opacity: interpolate(frame, [14, 24], [0, 1], clamp)}}>
        <span style={{fontFamily: BODY, fontWeight: 800, fontSize: 52, color: '#111', background: '#ffcc4d', padding: '18px 44px', borderRadius: 60, border: `6px solid ${OL}`}}>{(scene.cta as string) ?? ''}</span>
      </div>
    </Camera>
  );
};

export const TIMEFACT_SCENES: Record<string, React.FC<SceneProps>> = {
  factLine: FactLine,
  sameTime: SameTime,
  factsEnd: FactsEnd,
};
