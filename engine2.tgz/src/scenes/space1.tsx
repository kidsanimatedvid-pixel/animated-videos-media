import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Space scenes, set 1 (cartoon): sunVanish, orbitEmpty, skyBlack, freezeDrop, ventLife, sunLate. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Stars: React.FC<{n?: number}> = ({n = 90}) => {
  const frame = useCurrentFrame();
  return <>{new Array(n).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`st${i}`) * 1080, top: random(`sy${i}`) * 1920, width: 4 + random(`ss${i}`) * 6, height: 4 + random(`ss${i}`) * 6, borderRadius: '50%', background: '#fff', opacity: 0.35 + 0.5 * Math.abs(Math.sin(frame / 14 + i))}} />)}</>;
};

/* Cartoon Earth with a face. mood: happy | shock | sad | cold */
const Earth: React.FC<{x: number; y: number; r: number; mood?: string; ice?: number}> = ({x, y, r, mood = 'happy', ice = 0}) => {
  const frame = useCurrentFrame();
  const blink = frame % 70 > 66;
  return (
    <svg width={r * 2.4} height={r * 2.4} viewBox="-120 -120 240 240" style={{position: 'absolute', left: x - r * 1.2, top: y - r * 1.2, overflow: 'visible'}}>
      <circle r={100} fill="#3b82f6" stroke={OL} strokeWidth={9} />
      <path d="M-70 -50 Q-40 -80 -10 -60 Q10 -40 -20 -20 Q-50 -10 -60 -30 Z M20 -70 Q60 -80 80 -40 Q70 -20 40 -30 Q20 -40 20 -70 Z M-80 30 Q-50 10 -30 40 Q-40 70 -70 60 Z M30 40 Q60 20 85 40 Q70 80 40 80 Q20 60 30 40 Z" fill="#22c55e" stroke={OL} strokeWidth={6} />
      <circle r={100} fill="#e0f2fe" opacity={ice * 0.85} />
      {ice > 0.4 ? <path d="M-60 -70 L-40 -40 M50 -60 L30 -30 M-70 50 L-40 30" stroke="#fff" strokeWidth={8} strokeLinecap="round" /> : null}
      {blink ? <><path d="M-42 -8 h26 M16 -8 h26" stroke="#111" strokeWidth={8} strokeLinecap="round" /></> : <><circle cx={-30} cy={-8} r={mood === 'shock' ? 17 : 13} fill="#fff" stroke={OL} strokeWidth={5} /><circle cx={30} cy={-8} r={mood === 'shock' ? 17 : 13} fill="#fff" stroke={OL} strokeWidth={5} /><circle cx={-30} cy={-6} r={6} fill="#111" /><circle cx={30} cy={-6} r={6} fill="#111" /></>}
      {mood === 'happy' ? <path d="M-28 28 Q0 54 28 28" fill="none" stroke="#111" strokeWidth={8} strokeLinecap="round" /> : mood === 'shock' ? <ellipse cx={0} cy={38} rx={14} ry={18} fill="#111" /> : <path d="M-26 44 Q0 22 26 44" fill="none" stroke="#111" strokeWidth={8} strokeLinecap="round" />}
      {mood === 'cold' ? <><path d="M-40 20 h80" stroke="#111" strokeWidth={0} /><circle cx={-60} cy={20} r={10} fill="#93c5fd" /><circle cx={60} cy={20} r={10} fill="#93c5fd" /></> : <><circle cx={-60} cy={18} r={11} fill="#fda4af" opacity={0.8} /><circle cx={60} cy={18} r={11} fill="#fda4af" opacity={0.8} /></>}
    </svg>
  );
};

const Sun: React.FC<{x: number; y: number; r: number; on?: number}> = ({x, y, r, on = 1}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{position: 'absolute', left: x - r * 1.6, top: y - r * 1.6, width: r * 3.2, height: r * 3.2, opacity: on, scale: String(0.4 + on * 0.6)}}>
      <svg width={r * 3.2} height={r * 3.2} viewBox="-160 -160 320 320">
        <g transform={`rotate(${frame * 1.5})`}>{new Array(12).fill(0).map((_, i) => <path key={i} d="M0 -150 L16 -110 H-16 Z" fill="#fbbf24" stroke={OL} strokeWidth={6} strokeLinejoin="round" transform={`rotate(${i * 30})`} />)}</g>
        <circle r={100} fill="#fde047" stroke={OL} strokeWidth={9} />
        <circle cx={-32} cy={-14} r={10} fill="#111" /><circle cx={32} cy={-14} r={10} fill="#111" /><path d="M-30 26 Q0 50 30 26" fill="none" stroke="#111" strokeWidth={8} strokeLinecap="round" />
      </svg>
      <div style={{position: 'absolute', inset: -r, borderRadius: '50%', background: 'radial-gradient(circle, rgba(253,224,71,0.45), transparent 60%)'}} />
    </div>
  );
};

/* sunVanish: { goneOnWord?, tag, tag2?, tag2OnWord? } — the Sun pops out of existence in a flash; its last light keeps flowing to a happy, unaware Earth; a timer runs. */
const SunVanish: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const gAt = at(captions, scene.goneOnWord, fps, 8), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.7);
  const on = interpolate(frame, [gAt, gAt + 4], [1, 0], clamp), flash = interpolate(frame - gAt, [0, 2, 10], [0, 1, 0], clamp);
  const sec = Math.round(interpolate(frame, [gAt, dur], [500, 470], clamp));
  const tail = Math.max(0, frame - gAt) * 2.5;
  return (
    <Shake at={gAt} amount={30}>
      <Camera dur={dur} from={1.15} to={1.0}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 30%, #1e1b4b, #020617 70%)'}} />
        <Stars />
        <Sun x={540} y={430} r={150} on={on} />
        {frame >= gAt ? <div style={{position: 'absolute', left: 540 - 150, top: 430 - 150, width: 300, height: 300, borderRadius: '50%', border: '8px dashed #fde04788'}} /> : null}
        {/* the last light still on its way */}
        <div style={{position: 'absolute', left: 500, top: 560 + tail, width: 80, height: Math.max(0, 420 - tail), background: 'linear-gradient(180deg, rgba(253,224,71,0.85), rgba(253,224,71,0.25))', borderRadius: 40}} />
        <Earth x={540} y={1130} r={170} mood="happy" />
        <div style={{position: 'absolute', left: 300, top: 1370, width: 480, textAlign: 'center', opacity: frame >= gAt ? 1 : 0}}>
          <span style={{fontFamily: DISPLAY, fontSize: 110, color: '#fde047', background: '#111', border: `8px solid ${OL}`, borderRadius: 20, padding: '0 30px', fontVariantNumeric: 'tabular-nums'}}>{Math.floor(sec / 60)}:{String(sec % 60).padStart(2, '0')}</span>
        </div>
        {frame < gAt ? <Tag text={(scene.pre as string) ?? 'WHAT IF...'} at={0} y={160} size={110} color="#fff" rot={-3} /> : null}
        <Tag text={(scene.tag as string) ?? ''} at={gAt} y={160} size={110} color="#ef4444" fg="#fff" rot={-3} />
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} x={540} y={560} size={70} color="#fff" rot={3} /> : null}
        <AbsoluteFill style={{background: '#fff', opacity: flash}} />
      </Camera>
    </Shake>
  );
};

/* orbitEmpty: { tag, tagOnWord?, flyOnWord, tag2? } — Earth keeps circling an empty spot, then shoots off in a straight line. */
const OrbitEmpty: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 8), fAt = at(captions, scene.flyOnWord, fps, dur * 0.6);
  const cx = 540, cy = 900, R = 330;
  const angAt = (f: number) => -Math.PI / 2 + f * 0.05;
  const a = angAt(Math.min(frame, fAt));
  let ex = cx + Math.cos(a) * R, ey = cy + Math.sin(a) * R;
  if (frame > fAt) { const k = (frame - fAt) * 22; ex += -Math.sin(a) * k; ey += Math.cos(a) * k; }
  return (
    <Shake at={fAt} amount={18}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 46%, #1e1b4b, #020617 70%)'}} />
        <Stars />
        <div style={{position: 'absolute', left: cx - R, top: cy - R, width: R * 2, height: R * 2, borderRadius: '50%', border: '6px dashed #ffffff55'}} />
        <div style={{position: 'absolute', left: cx - 90, top: cy - 90, width: 180, height: 180, borderRadius: '50%', border: '8px dashed #fde04788'}} />
        <div style={{position: 'absolute', left: cx - 120, top: cy - 40, width: 240, textAlign: 'center', fontFamily: DISPLAY, fontSize: 64, color: '#ffffff99'}}>???</div>
        {frame > fAt ? <svg width={1080} height={1920} style={{position: 'absolute'}}><line x1={cx + Math.cos(a) * R} y1={cy + Math.sin(a) * R} x2={ex} y2={ey} stroke="#fde047" strokeWidth={10} strokeDasharray="20 18" /></svg> : null}
        <Earth x={ex} y={ey} r={100} mood={frame > fAt ? 'shock' : 'happy'} />
        <Tag text={(scene.tag as string) ?? ''} at={tAt} y={190} size={84} color="#fff" rot={-3} />
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={fAt} y={340} size={84} color="#fde047" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* skyBlack: { darkOnWord, moonOnWord?, tag?, tag2? } — sunny town; the sky snaps to black, the Moon blinks out, the person freezes in shock. */
const SkyBlack: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const dAt = at(captions, scene.darkOnWord, fps, dur * 0.3), mAt = at(captions, scene.moonOnWord, fps, dur * 0.65);
  const dark = interpolate(frame, [dAt, dAt + 3], [0, 1], clamp), moon = frame >= mAt ? interpolate(frame, [mAt, mAt + 6], [1, 0.08], clamp) : 1;
  return (
    <Shake at={dAt} amount={24}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #38bdf8, #bae6fd)'}} />
        <AbsoluteFill style={{background: '#020617', opacity: dark}} />
        {dark > 0.5 ? <Stars n={60} /> : null}
        {dark < 0.5 ? <Sun x={800} y={420} r={90} /> : null}
        <div style={{position: 'absolute', left: 170, top: 330, width: 150, height: 150, borderRadius: '50%', background: '#f1f5f9', border: `8px solid ${OL}`, opacity: moon, boxShadow: moon > 0.5 && dark > 0.5 ? '0 0 60px #e2e8f0' : 'none'}}><div style={{position: 'absolute', left: 30, top: 40, width: 30, height: 30, borderRadius: '50%', background: '#cbd5e1'}} /><div style={{position: 'absolute', left: 80, top: 80, width: 22, height: 22, borderRadius: '50%', background: '#cbd5e1'}} /></div>
        {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: 40 + i * 260, top: 800 - (i % 2) * 80, width: 220, height: 500 + (i % 2) * 80, background: dark > 0.5 ? '#1e293b' : ['#fca5a5', '#fde68a', '#a5b4fc', '#86efac'][i], border: `9px solid ${OL}`}}>{[0, 1, 2, 3].map((k) => <div key={k} style={{position: 'absolute', left: 30 + (k % 2) * 90, top: 40 + Math.floor(k / 2) * 120, width: 60, height: 70, background: dark > 0.5 ? '#0f172a' : '#e0f2fe', border: `6px solid ${OL}`}} />)}</div>)}
        <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: dark > 0.5 ? '#0f172a' : '#64748b', borderTop: `10px solid ${OL}`}} />
        <Boy x={540} y={1350} height={520} stage="adult" skin={sb.character.palette.skin} rim={dark > 0.5 ? '#94a3b8' : '#fff'} glow={0.5} mood={dark > 0.5 ? 'shock' : 'happy'} />
        {scene.tag ? <Tag text={scene.tag as string} at={dAt} y={180} size={100} color="#fff" rot={-3} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={mAt} x={360} y={540} size={70} color="#a5b4fc" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* freezeDrop: { steps: [{label, temp, onWord}], iceOnWord?, tag? } — a giant thermometer plunges while Earth turns icy. */
const FreezeDrop: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const steps = (scene.steps as {label: string; temp: string; onWord?: string}[]) ?? [];
  const ats = steps.map((s, i) => at(captions, s.onWord, fps, 10 + i * 30));
  const iAt = at(captions, scene.iceOnWord, fps, dur * 0.75);
  const lvl = interpolate(frame, [0, ...ats.map((a) => a + 8)], [0.75, ...steps.map((_, i) => 0.5 - i * 0.32)], clamp);
  const ice = interpolate(frame, [ats[0] ?? 0, iAt + 10], [0, 1], clamp);
  const cur = ats.reduce((c, a, i) => (frame >= a ? i : c), -1);
  return (
    <Shake at={ats[1] ?? 0} amount={16}>
      <Camera dur={dur} from={1.0} to={1.06}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0c4a6e, #082f49)'}} />
        <Stars n={50} />
        {new Array(30).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: ((random(`f${i}`) * 1200 + frame * 3) % 1200) - 60, top: ((random(`fy${i}`) * 1900 + frame * 7) % 1900), width: 12, height: 12, borderRadius: 6, background: '#fff', opacity: ice * 0.8}} />)}
        <div style={{position: 'absolute', left: 120, top: 420, width: 110, height: 760, background: '#fff', border: `10px solid ${OL}`, borderRadius: 55, overflow: 'hidden'}}>
          <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: `${Math.max(6, lvl * 100)}%`, background: lvl > 0.5 ? '#ef4444' : '#3b82f6'}} />
        </div>
        <div style={{position: 'absolute', left: 90, top: 1140, width: 170, height: 170, borderRadius: '50%', background: lvl > 0.5 ? '#ef4444' : '#3b82f6', border: `10px solid ${OL}`}} />
        <Earth x={680} y={1080} r={210} mood={ice > 0.5 ? 'cold' : 'sad'} ice={ice} />
        {cur >= 0 ? <div style={{position: 'absolute', left: 300, top: 300, width: 720, textAlign: 'center'}}>
          <div style={{fontFamily: DISPLAY, fontSize: 72, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>{steps[cur].label}</div>
          <div style={{fontFamily: DISPLAY, fontSize: 200, lineHeight: 1, color: '#7dd3fc', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill', scale: String(1 + (1 - spring({frame: frame - ats[cur], fps, config: {damping: 9}})) * 0.5)}}>{steps[cur].temp}</div>
        </div> : null}
        {scene.tag ? <Tag text={scene.tag as string} at={iAt} x={680} y={1340} size={70} color="#e0f2fe" rot={-2} /> : null}
      </Camera>
    </Shake>
  );
};

/* ventLife: { answer, answerOnWord?, tag?, tagOnWord? } — under a thick ice lid, a glowing vent; cheerful shrimp and microbes party in the warmth. */
const VentLife: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const aAt = at(captions, scene.answerOnWord, fps, 8), tAt = at(captions, scene.tagOnWord, fps, dur * 0.65);
  return (
    <Shake at={aAt} amount={16}>
      <Camera dur={dur} from={1.12} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0c4a6e 0%, #082f49 40%, #020617 100%)'}} />
        <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 260, background: 'linear-gradient(180deg, #f8fafc, #bae6fd)', borderBottom: `10px solid ${OL}`}}>{[0, 1, 2, 3, 4].map((i) => <div key={i} style={{position: 'absolute', left: 80 + i * 210, top: 230, width: 0, height: 0, borderLeft: '22px solid transparent', borderRight: '22px solid transparent', borderTop: '60px solid #bae6fd'}} />)}</div>
        <div style={{position: 'absolute', left: 110, top: 280, fontFamily: DISPLAY, fontSize: 52, color: '#e0f2fe', opacity: 0.8}}>ICE</div>
        {/* sea floor + vent */}
        <svg width={1080} height={700} style={{position: 'absolute', top: 1240}}><path d="M0 120 Q200 60 380 110 L460 0 H620 L700 110 Q880 60 1080 120 V700 H0 Z" fill="#292524" stroke={OL} strokeWidth={10} strokeLinejoin="round" /></svg>
        <div style={{position: 'absolute', left: 540 - 300, top: 900, width: 600, height: 500, borderRadius: '50%', background: 'radial-gradient(circle, rgba(251,146,60,0.55), transparent 65%)'}} />
        {[0, 1, 2, 3, 4].map((i) => { const p = ((frame + i * 9) % 45) / 45; return <div key={i} style={{position: 'absolute', left: 520 + Math.sin(frame / 7 + i) * 30 - p * 20, top: 1220 - p * 520, width: 60 + p * 120, height: 60 + p * 120, borderRadius: '50%', background: '#a8a29e', opacity: 0.55 * (1 - p)}} />; })}
        {new Array(7).fill(0).map((_, i) => { const x = 180 + i * 120 + Math.sin(frame / 9 + i) * 14, y = 1150 + (i % 3) * 50 + Math.cos(frame / 8 + i) * 10; return (
          <svg key={i} width={110} height={70} viewBox="0 0 110 70" style={{position: 'absolute', left: x - 55, top: y - 35, scale: i % 2 ? '-1 1' : '1'}}>
            <path d="M10 40 Q30 6 70 14 Q100 22 96 44 Q80 62 40 58 Q14 56 10 40 Z" fill={i % 2 ? '#fda4af' : '#fdba74'} stroke={OL} strokeWidth={6} />
            <path d="M96 34 q14 -20 4 -30 M96 40 q18 -10 12 -26" fill="none" stroke={OL} strokeWidth={4} /><circle cx={78} cy={28} r={6} fill="#111" /><path d="M66 42 q8 6 16 0" stroke="#111" strokeWidth={4} fill="none" strokeLinecap="round" />
          </svg>); })}
        <Tag text={(scene.answer as string) ?? ''} at={aAt} y={420} size={92} color="#4ade80" rot={-3} />
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={580} size={72} color="#fde047" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* sunLate: { tag, tagOnWord?, cta?, ctaOnWord? } — back to a sunny day; the person looks up at the Sun; a "8 MIN OLD" stamp lands on the sunlight. */
const SunLate: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.4), cAt = at(captions, scene.ctaOnWord, fps, dur * 0.8);
  const s = spring({frame: frame - tAt, fps, config: {damping: 8, stiffness: 200}});
  return (
    <Shake at={tAt} amount={16}>
      <Camera dur={dur} from={1.0} to={1.1}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #38bdf8, #e0f2fe)'}} />
        <Sun x={720} y={460} r={130} />
        <div style={{position: 'absolute', left: 0, top: 1250, width: 1080, height: 700, background: '#4ade80', borderTop: `10px solid ${OL}`}} />
        <Boy x={380} y={1330} height={560} stage="adult" skin={sb.character.palette.skin} rim="#fff" glow={0.5} mood={frame >= tAt ? 'shock' : 'happy'} />
        <div style={{position: 'absolute', left: 0, right: 0, top: 780, textAlign: 'center', opacity: frame >= tAt ? 1 : 0, scale: String(2.4 - s * 1.4), rotate: '-8deg'}}>
          <span style={{position: 'relative', left: 160, fontFamily: DISPLAY, fontSize: 110, color: '#ef4444', border: '12px solid #ef4444', padding: '0 30px', borderRadius: 22, background: '#ffffffd0'}}>{(scene.stamp as string) ?? '8 MIN OLD'}</span>
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={0} y={180} size={84} color="#fff" rot={-3} /> : null}
        {scene.cta ? <Tag text={scene.cta as string} at={cAt} y={1060} x={420} size={74} color="#ef4444" fg="#fff" rot={-2} /> : null}
      </Camera>
    </Shake>
  );
};

export const SPACE1_SCENES: Record<string, React.FC<SceneProps>> = {
  sunVanish: SunVanish,
  orbitEmpty: OrbitEmpty,
  skyBlack: SkyBlack,
  freezeDrop: FreezeDrop,
  ventLife: VentLife,
  sunLate: SunLate,
};
