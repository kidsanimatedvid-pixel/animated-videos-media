import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {Skyline, wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Story scenes, set 3: scooter commute, height line-up, back-to-back trophies. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const Chip: React.FC<{text: string; at: number; top: number; color: string; size?: number}> = ({text, at, top, color, size = 92}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - at, fps, config: {damping: 11, stiffness: 160}});
  return (
    <div style={{position: 'absolute', top, width: '100%', textAlign: 'center', opacity: s, scale: String(0.6 + s * 0.4), rotate: `${(1 - s) * -8}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: '#000', background: color, padding: '6px 34px', borderRadius: 14,
        boxShadow: `0 0 60px ${color}88`, letterSpacing: 2}}>{text}</span>
    </div>
  );
};

/* scooterRide: { stage?, chip?, chipOnWord? } — the hero kicks a small scooter along a dawn street; city scrolls past. */
const ScooterRide: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const stage = (scene.stage as 'child' | 'teen' | 'adult') ?? 'teen';
  const chipAt = scene.chipOnWord ? wordFrame(captions, scene.chipOnWord as string, fps, dur * 0.5) : dur * 0.5;
  const far = (frame * 3) % 1080;
  const near = (frame * 9) % 1080;
  const kick = Math.sin(frame / 4.5);
  const bob = Math.abs(Math.sin(frame / 4.5)) * 4;
  const H = stage === 'child' ? 300 : 380;
  const feetY = 1290;
  return (
    <Shake at={chipAt} amount={14}>
      <Camera dur={dur} from={1.1} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0d1230 0%, #3a2a5a 38%, #e07a4a 70%, #2a1a1a 100%)'}} />
        <div style={{position: 'absolute', left: 640, top: 760, width: 260, height: 260, borderRadius: '50%',
          background: 'radial-gradient(circle, #ffd9a0 0%, #ff9a5a 45%, transparent 70%)', filter: 'blur(4px)', opacity: 0.85}} />
        {[0, 1].map((k) => (
          <div key={`f${k}`} style={{position: 'absolute', left: k * 1080 - far, top: 0, width: 1080, height: 1920}}>
            <Skyline y={1040} color="#2a1c34" seed="kfar" height={300} windows="#ffcf8a" />
          </div>
        ))}
        {[0, 1].map((k) => (
          <div key={`n${k}`} style={{position: 'absolute', left: k * 1080 - near, top: 0, width: 1080, height: 1920}}>
            <Skyline y={1180} color="#140d18" seed="knear" height={360} />
            {[120, 480, 840].map((lx) => (
              <svg key={lx} width={80} height={520} style={{position: 'absolute', left: lx, top: 780}}>
                <rect x={36} y={30} width={8} height={490} fill="#0c0810" />
                <rect x={20} y={20} width={44} height={14} rx={5} fill="#0c0810" />
                <ellipse cx={42} cy={40} rx={18} ry={6} fill="#ffe2a8" />
              </svg>
            ))}
          </div>
        ))}
        {/* lamp glow */}
        <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 70%, rgba(255,190,120,0.22), transparent 60%)'}} />
        {/* road */}
        <svg width={1080} height={700} style={{position: 'absolute', top: feetY + 30}}>
          <rect width={1080} height={700} fill="#0a080c" />
          {new Array(8).fill(0).map((_, i) => (
            <rect key={i} x={((i * 200 - frame * 16) % 1600 + 1600) % 1600 - 260} y={60} width={110} height={10} fill="#e9c27a" opacity={0.55} />
          ))}
        </svg>
        {/* speed streaks */}
        {new Array(14).fill(0).map((_, i) => {
          const y = 600 + random(`ss${i}`) * 760;
          const x = 1200 - ((frame * (30 + random(`sv${i}`) * 30) + random(`sx${i}`) * 1400) % 1500);
          return <div key={i} style={{position: 'absolute', left: x, top: y, width: 160, height: 3, background: 'rgba(255,230,200,0.35)'}} />;
        })}
        {/* scooter */}
        <svg width={1080} height={400} style={{position: 'absolute', top: feetY - 300 - bob}}>
          <g fill="#07060a" stroke={sb.character.palette.rim} strokeWidth={2.5} strokeOpacity={0.7}>
            <rect x={455} y={292} width={170} height={14} rx={7} />
            <rect x={612} y={90} width={10} height={210} rx={4} transform="rotate(8 617 300)" />
            <rect x={580} y={82} width={80} height={10} rx={5} />
          </g>
          {[470, 625].map((wx) => (
            <g key={wx}>
              <circle cx={wx} cy={318} r={20} fill="#07060a" stroke={sb.character.palette.rim} strokeWidth={3} />
              <line x1={wx} y1={318} x2={wx + 16 * Math.cos(frame / 2)} y2={318 + 16 * Math.sin(frame / 2)} stroke="#555" strokeWidth={3} />
            </g>
          ))}
        </svg>
        <div style={{position: 'absolute', inset: 0, translate: `0px ${-bob}px`}}>
          <Boy x={545} y={feetY - 8} height={H} stage={stage} pose="run" phase={kick * 0.5}
            skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.85} />
        </div>
        {scene.chip ? <Chip text={scene.chip as string} at={chipAt} top={330} color={sb.palette.gold} /> : null}
      </Camera>
    </Shake>
  );
};

/* heightLine: { labels: [{text, onWord}] } — the small hero stands in a line-up of much bigger players;
   verdict labels slam in on cue. */
const HeightLine: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const labels = (scene.labels as {text: string; onWord?: string}[]) ?? [];
  const ats = labels.map((l, i) => (l.onWord ? wordFrame(captions, l.onWord, fps, 15 + i * 30) : 15 + i * 30));
  const others = [130, 330, 750, 950];
  const spot = 0.75 + 0.25 * Math.sin(frame / 9);
  return (
    <Shake at={ats[0] ?? 0} amount={16}>
      <Camera dur={dur} from={1.0} to={1.1} panY={-30}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #05060a 0%, #10131c 60%, #1a1c22 100%)'}} />
        {/* measuring wall */}
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          {new Array(14).fill(0).map((_, i) => (
            <g key={i}>
              <line x1={0} x2={1080} y1={1320 - i * 50} y2={1320 - i * 50} stroke="rgba(255,255,255,0.07)" strokeWidth={2} />
              <text x={24} y={1314 - i * 50} fill="rgba(255,255,255,0.18)" fontSize={22} fontFamily="Inter">{120 + i * 5}</text>
            </g>
          ))}
          <rect x={0} y={1320} width={1080} height={600} fill="#0b0c10" />
        </svg>
        {/* spotlight on the hero */}
        <div style={{position: 'absolute', left: 340, top: 300, width: 400, height: 1100,
          background: `linear-gradient(180deg, rgba(255,230,180,${0.25 * spot}), transparent 90%)`, clipPath: 'polygon(40% 0, 60% 0, 100% 100%, 0 100%)'}} />
        {others.map((x, i) => (
          <Boy key={x} x={x} y={1320} height={560 + (i % 2) * 40} stage="adult" hair="short" skin="#15171d" rim="#5b6070" glow={0.25} flip={i > 1} />
        ))}
        <Boy x={540} y={1320} height={330} stage="teen" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={1} />
        {labels.map((l, i) => {
          const s = spring({frame: frame - ats[i], fps, config: {damping: 9, stiffness: 220}});
          return (
            <div key={i} style={{position: 'absolute', top: 360 + i * 190, width: '100%', textAlign: 'center',
              opacity: frame >= ats[i] ? 1 : 0, scale: String(2.2 - s * 1.2), rotate: `${i % 2 ? 4 : -5}deg`}}>
              <span style={{fontFamily: DISPLAY, fontSize: 132, color: sb.palette.accent, border: `10px solid ${sb.palette.accent}`,
                padding: '0 30px', borderRadius: 18, background: 'rgba(0,0,0,0.55)'}}>{l.text}</span>
            </div>
          );
        })}
      </Camera>
    </Shake>
  );
};

const Trophy: React.FC<{x: number; y: number; s: number; ribbon: string}> = ({x, y, s, ribbon}) => (
  <svg width={260} height={340} style={{position: 'absolute', left: x - 130, top: y - 340, scale: String(s), transformOrigin: '50% 100%'}}>
    <defs>
      <linearGradient id={`tg${ribbon}`} x1="0" x2="1">
        <stop offset="0" stopColor="#8a5a10" /><stop offset="0.45" stopColor="#ffe08a" /><stop offset="1" stopColor="#a8701a" />
      </linearGradient>
    </defs>
    <path d="M60 30 H200 V90 C200 160 160 190 130 195 C100 190 60 160 60 90 Z" fill={`url(#tg${ribbon})`} />
    <path d="M60 50 C10 50 10 120 70 140 M200 50 C250 50 250 120 190 140" stroke="#d9a84a" strokeWidth={12} fill="none" />
    <rect x={118} y={195} width={24} height={60} fill={`url(#tg${ribbon})`} />
    <rect x={75} y={255} width={110} height={26} rx={6} fill={`url(#tg${ribbon})`} />
    <rect x={60} y={281} width={140} height={50} rx={8} fill="#1a1410" />
    <path d={`M100 100 L130 60 L160 100`} stroke={ribbon} strokeWidth={10} fill="none" />
  </svg>
);

/* twoTrophies: { items: [{label, sub, onWord, ribbon}], topText?, topOnWord? } — trophies land one after another. */
const TwoTrophies: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const items = (scene.items as {label: string; sub?: string; onWord?: string; ribbon?: string}[]) ?? [];
  const ats = items.map((it, i) => (it.onWord ? wordFrame(captions, it.onWord, fps, 10 + i * 40) : 10 + i * 40));
  const topAt = scene.topOnWord ? wordFrame(captions, scene.topOnWord as string, fps, dur * 0.7) : dur * 0.7;
  const xs = items.length === 1 ? [540] : [300, 780];
  return (
    <Shake at={ats[1] ?? ats[0] ?? 0} amount={16}>
      <Camera dur={dur} from={1.08} to={1.0}>
        <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 55%, #2a1e08 0%, #0a0806 60%, #050403 100%)'}} />
        {new Array(40).fill(0).map((_, i) => {
          const x = random(`cf${i}`) * 1080;
          const y = ((random(`cy${i}`) * 1900 + frame * (6 + random(`cv${i}`) * 8)) % 1900);
          const on = frame >= (ats[0] ?? 0);
          return <div key={i} style={{position: 'absolute', left: x, top: y, width: 12, height: 22, rotate: `${frame * 6 + i * 40}deg`,
            background: i % 3 ? sb.palette.gold : '#fff', opacity: on ? 0.7 : 0}} />;
        })}
        {items.map((it, i) => {
          const s = spring({frame: frame - ats[i], fps, config: {damping: 10, stiffness: 140}});
          const glow = frame >= ats[i] ? 1 : 0;
          return (
            <React.Fragment key={i}>
              <div style={{position: 'absolute', left: xs[i] - 220, top: 560, width: 440, height: 600, opacity: glow * 0.9,
                background: 'radial-gradient(circle, rgba(255,210,110,0.45), transparent 65%)'}} />
              <Trophy x={xs[i]} y={1000} s={s * 1.25} ribbon={it.ribbon ?? '#ffffff'} />
              <div style={{position: 'absolute', left: xs[i] - 240, width: 480, top: 1030, textAlign: 'center', opacity: s}}>
                <div style={{fontFamily: DISPLAY, fontSize: 104, color: '#fff', WebkitTextStroke: '5px #000', paintOrder: 'stroke fill'}}>{it.label}</div>
                {it.sub ? <div style={{fontFamily: DISPLAY, fontSize: 48, color: sb.palette.gold, letterSpacing: 3}}>{it.sub}</div> : null}
              </div>
            </React.Fragment>
          );
        })}
        {scene.topText ? <Chip text={scene.topText as string} at={topAt} top={330} color={sb.palette.gold} size={96} /> : null}
      </Camera>
    </Shake>
  );
};

export const STORY3_SCENES: Record<string, React.FC<SceneProps>> = {
  scooterRide: ScooterRide,
  heightLine: HeightLine,
  twoTrophies: TwoTrophies,
};
