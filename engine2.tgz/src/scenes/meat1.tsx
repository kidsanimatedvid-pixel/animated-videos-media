import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Food scenes, set 1 (cartoon): steakPrice, workRest, cowMap, slowPot, hotPan. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Steak: React.FC<{x: number; y: number; w: number; rot?: number; lean?: boolean}> = ({x, y, w, rot = 0, lean}) => (
  <svg width={w} height={w * 0.75} viewBox="0 0 400 300" style={{position: 'absolute', left: x - w / 2, top: y - w * 0.375, rotate: `${rot}deg`, overflow: 'visible'}}>
    <path d="M60 60 Q160 0 280 40 Q390 80 370 180 Q350 280 220 280 Q120 290 60 230 Q0 150 60 60 Z" fill="#fef3c7" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
    <path d="M84 84 Q170 36 270 66 Q350 96 336 176 Q320 250 216 252 Q130 258 86 212 Q40 150 84 84 Z" fill={lean ? '#b91c1c' : '#ef4444'} stroke={OL} strokeWidth={8} />
    {lean ? <path d="M110 120 Q200 100 300 140 M120 190 Q210 170 290 200" fill="none" stroke="#7f1d1d" strokeWidth={9} strokeLinecap="round" /> : <path d="M120 110 q30 20 60 -6 q30 30 70 4 M110 170 q40 -20 70 10 q40 -24 90 6 M150 220 q40 -18 90 0" fill="none" stroke="#fecaca" strokeWidth={9} strokeLinecap="round" />}
    <circle cx={110} cy={90} r={9} fill="#ffffffaa" />
  </svg>
);

/* steakPrice: { left, right, leftPrice, rightPrice, rightOnWord?, tag?, tagOnWord? } — two steaks drop onto a butcher's board; one price tag explodes upward. */
const SteakPrice: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const rAt = at(captions, scene.rightOnWord, fps, 26), tAt = at(captions, scene.tagOnWord, fps, dur * 0.8);
  const d1 = spring({frame: frame - 2, fps, config: {damping: 10}}), d2 = spring({frame: frame - 8, fps, config: {damping: 10}});
  const ps = spring({frame: frame - rAt, fps, config: {damping: 7, stiffness: 180}});
  return (
    <Shake at={0} amount={24}>
      <Shake at={rAt} amount={20}>
        <Camera dur={dur} from={1.25} to={1.0}>
          <AbsoluteFill style={{background: 'linear-gradient(180deg, #fecaca, #fda4af)'}} />
          <AbsoluteFill style={{background: 'repeating-linear-gradient(0deg, rgba(255,255,255,0.35) 0 60px, transparent 60px 120px), repeating-linear-gradient(90deg, rgba(255,255,255,0.35) 0 60px, transparent 60px 120px)'}} />
          <div style={{position: 'absolute', left: 60, top: 700, width: 960, height: 420, background: '#d6a56b', border: `10px solid ${OL}`, borderRadius: 40, boxShadow: `0 16px 0 ${OL}`}} />
          <div style={{position: 'absolute', left: 0, top: 1290, width: 1080, height: 700, background: '#9f1239', borderTop: `10px solid ${OL}`}} />
          <div style={{position: 'absolute', left: 0, top: -(1 - d1) * 900}}><Steak x={300} y={910} w={380} rot={-8} lean /></div>
          <div style={{position: 'absolute', left: 0, top: -(1 - d2) * 900}}><Steak x={770} y={910} w={380} rot={7} /></div>
          <Tag text={(scene.leftPrice as string) ?? '$'} at={12} x={300} y={585} size={96} color="#fff" rot={-5} />
          <div style={{position: 'absolute', left: 770 - 500, width: 1000, top: 575, textAlign: 'center', opacity: frame >= rAt ? 1 : 0, scale: String(2.4 - ps * 1.4), rotate: '5deg'}}>
            <span style={{fontFamily: DISPLAY, fontSize: 120, color: '#111', background: '#fde047', padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{(scene.rightPrice as string) ?? '$$$$$'}</span>
          </div>
          <Boy x={540} y={1360} height={330} stage="adult" hair="long" skin={sb.character.palette.skin} rim="#fff" glow={0.5} mood={frame >= rAt ? 'shock' : 'happy'} />
          {scene.tag ? <Tag text={scene.tag as string} at={0} y={230} size={96} color="#fff" rot={-3} /> : null}
          {scene.tag2 ? <Tag text={scene.tag2 as string} at={tAt} y={375} size={110} color="#ef4444" fg="#fff" rot={3} /> : null}
        </Camera>
      </Shake>
    </Shake>
  );
};

/* A little muscle character. kind: 'buff' lifts a dumbbell and sweats; 'lazy' snoozes. */
const Muscle: React.FC<{x: number; y: number; kind: 'buff' | 'lazy'}> = ({x, y, kind}) => {
  const frame = useCurrentFrame();
  const lift = Math.abs(Math.sin(frame / 5)) * 60, br = Math.sin(frame / 14) * 6;
  const buff = kind === 'buff';
  return (
    <svg width={420} height={480} viewBox="0 0 420 480" style={{position: 'absolute', left: x - 210, top: y - 480, overflow: 'visible'}}>
      {buff ? <g transform={`translate(0 ${-lift})`}><rect x={70} y={96} width={280} height={18} rx={8} fill="#475569" stroke={OL} strokeWidth={7} />{[40, 330].map((bx) => <rect key={bx} x={bx} y={56} width={50} height={98} rx={12} fill="#1e293b" stroke={OL} strokeWidth={8} />)}</g> : null}
      {buff ? <><path d={`M120 290 Q70 240 96 ${130 - lift}`} fill="none" stroke={OL} strokeWidth={50} strokeLinecap="round" /><path d={`M120 290 Q70 240 96 ${130 - lift}`} fill="none" stroke="#dc2626" strokeWidth={34} strokeLinecap="round" /><path d={`M300 290 Q350 240 324 ${130 - lift}`} fill="none" stroke={OL} strokeWidth={50} strokeLinecap="round" /><path d={`M300 290 Q350 240 324 ${130 - lift}`} fill="none" stroke="#dc2626" strokeWidth={34} strokeLinecap="round" /></> : null}
      <ellipse cx={210} cy={buff ? 330 : 360 + br * 0.5} rx={buff ? 130 : 150} ry={buff ? 140 : 100 + br} fill={buff ? '#dc2626' : '#fda4af'} stroke={OL} strokeWidth={12} />
      {buff ? <path d="M130 300 Q210 260 290 300 M140 370 Q210 340 280 370" fill="none" stroke="#991b1b" strokeWidth={9} strokeLinecap="round" /> : null}
      {buff ? <><path d="M150 286 L190 300 M270 286 L230 300" stroke="#111" strokeWidth={10} strokeLinecap="round" /><circle cx={172} cy={318} r={11} fill="#111" /><circle cx={248} cy={318} r={11} fill="#111" /><path d="M175 372 H245" stroke="#111" strokeWidth={11} strokeLinecap="round" /></>
        : <><path d="M150 348 q20 16 40 0 M230 348 q20 16 40 0" fill="none" stroke="#111" strokeWidth={10} strokeLinecap="round" /><path d="M185 390 q25 18 50 0" fill="none" stroke="#111" strokeWidth={10} strokeLinecap="round" /></>}
      {buff ? [0, 1].map((i) => { const p = ((frame + i * 12) % 24) / 24; return <path key={i} d="M0 0 q-12 22 0 30 q12 -8 0 -30" transform={`translate(${i ? 356 : 64} ${250 + p * 70})`} fill="#7dd3fc" stroke={OL} strokeWidth={5} opacity={1 - p} />; })
        : [0, 1, 2].map((i) => { const p = ((frame + i * 16) % 48) / 48; return <text key={i} x={300 + p * 60} y={250 - p * 110} fontFamily="Anton" fontSize={40 + p * 40} fill="#fff" stroke={OL} strokeWidth={5} paintOrder="stroke" opacity={1 - p}>Z</text>; })}
    </svg>
  );
};

/* workRest: { left:{top,bottom,onWord}, right:{top,bottom,onWord}, title? } — a sweating gym muscle versus a snoozing couch muscle. */
const WorkRest: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = (scene.left as {top: string; bottom: string; onWord?: string}) ?? {top: '', bottom: ''}, R = (scene.right as {top: string; bottom: string; onWord?: string}) ?? {top: '', bottom: ''};
  const lAt = at(captions, L.onWord, fps, 12), rAt = at(captions, R.onWord, fps, dur * 0.6);
  return (
    <Camera dur={dur} from={1.06} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(90deg, #fca5a5 0 50%, #bbf7d0 50% 100%)'}} />
      <div style={{position: 'absolute', left: 535, top: 0, width: 10, height: 1920, background: OL}} />
      <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: 'linear-gradient(90deg, #991b1b 0 50%, #166534 50% 100%)', borderTop: `10px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 580, top: 1090, width: 460, height: 200, background: '#7c3aed', border: `10px solid ${OL}`, borderRadius: 40}} /><div style={{position: 'absolute', left: 566, top: 990, width: 488, height: 140, background: '#8b5cf6', border: `10px solid ${OL}`, borderRadius: 40}} />
      <Muscle x={270} y={1290} kind="buff" />
      <Muscle x={810} y={1190} kind="lazy" />
      {scene.title ? <Tag text={scene.title as string} at={0} y={210} size={72} color="#fff" rot={-2} /> : null}
      <Tag text={L.top} at={lAt} x={270} y={380} size={70} color="#fff" rot={-4} />
      <Tag text={L.bottom} at={lAt + 8} x={270} y={520} size={110} color="#ef4444" fg="#fff" rot={-4} />
      <Tag text={R.top} at={rAt} x={810} y={380} size={70} color="#fff" rot={4} />
      <Tag text={R.bottom} at={rAt + 8} x={810} y={520} size={104} color="#22c55e" fg="#fff" rot={4} />
    </Camera>
  );
};

/* cowMap: { zones: [{id, onWord}], note?, noteOnWord? } — side-on cartoon cow; cut zones light red (hard workers) or green (lazy) as they are named.
   ids: chuck, brisket, shank, round, rib, loin */
const ZONES: Record<string, {d: string; lx: number; ly: number; label: string; lazy?: boolean}> = {
  chuck: {d: 'M230 560 H400 V760 H210 Q200 640 230 560 Z', lx: 310, ly: 640, label: 'CHUCK'},
  brisket: {d: 'M210 760 H400 V900 Q280 910 230 870 Q210 820 210 760 Z', lx: 305, ly: 810, label: 'BRISKET'},
  rib: {d: 'M400 560 H560 V760 H400 Z', lx: 480, ly: 640, label: 'RIB', lazy: true},
  loin: {d: 'M560 560 H740 V760 H560 Z', lx: 650, ly: 640, label: 'LOIN', lazy: true},
  round: {d: 'M740 560 H870 Q930 600 930 720 Q930 860 880 900 H740 Z', lx: 835, ly: 720, label: 'ROUND'},
  shank: {d: 'M250 900 H330 V1130 H250 Z M790 900 H870 V1130 H790 Z', lx: 290, ly: 1170, label: 'SHANK'},
};
const CowMap: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const zs = (scene.zones as {id: string; onWord?: string}[]) ?? [];
  const nAt = at(captions, scene.noteOnWord, fps, dur * 0.85);
  const on: Record<string, number> = {};
  zs.forEach((z, i) => { on[z.id] = at(captions, z.onWord, fps, 10 + i * 16); });
  return (
    <Camera dur={dur} from={1.0} to={1.05}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #7dd3fc 0%, #bae6fd 62%, #4ade80 63%, #15803d 100%)'}} />
      {[0, 1].map((i) => <div key={i} style={{position: 'absolute', left: ((i * 600 + frame * 0.5) % 1400) - 200, top: 250 + i * 90, width: 260, height: 80, borderRadius: 60, background: '#fff', opacity: 0.85}} />)}
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <path d="M930 640 Q1010 700 990 820" fill="none" stroke={OL} strokeWidth={22} strokeLinecap="round" /><path d="M930 640 Q1010 700 990 820" fill="none" stroke="#fef3c7" strokeWidth={10} strokeLinecap="round" />
        <path d="M250 900 H330 V1130 H250 Z M790 900 H870 V1130 H790 Z M420 890 H490 V1110 H420 Z M650 890 H720 V1110 H650 Z" fill="#fef3c7" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
        <path d="M230 560 H870 Q930 600 930 720 Q930 860 880 900 H400 Q280 910 230 870 Q200 760 230 560 Z" fill="#fef3c7" stroke={OL} strokeWidth={14} strokeLinejoin="round" />
        {Object.entries(ZONES).map(([id, z]) => { const a = on[id]; const s = a === undefined ? 0 : interpolate(frame, [a, a + 6], [0, 1], clamp); return <path key={id} d={z.d} fill={z.lazy ? '#22c55e' : '#ef4444'} opacity={s * 0.92} stroke={OL} strokeWidth={8} strokeLinejoin="round" />; })}
        <path d="M400 560 V900 M560 560 V900 M740 560 V900 M210 760 H740" fill="none" stroke={OL} strokeWidth={7} strokeDasharray="14 12" />
        {/* head */}
        <path d="M240 560 Q150 470 90 520 Q30 560 40 660 Q50 740 130 740 Q200 740 240 680 Z" fill="#fef3c7" stroke={OL} strokeWidth={14} strokeLinejoin="round" />
        <path d="M40 640 Q30 740 110 744 Q170 744 170 690 Q120 640 40 640 Z" fill="#fda4af" stroke={OL} strokeWidth={10} strokeLinejoin="round" />
        <circle cx={130} cy={590} r={13} fill="#111" /><circle cx={78} cy={700} r={7} fill="#111" /><circle cx={118} cy={706} r={7} fill="#111" />
        <path d="M150 500 Q130 440 180 450 M210 520 Q250 470 270 520" fill="none" stroke={OL} strokeWidth={14} strokeLinecap="round" />
        <path d="M560 600 Q620 580 700 620 Q680 700 600 690 Q550 660 560 600 Z" fill="#44403c" opacity={0.14} />
        {[250, 790, 420, 650].map((x, i) => <rect key={i} x={x} y={i < 2 ? 1100 : 1080} width={i < 2 ? 80 : 70} height={34} fill="#44403c" stroke={OL} strokeWidth={10} />)}
      </svg>
      {Object.entries(ZONES).map(([id, z]) => { const a = on[id]; if (a === undefined) return null; const s = spring({frame: frame - a, fps, config: {damping: 9, stiffness: 200}}); return (
        <div key={id} style={{position: 'absolute', left: z.lx - 200, width: 400, top: z.ly - 30, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.7 - s * 0.7)}}>
          <span style={{fontFamily: DISPLAY, fontSize: 46, color: '#fff', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>{z.label}</span></div>); })}
      {scene.title ? <Tag text={scene.title as string} at={0} y={230} size={76} color="#fff" rot={-2} /> : null}
      <div style={{position: 'absolute', left: 150, top: 1215, display: 'flex', gap: 20}}>
        {[{c: '#ef4444', t: 'WORKS HARD'}, {c: '#22c55e', t: 'BARELY MOVES'}].map((k) => <div key={k.t} style={{display: 'flex', alignItems: 'center', gap: 10, background: '#fff', border: `6px solid ${OL}`, borderRadius: 14, padding: '4px 16px'}}><div style={{width: 40, height: 40, borderRadius: 8, background: k.c, border: `5px solid ${OL}`}} /><span style={{fontFamily: DISPLAY, fontSize: 44, color: '#111'}}>{k.t}</span></div>)}
      </div>
      {scene.note ? <Tag text={scene.note as string} at={nAt} y={1305} size={54} color="#fde047" rot={0} /> : null}
    </Camera>
  );
};

/* slowPot: { tag, tagOnWord?, from, to, meltOnWord? } — a lidded pot simmers while a clock spins; a "COLLAGEN" bar melts into "GELATIN". */
const SlowPot: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 10), mAt = at(captions, scene.meltOnWord, fps, dur * 0.55);
  const m = interpolate(frame, [mAt, mAt + 30], [0, 1], clamp);
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e3a8a, #312e81)'}} />
      <div style={{position: 'absolute', left: 0, top: 1240, width: 1080, height: 700, background: '#1e1b4b', borderTop: `10px solid ${OL}`}} />
      {[0, 1, 2, 3].map((i) => { const p = ((frame + i * 14) % 56) / 56; return <div key={i} style={{position: 'absolute', left: 250 + i * 70 + Math.sin(frame / 9 + i) * 16, top: 800 - p * 220, width: 60 + p * 70, height: 60 + p * 70, borderRadius: '50%', background: '#e2e8f0', opacity: 0.5 * (1 - p)}} />; })}
      <svg width={560} height={420} viewBox="0 0 560 420" style={{position: 'absolute', left: 90, top: 830}}>
        <rect x={60} y={120} width={440} height={270} rx={40} fill="#ef4444" stroke={OL} strokeWidth={12} /><rect x={0} y={170} width={70} height={40} rx={14} fill="#991b1b" stroke={OL} strokeWidth={9} /><rect x={490} y={170} width={70} height={40} rx={14} fill="#991b1b" stroke={OL} strokeWidth={9} />
        <g transform={`translate(0 ${Math.sin(frame / 3) * 4}) rotate(${Math.sin(frame / 4) * 1.5} 280 110)`}><path d="M50 120 Q280 30 510 120 Z" fill="#fca5a5" stroke={OL} strokeWidth={12} strokeLinejoin="round" /><circle cx={280} cy={62} r={22} fill="#991b1b" stroke={OL} strokeWidth={9} /></g>
      </svg>
      {[0, 1, 2, 3, 4].map((i) => <div key={i} style={{position: 'absolute', left: 190 + i * 76, top: 1226 + Math.sin(frame / 2 + i) * 4, width: 44, height: 50 + Math.sin(frame / 3 + i * 2) * 10, borderRadius: '50% 50% 20% 20%', background: i % 2 ? '#fb923c' : '#60a5fa', border: `5px solid ${OL}`}} />)}
      <svg width={300} height={300} viewBox="0 0 300 300" style={{position: 'absolute', left: 700, top: 480}}>
        <circle cx={150} cy={150} r={130} fill="#fff" stroke={OL} strokeWidth={14} />{new Array(12).fill(0).map((_, i) => <rect key={i} x={146} y={32} width={8} height={22} fill={OL} transform={`rotate(${i * 30} 150 150)`} />)}
        <rect x={144} y={60} width={12} height={96} rx={6} fill="#ef4444" transform={`rotate(${frame * 14} 150 150)`} /><rect x={143} y={84} width={14} height={72} rx={7} fill={OL} transform={`rotate(${frame * 1.2} 150 150)`} /><circle cx={150} cy={150} r={12} fill={OL} />
      </svg>
      <div style={{position: 'absolute', left: 610, top: 880, width: 420, height: 130, borderRadius: 26, border: `9px solid ${OL}`, boxShadow: `0 10px 0 ${OL}`, overflow: 'hidden', background: '#e2e8f0'}}>
        <div style={{position: 'absolute', inset: 0, background: '#fde047', width: `${m * 100}%`}} />
        <div style={{position: 'absolute', inset: 0, textAlign: 'center', fontFamily: DISPLAY, fontSize: 74, lineHeight: '112px', color: '#111'}}>{m > 0.6 ? (scene.to as string) ?? 'GELATIN' : (scene.from as string) ?? 'COLLAGEN'}</div>
      </div>
      <div style={{position: 'absolute', left: 610, top: 1040, width: 420, textAlign: 'center', fontFamily: DISPLAY, fontSize: 52, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill', opacity: m > 0.6 ? 1 : 0}}>SOFT + JUICY</div>
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={240} size={110} color="#60a5fa" rot={-3} /> : null}
    </Camera>
  );
};

/* hotPan: { tag, tagOnWord? } — a steak slams into a flaming pan and sizzles. */
const HotPan: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.5);
  const d = spring({frame: frame - 6, fps, config: {damping: 9, stiffness: 160}});
  return (
    <Shake at={14} amount={20}>
      <Camera dur={dur} from={1.1} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #7c2d12, #ea580c 70%, #7c2d12)'}} />
        <div style={{position: 'absolute', left: 0, top: 1260, width: 1080, height: 700, background: '#431407', borderTop: `10px solid ${OL}`}} />
        {new Array(9).fill(0).map((_, i) => { const h = 150 + Math.sin(frame / 2 + i * 1.7) * 50; return <div key={i} style={{position: 'absolute', left: 190 + i * 70, top: 1250 - h, width: 80, height: h, borderRadius: '50% 50% 30% 30%', background: i % 2 ? '#fde047' : '#fb923c', border: `6px solid ${OL}`}} />; })}
        <svg width={960} height={260} viewBox="0 0 960 260" style={{position: 'absolute', left: 40, top: 960}}>
          <rect x={640} y={90} width={310} height={46} rx={20} fill="#1f2937" stroke={OL} strokeWidth={10} />
          <path d="M60 60 H680 Q690 220 600 240 H140 Q50 220 60 60 Z" fill="#374151" stroke={OL} strokeWidth={13} strokeLinejoin="round" /><ellipse cx={370} cy={64} rx={312} ry={40} fill="#111827" stroke={OL} strokeWidth={11} />
        </svg>
        <div style={{position: 'absolute', left: 0, top: -(1 - d) * 900}}><Steak x={410} y={960} w={420} rot={-4} /></div>
        {frame > 14 ? new Array(8).fill(0).map((_, i) => { const p = ((frame + i * 5) % 20) / 20; return <div key={i} style={{position: 'absolute', left: 250 + random(`sx${i}`) * 330, top: 900 - p * 240, width: 14, height: 30, borderRadius: 7, background: '#fff', opacity: 0.8 * (1 - p), rotate: `${(random(`sr${i}`) - 0.5) * 50}deg`}} />; }) : null}
        {frame > 14 ? [0, 1].map((i) => <div key={i} style={{position: 'absolute', left: [150, 690][i], top: [760, 720][i] + Math.sin(frame / 2 + i) * 8, fontFamily: DISPLAY, fontSize: 80, color: '#fff', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill', rotate: `${i ? 10 : -12}deg`}}>TSSS</div>) : null}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={250} size={120} color="#fde047" rot={-3} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={tAt + 10} y={440} size={64} color="#fff" rot={2} /> : null}
      </Camera>
    </Shake>
  );
};

export const MEAT1_SCENES: Record<string, React.FC<SceneProps>> = {
  steakPrice: SteakPrice,
  workRest: WorkRest,
  cowMap: CowMap,
  slowPot: SlowPot,
  hotPan: HotPan,
};
