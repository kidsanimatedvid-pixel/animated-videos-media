import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* History scenes, set 2 (cartoon, ancient world): horseTame, teacherScene, marchMap, zeroLosses, citySigns, helmetReveal, horseCity. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* Cartoon horse facing right; (x, y) = point between the hooves on the ground; h = overall height. */
const Horse: React.FC<{x: number; y: number; h: number; rear?: number; gallop?: number}> = ({x, y, h, rear = 0, gallop = 0}) => {
  const sc = h / 300;
  const lg = (a: number) => `rotate(${a})`;
  return (
    <svg width={400 * sc} height={300 * sc} viewBox="0 0 400 300" style={{position: 'absolute', left: x - 200 * sc, top: y - 300 * sc, overflow: 'visible'}}>
      <g transform={`rotate(${-rear} 110 250)`}>
        <path d="M70 130 Q20 150 30 230" fill="none" stroke={OL} strokeWidth={26} strokeLinecap="round" /><path d="M70 130 Q20 150 30 230" fill="none" stroke="#3f3f46" strokeWidth={16} strokeLinecap="round" />
        {[{x: 110, a: gallop * 30 - rear * 0.2}, {x: 140, a: -gallop * 30}].map((l, i) => <g key={i} transform={`translate(${l.x} 180) ${lg(l.a)}`}><rect x={-13} y={0} width={26} height={104} rx={10} fill="#27272a" stroke={OL} strokeWidth={8} /><rect x={-15} y={92} width={30} height={18} rx={6} fill="#a1a1aa" stroke={OL} strokeWidth={6} /></g>)}
        {[{x: 260, a: -gallop * 34 - rear * 1.1}, {x: 290, a: gallop * 34 - rear * 0.7}].map((l, i) => <g key={i} transform={`translate(${l.x} 180) ${lg(l.a)}`}><rect x={-13} y={0} width={26} height={104} rx={10} fill="#27272a" stroke={OL} strokeWidth={8} /><rect x={-15} y={92} width={30} height={18} rx={6} fill="#a1a1aa" stroke={OL} strokeWidth={6} /></g>)}
        <ellipse cx={195} cy={150} rx={125} ry={62} fill="#27272a" stroke={OL} strokeWidth={10} />
        <path d="M270 130 Q300 40 330 30 L372 50 Q340 110 320 170 Z" fill="#27272a" stroke={OL} strokeWidth={10} strokeLinejoin="round" />
        <path d="M322 30 Q350 0 392 30 Q420 60 408 92 Q396 104 380 96 Q352 76 322 70 Z" fill="#27272a" stroke={OL} strokeWidth={10} strokeLinejoin="round" />
        <path d="M330 22 L338 -8 L352 18 Z" fill="#27272a" stroke={OL} strokeWidth={8} strokeLinejoin="round" />
        <circle cx={368} cy={46} r={9} fill="#fff" /><circle cx={370} cy={47} r={5} fill="#111" /><path d="M350 30 l10 -8 l8 10 l-10 6 z" fill="#fff" />
        <path d="M282 110 Q286 60 318 26" fill="none" stroke="#52525b" strokeWidth={18} strokeLinecap="round" />
        <circle cx={402} cy={84} r={4} fill="#111" />
      </g>
    </svg>
  );
};

/* horseTame: { tag, tagOnWord?, tameOnWord, tag2? } — a wild black horse rears and throws grown men back; a boy calms it. */
const HorseTame: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 10), tame = at(captions, scene.tameOnWord, fps, dur * 0.75), boyIn = at(captions, scene.boyOnWord, fps, dur * 0.45);
  const wild = frame < tame;
  const rear = wild ? 22 + Math.sin(frame / 3.2) * 16 : interpolate(frame, [tame, tame + 8], [20, 0], clamp);
  const bx = interpolate(frame, [boyIn, boyIn + 16], [1250, 900], clamp);
  return (
    <Shake at={0} amount={24}>
      <Shake at={tame} amount={14}>
        <Camera dur={dur} from={1.25} to={1.0}>
          <AbsoluteFill style={{background: 'linear-gradient(180deg, #fdba74 0%, #fde68a 55%, #d6b370 56%, #b08d4f 100%)'}} />
          <div style={{position: 'absolute', left: 760, top: 300, width: 200, height: 200, borderRadius: '50%', background: '#fff7c2', boxShadow: '0 0 120px #fff3a0'}} />
          {[0, 1, 2, 3, 4, 5, 6].map((i) => <div key={i} style={{position: 'absolute', left: i * 180 - 40, top: 960, width: 24, height: 200, background: '#78350f', border: `6px solid ${OL}`}} />)}
          <div style={{position: 'absolute', left: -20, top: 1010, width: 1120, height: 26, background: '#92400e', border: `6px solid ${OL}`}} />
          <div style={{position: 'absolute', left: 0, top: 1260, width: 1080, height: 700, background: '#a16207', borderTop: `10px solid ${OL}`}} />
          {wild ? [0, 1, 2, 3, 4].map((i) => { const p = ((frame + i * 5) % 20) / 20; return <div key={i} style={{position: 'absolute', left: 300 + i * 70 - p * 60, top: 1230 - p * 60, width: 50 + p * 70, height: 50 + p * 70, borderRadius: '50%', background: '#fef3c7', opacity: 0.6 * (1 - p)}} />; }) : null}
          <Boy x={150} y={1340} height={560} stage="adult" skin="#groom-a" rim="#fff" glow={0.2} mood={wild ? 'shock' : 'happy'} />
          <Horse x={500} y={1290} h={520} rear={rear} />
          <Boy x={bx} y={1350} height={400} stage="child" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood={wild ? 'determined' : 'happy'} flip />
          {!wild ? [0, 1, 2].map((i) => { const p = ((frame - tame + i * 9) % 28) / 28; return <div key={i} style={{position: 'absolute', left: 640 + i * 50, top: 760 - p * 90, fontSize: 70, opacity: 1 - p}}>✨</div>; }) : null}
          {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={250} size={96} color="#ef4444" fg="#fff" rot={-4} /> : null}
          {scene.tag2 ? <Tag text={scene.tag2 as string} at={tame} y={420} size={100} color="#fde047" rot={3} /> : null}
        </Camera>
      </Shake>
    </Shake>
  );
};

/* teacherScene: { age?, tag, tagOnWord? } — marble columns; a bearded teacher with a scroll, the boy listening. */
const TeacherScene: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.5);
  const TX = 720, TY = 1330, TH = 660, cy = TY - TH * 0.87, R = TH * 0.126;
  return (
    <Camera dur={dur} from={1.0} to={1.1}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #7dd3fc, #e0f2fe 60%)'}} />
      {[90, 990].map((x) => <React.Fragment key={x}><div style={{position: 'absolute', left: x - 70, top: 420, width: 140, height: 860, background: 'repeating-linear-gradient(90deg, #f8fafc 0 22px, #cbd5e1 22px 28px)', border: `9px solid ${OL}`}} /><div style={{position: 'absolute', left: x - 100, top: 380, width: 200, height: 50, background: '#f1f5f9', border: `9px solid ${OL}`, borderRadius: 8}} /></React.Fragment>)}
      <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#e7e5e4', borderTop: `10px solid ${OL}`}} />
      <Boy x={TX} y={TY} height={TH} stage="adult" skin="#wise-teacher" hair="short" rim="#fff" glow={0.2} mood="happy" flip />
      <svg width={R * 2.6} height={R * 2.4} viewBox="0 0 130 120" style={{position: 'absolute', left: TX - R * 1.3, top: cy + R * 0.3}}>
        <path d="M8 4 Q0 70 40 104 Q65 122 90 104 Q130 70 122 4 Q100 34 65 30 Q30 34 8 4 Z" fill="#f1f5f9" stroke={OL} strokeWidth={7} strokeLinejoin="round" />
      </svg>
      <svg width={240} height={200} viewBox="0 0 240 200" style={{position: 'absolute', left: 430, top: 900, rotate: `${Math.sin(frame / 12) * 4}deg`}}>
        <rect x={30} y={30} width={180} height={140} fill="#fef3c7" stroke={OL} strokeWidth={9} /><rect x={10} y={20} width={30} height={160} rx={12} fill="#d97706" stroke={OL} strokeWidth={8} /><rect x={200} y={20} width={30} height={160} rx={12} fill="#d97706" stroke={OL} strokeWidth={8} />
        {[60, 85, 110, 135].map((y) => <path key={y} d={`M60 ${y} H180`} stroke="#92400e" strokeWidth={7} strokeLinecap="round" />)}
      </svg>
      <Boy x={260} y={1350} height={440} stage="teen" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="happy" />
      {scene.age ? <Tag text={scene.age as string} at={0} y={230} size={92} color="#fff" rot={-3} /> : null}
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={400} size={78} color="#fde047" rot={3} /> : null}
    </Camera>
  );
};

/* marchMap: { stops: [{text, onWord, x, y}], startOnWord? } — a red tide spreads east across the map, place names popping as it goes. */
const MarchMap: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const stops = (scene.stops as {text: string; onWord?: string; x: number; y: number}[]) ?? [];
  const ats = stops.map((s, i) => at(captions, s.onWord, fps, 10 + i * 20));
  const go = at(captions, scene.startOnWord, fps, 6);
  const reach = interpolate(frame, [go, ...ats], [160, ...stops.map((s) => s.x + 90)], clamp);
  const land = 'M60 620 Q160 520 300 560 Q420 500 560 560 Q720 500 860 580 Q1010 600 1040 760 Q1060 900 960 980 Q900 1100 760 1040 Q640 1000 560 1060 Q480 1180 360 1160 Q260 1150 250 1030 Q120 1010 80 860 Q30 720 60 620 Z';
  return (
    <Shake at={ats[ats.length - 1] ?? 0} amount={16}>
      <Camera dur={dur} from={1.08} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #0ea5e9, #0c4a6e)'}} />
        <svg width={1080} height={1920} style={{position: 'absolute'}}>
          <defs><clipPath id="mm-reach"><rect x={0} y={0} width={reach} height={1920} /></clipPath></defs>
          <path d={land} fill="#fde68a" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
          <path d={land} fill="#ef4444" clipPath="url(#mm-reach)" />
          <path d={land} fill="none" stroke={OL} strokeWidth={12} strokeLinejoin="round" />
          <path d={`M160 700 ${stops.map((s) => `L${s.x} ${s.y}`).join(' ')}`} fill="none" stroke="#fff" strokeWidth={9} strokeDasharray="4 22" strokeLinecap="round" clipPath="url(#mm-reach)" />
          <circle cx={160} cy={700} r={20} fill="#fff" stroke={OL} strokeWidth={8} />
          <path d={`M${reach - 6} 520 l46 60 l-46 60`} fill="none" stroke="#fff" strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" opacity={frame > go && reach < 1000 ? 0.9 : 0} />
        </svg>
        {stops.map((s, i) => { const sp = spring({frame: frame - ats[i], fps, config: {damping: 9, stiffness: 200}}); return (
          <div key={i} style={{position: 'absolute', left: s.x - 250, width: 500, top: s.y - 40, textAlign: 'center', opacity: frame >= ats[i] ? 1 : 0, scale: String(1.7 - sp * 0.7)}}>
            <span style={{fontFamily: DISPLAY, fontSize: 70, color: '#fff', WebkitTextStroke: `9px ${OL}`, paintOrder: 'stroke fill'}}>{s.text}</span></div>); })}
        <div style={{position: 'absolute', left: 60, width: 220, top: 730, textAlign: 'center', fontFamily: DISPLAY, fontSize: 50, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>{(scene.home as string) ?? 'HOME'}</div>
        {scene.tag ? <Tag text={scene.tag as string} at={go} y={280} size={92} color="#fff" rot={-3} /> : null}
      </Camera>
    </Shake>
  );
};

/* zeroLosses: { wins?, zeroOnWord?, title? } — a scoreboard fills with victory ticks; the loss column stays at a giant zero. */
const ZeroLosses: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const zAt = at(captions, scene.zeroOnWord, fps, dur * 0.5);
  const n = (scene.wins as number) ?? 15;
  const s = spring({frame: frame - zAt, fps, config: {damping: 8, stiffness: 190}});
  return (
    <Shake at={zAt} amount={22}>
      <Camera dur={dur} from={1.06} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #4c1d95, #7c3aed 60%, #4c1d95)'}} />
        <AbsoluteFill style={{background: 'repeating-conic-gradient(from 0deg at 50% 40%, rgba(255,255,255,0.06) 0 8deg, transparent 8deg 16deg)', rotate: `${frame * 0.3}deg`, scale: '2'}} />
        <div style={{position: 'absolute', left: 70, top: 300, width: 940, height: 250, background: '#1e1b4b', border: `10px solid ${OL}`, borderRadius: 24, boxShadow: `0 12px 0 ${OL}`, padding: '10px 26px'}}>
          <div style={{fontFamily: DISPLAY, fontSize: 60, color: '#a5b4fc'}}>{(scene.title as string) ?? 'BATTLES WON'}</div>
          <div style={{display: 'flex', flexWrap: 'wrap', gap: 10}}>{new Array(n).fill(0).map((_, i) => <div key={i} style={{width: 48, height: 66, fontFamily: 'Arial, sans-serif', fontWeight: 900, fontSize: 64, lineHeight: 1, color: '#4ade80', opacity: frame > 4 + i * 2.2 ? 1 : 0.08}}>✓</div>)}</div>
        </div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 590, textAlign: 'center', opacity: frame >= zAt ? 1 : 0, scale: String(2.2 - s * 1.2)}}>
          <span style={{fontFamily: DISPLAY, fontSize: 110, color: '#fff', WebkitTextStroke: `10px ${OL}`, paintOrder: 'stroke fill'}}>LOST: </span>
          <span style={{fontFamily: DISPLAY, fontSize: 260, lineHeight: 1, color: '#fde047', WebkitTextStroke: `14px ${OL}`, paintOrder: 'stroke fill'}}>0</span>
        </div>
        <div style={{position: 'absolute', left: 0, top: 1290, width: 1080, height: 700, background: '#2e1065', borderTop: `10px solid ${OL}`}} />
        <Boy x={540} y={1340} height={440} stage="adult" skin={sb.character.palette.skin} rim="#fde047" glow={0.8} pose="cheer" mood="laugh" phase={frame / 4} />
      </Camera>
    </Shake>
  );
};

/* citySigns: { sign, count?, signOnWord?, tag, tagOnWord? } — signposts with the same (blurred-out) city name pop up; then an hourglass runs out. */
const CitySigns: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sAt = at(captions, scene.signOnWord, fps, 8), tAt = at(captions, scene.tagOnWord, fps, dur * 0.65);
  const sand = interpolate(frame, [0, tAt], [0, 1], clamp);
  const signs = [{x: 190, y: 800}, {x: 560, y: 700}, {x: 250, y: 1060}];
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #fb923c, #fde68a 55%, #eab308 56%, #a16207)'}} />
      <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#854d0e', borderTop: `10px solid ${OL}`}} />
      {signs.map((p, i) => { const sp = spring({frame: frame - sAt - i * 7, fps, config: {damping: 9, stiffness: 190}}); return (
        <div key={i} style={{position: 'absolute', left: p.x - 190, top: p.y, width: 380, opacity: frame >= sAt + i * 7 ? 1 : 0, translate: `0px ${(1 - sp) * 120}px`, rotate: `${[-5, 4, -3][i]}deg`}}>
          <div style={{fontFamily: DISPLAY, fontSize: 58, textAlign: 'center', color: '#111', background: '#fef3c7', border: `8px solid ${OL}`, borderRadius: 12, boxShadow: `0 8px 0 ${OL}`}}>{(scene.sign as string) ?? '???'}</div>
          <div style={{margin: '0 auto', width: 22, height: 1280 - p.y - 80, background: '#78350f', border: `6px solid ${OL}`}} />
        </div>); })}
      <svg width={260} height={420} viewBox="0 0 260 420" style={{position: 'absolute', left: 720, top: 860}}>
        <path d="M40 30 H220 Q220 150 150 210 Q220 270 220 390 H40 Q40 270 110 210 Q40 150 40 30 Z" fill="#e0f2fe" stroke={OL} strokeWidth={11} strokeLinejoin="round" />
        <path d={`M${62 + sand * 50} ${60 + sand * 110} H${198 - sand * 50} Q180 170 130 200 Q80 170 ${62 + sand * 50} ${60 + sand * 110} Z`} fill="#f59e0b" />
        <path d={`M130 380 m-${20 + sand * 62} 0 q${20 + sand * 62} -${20 + sand * 110} ${40 + sand * 124} 0 z`} fill="#f59e0b" />
        {sand < 1 ? <path d="M130 205 V370" stroke="#f59e0b" strokeWidth={7} /> : null}
        <rect x={20} y={10} width={220} height={30} rx={10} fill="#92400e" stroke={OL} strokeWidth={9} /><rect x={20} y={380} width={220} height={30} rx={10} fill="#92400e" stroke={OL} strokeWidth={9} />
      </svg>
      <Boy x={560} y={1340} height={420} stage="adult" skin={sb.character.palette.skin} rim="#fff" glow={0.5} mood={frame >= tAt ? 'sad' : 'happy'} />
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={300} size={110} color="#111" fg="#fff" rot={-3} /> : null}
    </Camera>
  );
};

const Helmet: React.FC<{cx: number; by: number; w: number; rot?: number}> = ({cx, by, w, rot = 0}) => (
  <svg width={w} height={w} viewBox="0 0 200 200" style={{position: 'absolute', left: cx - w / 2, top: by - w, rotate: `${rot}deg`, overflow: 'visible'}}>
    <path d="M60 80 Q40 -10 100 -14 Q170 -10 150 84 Q120 40 100 40 Q80 40 60 80 Z" fill="#ef4444" stroke={OL} strokeWidth={8} strokeLinejoin="round" />
    <path d="M30 200 Q14 80 100 70 Q186 80 170 200 L140 200 Q146 150 100 150 Q54 150 60 200 Z" fill="#fbbf24" stroke={OL} strokeWidth={9} strokeLinejoin="round" />
    <path d="M36 128 H164" stroke="#b45309" strokeWidth={8} />
  </svg>
);

/* helmetReveal: { first, last, onWord, pattern? } — spotlight; a crested helmet drops onto the hero and the name slams in. */
const HelmetReveal: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const rAt = at(captions, scene.onWord, fps, dur * 0.5);
  const s = spring({frame: frame - rAt, fps, config: {damping: 8, stiffness: 150}});
  const bg = interpolate(frame, [rAt - 2, rAt + 10], [0, 1], clamp), flash = interpolate(frame - rAt, [0, 2, 12], [0, 1, 0], clamp);
  const X = 540, Y = 1330, Hh = 580, top = Y - Hh * 0.985, R = Hh * 0.126;
  const words = [(scene.first as string) ?? '', (scene.last as string) ?? ''];
  return (
    <Shake at={rAt} amount={28}>
      <AbsoluteFill style={{background: '#06060a'}} />
      <AbsoluteFill style={{opacity: bg * 0.75, background: (scene.pattern as string) ?? 'repeating-conic-gradient(from 0deg at 50% 56%, #7c2d12 0 11.25deg, #b45309 11.25deg 22.5deg)'}} />
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 56%, rgba(0,0,0,0) 0%, rgba(0,0,0,0.85) 72%)'}} />
      <div style={{position: 'absolute', left: 240, top: 0, width: 600, height: 1400, background: 'linear-gradient(180deg, rgba(254,249,195,0.28), transparent)', clipPath: 'polygon(40% 0, 60% 0, 100% 100%, 0 100%)'}} />
      <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#fde047" glow={0.9} mood={frame >= rAt ? 'happy' : 'neutral'} />
      {frame < rAt ? <div style={{position: 'absolute', left: 0, right: 0, top: 360, textAlign: 'center', fontFamily: DISPLAY, fontSize: 300, color: '#fde047', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill', scale: String(1 + Math.sin(frame / 5) * 0.06)}}>?</div> : null}
      <div style={{opacity: frame >= rAt - 6 ? 1 : 0}}><Helmet cx={X} by={top + R * 1.5 - (1 - s) * 700} w={R * 2.9} rot={(1 - s) * -30} /></div>
      <div style={{position: 'absolute', top: 170, width: '100%', textAlign: 'center'}}>
        {words.map((w, wi) => (
          <div key={wi} style={{display: 'flex', justifyContent: 'center'}}>
            {w.split('').map((ch, ci) => { const ls = spring({frame: frame - rAt - 4 - (wi * 5 + ci * 1.4), fps, config: {damping: 11, stiffness: 220}}); return (
              <span key={ci} style={{fontFamily: DISPLAY, fontSize: wi ? 170 : 180, lineHeight: 1.08, minWidth: ch === ' ' ? 44 : undefined, color: wi ? '#fde047' : '#fff', display: 'inline-block', translate: `0px ${(1 - ls) * 120}px`, opacity: ls, WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill'}}>{ch}</span>); })}
          </div>
        ))}
      </div>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </Shake>
  );
};

/* horseCity: { sign, signOnWord?, cta?, ctaOnWord? } — the helmeted hero rides the black horse past a city gate named after it. */
const HorseCity: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sAt = at(captions, scene.signOnWord, fps, dur * 0.35), cAt = at(captions, scene.ctaOnWord, fps, dur * 0.8);
  const g = Math.sin(frame / 2.4);
  const HX = 420, HY = 1300, bob = Math.abs(g) * 14;
  const RY = HY - 250 - bob, RH = 400, top = RY - RH * 0.985, R = RH * 0.126;
  return (
    <Camera dur={dur} from={1.05} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #38bdf8, #bae6fd 55%, #facc15 56%, #ca8a04)'}} />
      {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: ((i * 460 - frame * 3) % 1500 + 1500) % 1500 - 200, top: 430 + i * 70, width: 240, height: 70, borderRadius: 50, background: '#fff', opacity: 0.85}} />)}
      <div style={{position: 'absolute', left: 700, top: 760, width: 360, height: 520, background: '#fef3c7', border: `10px solid ${OL}`}}>
        <div style={{position: 'absolute', left: 100, bottom: 0, width: 160, height: 280, background: '#451a03', border: `9px solid ${OL}`, borderRadius: '80px 80px 0 0'}} />
        {[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: i * 96 - 10, top: -50, width: 70, height: 50, background: '#fef3c7', border: `10px solid ${OL}`}} />)}
      </div>
      <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#a16207', borderTop: `10px solid ${OL}`}} />
      {[0, 1, 2].map((i) => { const p = ((frame + i * 6) % 18) / 18; return <div key={i} style={{position: 'absolute', left: 200 - p * 140, top: 1240 - p * 50, width: 50 + p * 60, height: 50 + p * 60, borderRadius: '50%', background: '#fef3c7', opacity: 0.6 * (1 - p)}} />; })}
      <Boy x={HX - 20} y={RY} height={RH} stage="adult" skin={sb.character.palette.skin} rim="#fff" glow={0.5} mood="laugh" />
      <Helmet cx={HX - 20} by={top + R * 1.5} w={R * 2.9} />
      <div style={{position: 'absolute', left: 0, top: -bob}}><Horse x={HX} y={HY} h={500} gallop={g} /></div>
      <Tag text={(scene.sign as string) ?? ''} at={sAt} x={760} y={560} size={70} color="#fff" rot={3} />
      {scene.cta ? <Tag text={scene.cta as string} at={cAt} y={280} size={84} color="#ef4444" fg="#fff" rot={-2} /> : null}
    </Camera>
  );
};

export const HISTORY2_SCENES: Record<string, React.FC<SceneProps>> = {
  horseTame: HorseTame,
  teacherScene: TeacherScene,
  marchMap: MarchMap,
  zeroLosses: ZeroLosses,
  citySigns: CitySigns,
  helmetReveal: HelmetReveal,
  horseCity: HorseCity,
};
