import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Story scenes, set 10 (cartoon): emptyCabinet, parkReleased, loanStickers, lostFinals. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* emptyCabinet: { goals, countOnWord?, zeroOnWord, pre? } — a goal counter races past 400 above a glass trophy cabinet that stays empty (cobweb, dust). */
const EmptyCabinet: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.countOnWord, fps, 0), zAt = at(captions, scene.zeroOnWord, fps, dur * 0.55);
  const n = Math.round(interpolate(frame, [0, Math.max(cAt + 14, 20)], [0, (scene.goals as number) ?? 400], {...clamp, easing: (t) => 1 - Math.pow(1 - t, 2)}));
  const zs = spring({frame: frame - zAt, fps, config: {damping: 7, stiffness: 200}});
  return (
    <Shake at={0} amount={22}>
      <Shake at={zAt} amount={22}>
        <Camera dur={dur} from={1.22} to={1.0}>
          <AbsoluteFill style={{background: 'linear-gradient(180deg, #1e293b, #334155)'}} />
          <AbsoluteFill style={{background: 'repeating-linear-gradient(90deg, rgba(255,255,255,0.04) 0 60px, transparent 60px 120px)'}} />
          <div style={{position: 'absolute', top: 170, width: '100%', textAlign: 'center'}}>
            <span style={{fontFamily: DISPLAY, fontSize: 250, lineHeight: 1, color: '#4ade80', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill', fontVariantNumeric: 'tabular-nums'}}>{n}{n >= ((scene.goals as number) ?? 400) ? '+' : ''}</span>
            <div style={{fontFamily: DISPLAY, fontSize: 80, color: '#fff', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill', marginTop: -10}}>GOALS</div>
          </div>
          {/* cabinet */}
          <div style={{position: 'absolute', left: 170, top: 620, width: 740, height: 620, background: 'linear-gradient(135deg, rgba(186,230,253,0.25), rgba(186,230,253,0.08))', border: `14px solid #78350f`, outline: `8px solid ${OL}`, borderRadius: 10}}>
            {[0, 1].map((i) => <div key={i} style={{position: 'absolute', left: 0, right: 0, top: 200 + i * 200, height: 18, background: '#a16207', border: `5px solid ${OL}`}} />)}
            <svg width={200} height={200} viewBox="0 0 200 200" style={{position: 'absolute', right: 0, top: 0}}><path d="M200 0 L0 0 M200 0 L200 200 M200 0 L60 140 M200 0 L120 160 M200 0 L30 70 M80 0 Q140 60 200 120 M140 0 Q170 40 200 60" stroke="#e2e8f0" strokeWidth={3} fill="none" opacity={0.8} /></svg>
            {new Array(12).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: 40 + random(`d${i}`) * 620, top: ((random(`dy${i}`) * 560 + frame * 1.4) % 560), width: 8, height: 8, borderRadius: 4, background: '#cbd5e1', opacity: 0.6}} />)}
            <div style={{position: 'absolute', left: 0, right: 0, top: 230, textAlign: 'center', opacity: frame >= zAt ? 1 : 0, scale: String(2.2 - zs * 1.2), rotate: '-6deg'}}>
              <span style={{fontFamily: DISPLAY, fontSize: 150, color: '#ef4444', border: '12px solid #ef4444', padding: '0 30px', borderRadius: 22, background: '#000000b0'}}>{(scene.stamp as string) ?? '0 TROPHIES'}</span>
            </div>
          </div>
          <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#0f172a', borderTop: `10px solid ${OL}`}} />
          <Boy x={860} y={1340} height={380} stage="adult" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.4} mood={frame >= zAt ? 'sad' : 'neutral'} flip />
          {scene.pre && frame < cAt + 6 ? <Tag text={scene.pre as string} at={0} y={545} size={66} color="#fff" rot={-3} /> : null}
        </Camera>
      </Shake>
    </Shake>
  );
};

/* parkReleased: { age?, tag, tagOnWord?, stamp, stampOnWord? } — a park path; dad puts an arm round his little boy; a "RELEASED" stamp lands. */
const ParkReleased: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.6), sAt = at(captions, scene.stampOnWord, fps, dur * 0.3);
  const ss = spring({frame: frame - sAt, fps, config: {damping: 8, stiffness: 200}});
  return (
    <Shake at={sAt} amount={20}>
      <Camera dur={dur} from={1.0} to={1.1}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #94a3b8 0%, #cbd5e1 55%, #65a30d 56%, #3f6212 100%)'}} />
        {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: ((i * 420 + frame * 0.5) % 1400) - 200, top: 330 + i * 70, width: 260, height: 80, borderRadius: 60, background: '#e2e8f0', opacity: 0.9}} />)}
        {[80, 960].map((x, i) => <svg key={i} width={260} height={480} viewBox="0 0 260 480" style={{position: 'absolute', left: x - 130, top: 660 + i * 30}}><rect x={115} y={260} width={30} height={220} fill="#78350f" stroke={OL} strokeWidth={8} /><circle cx={130} cy={170} r={130} fill="#4d7c0f" stroke={OL} strokeWidth={9} /></svg>)}
        <div style={{position: 'absolute', left: 240, top: 1150, width: 600, height: 900, background: '#d6d3d1', clipPath: 'polygon(40% 0, 60% 0, 100% 100%, 0 100%)'}} />
        <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: '#3f6212', borderTop: `10px solid ${OL}`, opacity: 0.35}} />
        <Boy x={620} y={1360} height={640} stage="adult" skin="#kane-dad" rim="#fff" glow={0.2} mood="sad" flip />
        <Boy x={440} y={1370} height={380} stage="child" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood={frame >= sAt ? 'cry' : 'happy'} />
        {scene.age ? <Tag text={scene.age as string} at={0} x={300} y={220} size={100} color="#fff" rot={-4} /> : null}
        <div style={{position: 'absolute', left: 0, right: 0, top: 560, textAlign: 'center', opacity: frame >= sAt ? 1 : 0, scale: String(2.4 - ss * 1.4), rotate: '-9deg'}}>
          <span style={{fontFamily: DISPLAY, fontSize: 170, color: '#ef4444', border: '14px solid #ef4444', padding: '0 34px', borderRadius: 26, background: '#000000a0'}}>{(scene.stamp as string) ?? 'RELEASED'}</span>
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={380} size={80} color="#fde047" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* loanStickers: { count?, firstOnWord?, tag, tagOnWord? } — a battered suitcase; "LOAN" stickers slap on one after another while the teen drags it. */
const LoanStickers: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const n = (scene.count as number) ?? 4, fAt = at(captions, scene.firstOnWord, fps, 8), tAt = at(captions, scene.tagOnWord, fps, dur * 0.7);
  const gap = Math.max(6, (tAt - fAt) / n);
  const cols = ['#f87171', '#60a5fa', '#facc15', '#a78bfa'];
  const walk = (frame * 3) % 1400;
  return (
    <Camera dur={dur} from={1.0} to={1.06}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #fde68a, #fdba74)'}} />
      {[0, 1, 2, 3, 4].map((i) => <div key={i} style={{position: 'absolute', left: ((i * 300 - walk) % 1500 + 1500) % 1500 - 200, top: 880, width: 30, height: 380, background: '#78716c', border: `6px solid ${OL}`}}><div style={{position: 'absolute', left: -60, top: 0, width: 150, height: 70, background: '#fff', border: `6px solid ${OL}`, borderRadius: 10, fontFamily: DISPLAY, fontSize: 40, textAlign: 'center', lineHeight: '58px', color: '#111'}}>BUS</div></div>)}
      <div style={{position: 'absolute', left: 0, top: 1260, width: 1080, height: 700, background: '#57534e', borderTop: `10px solid ${OL}`}} />
      {[0, 1, 2, 3, 4, 5].map((i) => <div key={i} style={{position: 'absolute', left: ((i * 220 - walk * 1.2) % 1320 + 1320) % 1320 - 120, top: 1440, width: 120, height: 16, background: '#fde047'}} />)}
      <Boy x={300} y={1330} height={520} stage="teen" pose="run" phase={frame / 4} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="determined" />
      <div style={{position: 'absolute', left: 430, top: 770, width: 560, height: 430, background: '#92400e', border: `12px solid ${OL}`, borderRadius: 30, rotate: `${Math.sin(frame / 4) * 2}deg`}}>
        <div style={{position: 'absolute', left: 200, top: -70, width: 140, height: 70, border: `12px solid ${OL}`, borderBottom: 'none', borderRadius: '30px 30px 0 0'}} />
        <div style={{position: 'absolute', left: 0, right: 0, top: 200, height: 14, background: '#78350f'}} />
        {new Array(n).fill(0).map((_, i) => { const a = fAt + i * gap, s = spring({frame: frame - a, fps, config: {damping: 8, stiffness: 220}}); return (
          <div key={i} style={{position: 'absolute', left: 30 + (i % 2) * 260, top: 30 + Math.floor(i / 2) * 200, width: 230, height: 150, background: cols[i % 4], border: `8px solid ${OL}`, borderRadius: 20, opacity: frame >= a ? 1 : 0, scale: String(1.8 - s * 0.8), rotate: `${[-8, 6, 5, -6][i % 4]}deg`, textAlign: 'center'}}>
            <div style={{fontFamily: DISPLAY, fontSize: 50, color: '#111', lineHeight: 1.1, marginTop: 14}}>LOAN</div><div style={{fontFamily: DISPLAY, fontSize: 60, color: '#fff', WebkitTextStroke: `5px ${OL}`, paintOrder: 'stroke fill', lineHeight: 1}}>#{i + 1}</div>
          </div>); })}
      </div>
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={240} size={92} color="#fff" rot={-3} /> : null}
    </Camera>
  );
};

/* lostFinals: { finals: [{text, onWord}], tag?, tagOnWord? } — silver medals drop one by one, each stamped LOST, while the hero hangs his head. */
const LostFinals: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fin = (scene.finals as {text: string; onWord?: string}[]) ?? [];
  const ats = fin.map((f, i) => at(captions, f.onWord, fps, 10 + i * 18));
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.85);
  return (
    <Shake at={ats[ats.length - 1] ?? 0} amount={18}>
      <Camera dur={dur} from={1.04} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #312e81, #1e1b4b)'}} />
        {new Array(40).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`r${i}`) * 1080, top: ((random(`ry${i}`) * 1500 + frame * 30) % 1500), width: 5, height: 48, background: '#93c5fd', opacity: 0.35, rotate: '8deg', borderRadius: 3}} />)}
        {fin.map((f, i) => { const s = spring({frame: frame - ats[i], fps, config: {damping: 9, stiffness: 180}}); return (
          <div key={i} style={{position: 'absolute', left: 90, top: 330 + i * 195, width: 900, height: 170, borderRadius: 28, border: `9px solid ${OL}`, boxShadow: `0 11px 0 ${OL}`, background: '#e2e8f0', opacity: frame >= ats[i] ? 1 : 0, translate: `0px ${(1 - s) * -200}px`, rotate: `${[-2, 2, -1, 1][i % 4]}deg`, display: 'flex', alignItems: 'center', gap: 24, padding: '0 28px'}}>
            <div style={{width: 110, height: 110, borderRadius: '50%', background: 'radial-gradient(circle at 35% 30%, #fff, #94a3b8)', border: `8px solid ${OL}`, fontFamily: DISPLAY, fontSize: 50, textAlign: 'center', lineHeight: '96px', color: '#475569'}}>2ND</div>
            <div style={{fontFamily: DISPLAY, fontSize: 62, color: '#111', flex: 1, lineHeight: 1.05}}>{f.text}</div>
            <div style={{fontFamily: DISPLAY, fontSize: 56, color: '#fff', background: '#ef4444', border: `6px solid ${OL}`, borderRadius: 12, padding: '0 14px', rotate: '-8deg'}}>LOST</div>
          </div>); })}
        <div style={{position: 'absolute', left: 0, top: 1290, width: 1080, height: 700, background: '#0f172a', borderTop: `10px solid ${OL}`}} />
        <Boy x={540} y={1360} height={430} stage="adult" skin={sb.character.palette.skin} rim="#93c5fd" glow={0.4} mood={ats[0] !== undefined && frame >= ats[0] ? 'cry' : 'sad'} />
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={170} size={84} color="#fde047" rot={-3} /> : null}
      </Camera>
    </Shake>
  );
};

export const STORY10_SCENES: Record<string, React.FC<SceneProps>> = {
  emptyCabinet: EmptyCabinet,
  parkReleased: ParkReleased,
  loanStickers: LoanStickers,
  lostFinals: LostFinals,
};
