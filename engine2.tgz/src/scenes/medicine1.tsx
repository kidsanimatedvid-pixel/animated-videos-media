import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Medicine scenes, set 1 (cartoon): drinkCup, stomachMyth, microscope, sickDays, nobelMedal, answerCard. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* Spiral bacterium with little tails, wriggling. */
const Germ: React.FC<{x: number; y: number; s?: number; rot?: number; seed?: number; color?: string}> = ({x, y, s = 1, rot = 0, seed = 0, color = '#4ade80'}) => {
  const frame = useCurrentFrame();
  const w = Math.sin(frame / 3 + seed) * 8;
  return (
    <svg width={220 * s} height={90 * s} viewBox="0 0 220 90" style={{position: 'absolute', left: x - 110 * s, top: y - 45 * s, rotate: `${rot + Math.sin(frame / 9 + seed) * 10}deg`, overflow: 'visible'}}>
      <path d={`M150 45 q20 ${-20 + w} 40 0 q14 ${14 - w} 28 -6 M150 45 q22 ${18 - w} 44 14`} fill="none" stroke={OL} strokeWidth={6} strokeLinecap="round" />
      <path d={`M30 45 q15 ${-34 + w} 30 0 q15 ${34 - w} 30 0 q15 ${-34 + w} 30 0 q15 ${34 - w} 30 0`} fill="none" stroke={OL} strokeWidth={36} strokeLinecap="round" />
      <path d={`M30 45 q15 ${-34 + w} 30 0 q15 ${34 - w} 30 0 q15 ${-34 + w} 30 0 q15 ${34 - w} 30 0`} fill="none" stroke={color} strokeWidth={22} strokeLinecap="round" />
      <circle cx={36} cy={40} r={5} fill="#111" /><circle cx={52} cy={36} r={5} fill="#111" />
    </svg>
  );
};

/* Cartoon stomach with a face. mood: sad | happy | sick */
const Stomach: React.FC<{x: number; y: number; w: number; mood?: string; glow?: number}> = ({x, y, w, mood = 'sad', glow = 0}) => (
  <svg width={w} height={w} viewBox="0 0 300 300" style={{position: 'absolute', left: x - w / 2, top: y - w / 2, overflow: 'visible', filter: glow ? `drop-shadow(0 0 ${glow * 50}px #ef4444)` : undefined}}>
    <path d="M120 10 V70 Q40 90 40 180 Q40 280 150 280 Q230 280 250 220 L290 230 L286 190 Q250 180 240 150 Q230 70 170 66 V10 Z" fill={mood === 'sick' ? '#f87171' : '#fda4af'} stroke={OL} strokeWidth={12} strokeLinejoin="round" />
    <circle cx={110} cy={160} r={12} fill="#111" /><circle cx={180} cy={160} r={12} fill="#111" />
    {mood === 'happy' ? <path d="M110 200 Q145 240 180 200" fill="none" stroke="#111" strokeWidth={10} strokeLinecap="round" /> : <path d="M110 225 Q145 190 180 225" fill="none" stroke="#111" strokeWidth={10} strokeLinecap="round" />}
    {mood !== 'happy' ? <><path d="M92 136 L128 146" stroke="#111" strokeWidth={8} strokeLinecap="round" /><path d="M198 136 L162 146" stroke="#111" strokeWidth={8} strokeLinecap="round" /></> : null}
  </svg>
);

/* drinkCup: { year?, drinkOnWord, tag?, tagOnWord? } — lab; the doctor lifts a beaker of wriggling green broth and drinks it. */
const DrinkCup: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const dAt = at(captions, scene.drinkOnWord, fps, 20), tAt = at(captions, scene.tagOnWord, fps, dur * 0.8);
  const p = interpolate(frame, [dAt, dAt + 10], [0, 1], clamp), lvl = interpolate(frame, [dAt + 8, dAt + 40], [0, 1], clamp);
  const X = 420, Y = 1330, Hh = 640;
  const bx = 690 - p * 120, by = 1000 - p * 130;
  return (
    <Shake at={0} amount={24}>
      <Shake at={tAt} amount={18}>
        <Camera dur={dur} from={1.28} to={1.02}>
          <AbsoluteFill style={{background: 'linear-gradient(180deg, #99f6e4, #5eead4)'}} />
          <div style={{position: 'absolute', left: 640, top: 520, width: 380, height: 26, background: '#0f766e', border: `7px solid ${OL}`}} />
          {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 670 + i * 110, top: 400 + (i % 2) * 30, width: 70, height: 120 - (i % 2) * 30, background: ['#fda4af', '#93c5fd', '#fde047'][i], border: `7px solid ${OL}`, borderRadius: '8px 8px 22px 22px'}} />)}
          <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: '#115e59', borderTop: `10px solid ${OL}`}} />
          <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#fff" glow={0.5} mood={frame >= dAt + 30 ? 'shock' : 'determined'} />
          <svg width={220} height={260} viewBox="0 0 220 260" style={{position: 'absolute', left: bx - 110, top: by - 130, rotate: `${-p * 48}deg`}}>
            <path d="M40 20 H180 L170 230 Q168 246 150 246 H70 Q52 246 50 230 Z" fill="#ecfeff" stroke={OL} strokeWidth={11} strokeLinejoin="round" />
            <path d={`M${46 + lvl * 4} ${70 + lvl * 150} H${174 - lvl * 4} L166 230 Q165 240 150 240 H70 Q55 240 54 230 Z`} fill="#4ade80" />
            {[0, 1, 2].map((i) => <circle key={i} cx={80 + i * 30} cy={210 - ((frame * 2 + i * 30) % 120) * (1 - lvl)} r={8} fill="#bbf7d0" opacity={1 - lvl} />)}
            <rect x={30} y={10} width={160} height={22} rx={10} fill="#ecfeff" stroke={OL} strokeWidth={9} />
          </svg>
          {[0, 1, 2, 3, 4].map((i) => <Germ key={i} x={[820, 930, 760, 900, 180][i] + Math.sin(frame / 14 + i) * 20} y={[760, 900, 1080, 1180, 760][i] + Math.cos(frame / 11 + i) * 20} s={0.8 + (i % 2) * 0.3} rot={i * 50} seed={i} />)}
          {scene.year ? <Tag text={scene.year as string} at={0} x={330} y={240} size={130} color="#fff" rot={-4} /> : null}
          {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={440} size={110} color="#ef4444" fg="#fff" rot={3} /> : null}
        </Camera>
      </Shake>
    </Shake>
  );
};

/* stomachMyth: { title?, tags: [{text,onWord}] } — an unhappy cartoon stomach under lightning; the old textbook culprits pop up. */
const StomachMyth: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tags = (scene.tags as {text: string; onWord?: string}[]) ?? [];
  const tA = at(captions, scene.titleOnWord, fps, 10);
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #fb923c, #fdba74)'}} />
      <AbsoluteFill style={{background: 'repeating-linear-gradient(135deg, rgba(255,255,255,0.08) 0 40px, transparent 40px 80px)'}} />
      <div style={{position: 'absolute', left: 0, top: 1290, width: 1080, height: 700, background: '#9a3412', borderTop: `10px solid ${OL}`}} />
      <div style={{position: 'absolute', left: 0, top: Math.sin(frame / 2) * 5}}><Stomach x={540} y={990} w={520} mood="sad" /></div>
      {[0, 1].map((i) => <svg key={i} width={120} height={200} viewBox="0 0 120 200" style={{position: 'absolute', left: [210, 760][i], top: 640, opacity: Math.floor(frame / 5 + i) % 3 ? 1 : 0.2}}><path d="M70 0 L20 110 H60 L40 200 L110 80 H66 Z" fill="#fde047" stroke={OL} strokeWidth={9} strokeLinejoin="round" /></svg>)}
      <Tag text={(scene.title as string) ?? ''} at={tA} y={240} size={80} color="#fff" rot={-3} />
      {tags.map((t, i) => <Tag key={i} text={t.text} at={at(captions, t.onWord, fps, 20 + i * 14)} x={i ? 790 : 290} y={430 + i * 60} size={104} color={i ? '#a3e635' : '#ef4444'} fg={i ? '#111' : '#fff'} rot={i ? 5 : -6} />)}
    </Camera>
  );
};

/* microscope: { tag, tagOnWord?, stamp, stampOnWord? } — a round lens view full of spiral bacteria; skeptics slam a red stamp on it. */
const Microscope: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 14), sAt = at(captions, scene.stampOnWord, fps, dur * 0.65);
  const ss = spring({frame: frame - sAt, fps, config: {damping: 8, stiffness: 200}});
  return (
    <Shake at={sAt} amount={22}>
      <Camera dur={dur} from={1.1} to={1.0}>
        <AbsoluteFill style={{background: '#0f172a'}} />
        <div style={{position: 'absolute', left: 540 - 400, top: 760 - 400, width: 800, height: 800, borderRadius: '50%', background: 'radial-gradient(circle at 40% 35%, #fecdd3, #fda4af 70%, #fb7185)', border: `18px solid ${OL}`, outline: '14px solid #64748b', overflow: 'hidden'}}>
          {new Array(9).fill(0).map((_, i) => <Germ key={i} x={120 + random(`gx${i}`) * 560 + Math.sin(frame / 16 + i) * 30} y={130 + random(`gy${i}`) * 540 + Math.cos(frame / 13 + i * 2) * 30} s={0.9 + random(`gs${i}`) * 0.5} rot={random(`gr${i}`) * 360 + frame * (i % 2 ? 0.6 : -0.6)} seed={i} />)}
        </div>
        <Boy x={170} y={1340} height={400} stage="adult" skin={sb.character.palette.skin} rim="#fff" glow={0.5} mood={frame >= sAt ? 'sad' : 'happy'} />
        <Boy x={830} y={1340} height={400} stage="adult" skin="#skeptic-1" rim="#fff" glow={0.2} mood={frame >= sAt ? 'laugh' : 'neutral'} flip />
        <Boy x={980} y={1350} height={400} stage="adult" skin="#skeptic-2" rim="#fff" glow={0.2} mood={frame >= sAt ? 'laugh' : 'neutral'} flip />
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={220} size={88} color="#4ade80" rot={-3} /> : null}
        <div style={{position: 'absolute', left: 0, right: 0, top: 640, textAlign: 'center', opacity: frame >= sAt ? 1 : 0, scale: String(2.6 - ss * 1.6), rotate: '-12deg'}}>
          <span style={{fontFamily: DISPLAY, fontSize: 170, color: '#ef4444', border: '14px solid #ef4444', padding: '0 34px', borderRadius: 26, background: '#000000b0'}}>{(scene.stamp as string) ?? 'IMPOSSIBLE'}</span>
        </div>
      </Camera>
    </Shake>
  );
};

/* sickDays: { days?, countOnWord?, tag, tagOnWord? } — a day counter flips while the doctor turns green and his stomach flares red. */
const SickDays: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.countOnWord, fps, 20), tAt = at(captions, scene.tagOnWord, fps, dur * 0.8);
  const max = (scene.days as number) ?? 8;
  const day = Math.max(1, Math.round(interpolate(frame, [cAt, cAt + 40], [1, max], clamp)));
  const sick = interpolate(frame, [cAt, cAt + 40], [0, 1], clamp);
  const X = 400, Y = 1330, Hh = 600, hc = Y - Hh * 0.87, R = Hh * 0.126;
  return (
    <Shake at={tAt} amount={18}>
      <Camera dur={dur} from={1.0} to={1.1}>
        <AbsoluteFill style={{background: `linear-gradient(180deg, #bae6fd, #e0f2fe)`}} />
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #a3e635, #d9f99d)', opacity: sick * 0.85}} />
        <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: '#3f6212', borderTop: `10px solid ${OL}`}} />
        <div style={{position: 'absolute', left: X + Math.sin(frame / 1.5) * sick * 6 - X, top: 0}}>
          <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim="#fff" glow={0.4} mood={sick > 0.5 ? 'cry' : 'neutral'} />
          <div style={{position: 'absolute', left: X - R * 1.2, top: hc - R * 1.1, width: R * 2.4, height: R * 2.3, borderRadius: '50%', background: '#65a30d', opacity: sick * 0.45, mixBlendMode: 'multiply'}} />
        </div>
        <div style={{position: 'absolute', left: 0, top: Math.sin(frame / 2) * 6 * sick}}><Stomach x={800} y={1010} w={330} mood={sick > 0.5 ? 'sick' : 'sad'} glow={sick * (0.6 + Math.sin(frame / 3) * 0.4)} /></div>
        <div style={{position: 'absolute', left: 600, top: 450, width: 400, height: 360, background: '#fff', border: `10px solid ${OL}`, borderRadius: 26, boxShadow: `0 12px 0 ${OL}`, overflow: 'hidden', rotate: '4deg', textAlign: 'center'}}>
          <div style={{height: 100, background: '#ef4444', borderBottom: `8px solid ${OL}`, fontFamily: DISPLAY, fontSize: 70, color: '#fff', lineHeight: '100px'}}>DAY</div>
          <div style={{fontFamily: DISPLAY, fontSize: 230, lineHeight: 1.08, color: '#111'}}>{day}</div>
        </div>
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} x={540} y={220} size={84} color="#ef4444" fg="#fff" rot={-3} /> : null}
      </Camera>
    </Shake>
  );
};

/* nobelMedal: { pill, pillOnWord?, medalOnWord?, names?, label? } — capsules pop in, then a gold medal swings down on its ribbon. */
const NobelMedal: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pAt = at(captions, scene.pillOnWord, fps, 4), mAt = at(captions, scene.medalOnWord, fps, dur * 0.6), nAt = at(captions, scene.namesOnWord, fps, dur * 0.4);
  const ms = spring({frame: frame - mAt, fps, config: {damping: 9, stiffness: 110}});
  return (
    <Shake at={mAt + 6} amount={18}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: '#1e3a8a'}} />
        <AbsoluteFill style={{background: 'repeating-conic-gradient(from 0deg at 50% 45%, #1d4ed8 0 9deg, #1e40af 9deg 18deg)', rotate: `${frame * 0.25}deg`, scale: '2.2'}} />
        <div style={{position: 'absolute', left: 0, top: 1290, width: 1080, height: 700, background: '#172554', borderTop: `10px solid ${OL}`}} />
        <Boy x={300} y={1340} height={560} stage="adult" skin={sb.character.palette.skin} rim="#fde047" glow={0.8} mood={frame >= mAt ? 'laugh' : 'happy'} pose={frame >= mAt ? 'cheer' : 'stand'} phase={frame / 4} />
        {[0, 1, 2].map((i) => { const s = spring({frame: frame - pAt - i * 4, fps, config: {damping: 9}}); return (
          <div key={i} style={{position: 'absolute', left: 560 + i * 140, top: 1120 + (i % 2) * 40, width: 150, height: 64, borderRadius: 32, border: `8px solid ${OL}`, background: 'linear-gradient(90deg, #ef4444 50%, #fff 50%)', rotate: `${[-20, 15, -8][i]}deg`, scale: String(s), opacity: frame >= pAt + i * 4 ? 1 : 0}} />); })}
        <div style={{position: 'absolute', left: 700, top: -40 - (1 - ms) * 900, rotate: `${Math.sin((frame - mAt) / 7) * 6 * Math.max(0, 1 - (frame - mAt) / 70)}deg`, transformOrigin: '80px 0'}}>
          <div style={{margin: '0 auto', width: 70, height: 560, background: 'repeating-linear-gradient(90deg, #2563eb 0 23px, #fde047 23px 46px, #2563eb 46px 70px)', border: `8px solid ${OL}`}} />
          <div style={{marginLeft: -85, marginTop: -10, width: 330, height: 330, borderRadius: '50%', background: 'radial-gradient(circle at 35% 30%, #fef08a, #f59e0b)', border: `12px solid ${OL}`, boxShadow: '0 0 80px #fde047', textAlign: 'center'}}>
            <div style={{fontFamily: DISPLAY, fontSize: 64, lineHeight: 1.05, color: '#78350f', paddingTop: 72}}>{((scene.label as string) ?? 'NOBEL|PRIZE|2005').split('|').map((l, i) => <div key={i}>{l}</div>)}</div>
          </div>
        </div>
        {scene.pill ? <Tag text={scene.pill as string} at={pAt} x={480} y={230} size={76} color="#fff" rot={-3} /> : null}
        {scene.names ? <Tag text={scene.names as string} at={nAt} x={300} y={520} size={60} color="#fde047" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* answerCard: { title?, options: ['..'], correct: index, revealOnWord?, note?, cta?, ctaOnWord? } — the earlier choices return with the right one lit. */
const AnswerCard: React.FC<SceneProps> = ({scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const rAt = at(captions, scene.revealOnWord, fps, 10), cAt = at(captions, scene.ctaOnWord, fps, dur * 0.8), nAt = at(captions, scene.noteOnWord, fps, dur * 0.4);
  const opts = (scene.options as string[]) ?? [], ok = (scene.correct as number) ?? 0;
  const s = spring({frame: frame - rAt, fps, config: {damping: 8, stiffness: 190}});
  return (
    <Shake at={rAt} amount={18}>
      <Camera dur={dur} from={1.05} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #065f46, #10b981 60%, #065f46)'}} />
        {new Array(24).fill(0).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`a${i}`) * 1080, top: ((random(`ay${i}`) * 1500 + (frame - rAt) * 10) % 1500), width: 18, height: 18, rotate: `${frame * 6 + i * 30}deg`, background: ['#fde047', '#fff', '#f472b6'][i % 3], opacity: frame >= rAt ? 0.9 : 0}} />)}
        <Tag text={(scene.title as string) ?? 'THE ANSWER'} at={0} y={230} size={96} color="#fff" rot={-3} />
        {opts.map((o, i) => { const hit = i === ok, on = frame >= rAt; return (
          <div key={i} style={{position: 'absolute', left: 110, top: 440 + i * 190, width: 860, height: 150, borderRadius: 30, border: `10px solid ${OL}`, boxShadow: `0 12px 0 ${OL}`, background: on ? (hit ? '#fde047' : '#94a3b8') : '#fff', opacity: on && !hit ? 0.55 : 1, scale: String(on && hit ? 1 + s * 0.08 : 1), display: 'flex', alignItems: 'center', padding: '0 34px', gap: 26}}>
            <div style={{width: 96, height: 96, borderRadius: '50%', background: OL, color: '#fff', fontFamily: DISPLAY, fontSize: 64, textAlign: 'center', lineHeight: '96px'}}>{'ABC'[i]}</div>
            <div style={{fontFamily: DISPLAY, fontSize: 84, color: '#111', flex: 1, textDecoration: on && !hit ? 'line-through' : 'none'}}>{o}</div>
            <div style={{fontFamily: 'Arial, sans-serif', fontWeight: 900, fontSize: 90, color: hit ? '#16a34a' : '#dc2626', opacity: on ? 1 : 0}}>{hit ? '✓' : '✗'}</div>
          </div>); })}
        {scene.noIcon ? null : <div style={{position: 'absolute', left: 0, top: 0}}><Stomach x={540} y={1175} w={170} mood={frame >= rAt ? 'happy' : 'sad'} /></div>}
        {scene.note ? <Tag text={scene.note as string} at={nAt} y={1010} x={540} size={38} color="#fff" rot={0} /> : null}
        {scene.cta ? <Tag text={scene.cta as string} at={cAt} y={1300} size={80} color="#ef4444" fg="#fff" rot={-2} /> : null}
      </Camera>
    </Shake>
  );
};

export const MEDICINE1_SCENES: Record<string, React.FC<SceneProps>> = {
  drinkCup: DrinkCup,
  stomachMyth: StomachMyth,
  microscope: Microscope,
  sickDays: SickDays,
  nobelMedal: NobelMedal,
  answerCard: AnswerCard,
};
