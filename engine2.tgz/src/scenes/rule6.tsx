import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Owl, Raccoon, Study, Counter, Board, W} from '../components/Duo';
import {CameraRig, EASE, impulse, impulses, kf, Layer, Particles} from '../components/Motion';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* THE HIDDEN RULE #6 — Sunk cost (Arkes & Blumer 1985 ski-trip study). Duo look (Professor owl + Kit raccoon) built with animation kit v2:
   CameraRig + parallax layers (wall → board → characters → counter), eased keyframes, impact kicks.
   Scenes: skiHook, onlyOne, kitPicks, sunkReveal, studyDots, sunkTurn. */
const OL = '#1b120b';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);
const talkOf = (mouth: number[] | undefined, f: number) => (mouth ? mouth[Math.min(mouth.length - 1, Math.max(0, f))] ?? 0 : 0);

const Badge: React.FC<{text: string}> = ({text}) => (
  <div style={{position: 'absolute', left: 40, top: 190, fontFamily: BODY, fontWeight: 800, fontSize: 30, letterSpacing: 4, color: W.cream, border: `3px solid ${W.cream}`, borderRadius: 10, padding: '4px 14px', opacity: 0.85}}>{text}</div>
);

/* Scene shell: layered study set under a virtual camera. */
const Set: React.FC<{cam: {x: number; y: number; zoom: number; roll?: number}; board?: React.ReactNode; actors?: React.ReactNode; counterTop?: number}> = ({cam, board, actors, counterTop = 1260}) => (
  <CameraRig cam={cam}>
    <Layer depth={0.55} blur={1}><Study /></Layer>
    <Layer depth={0.8}>{board}</Layer>
    <Layer depth={1}>{actors}</Layer>
    <Layer depth={1.2}><Counter top={counterTop} /></Layer>
  </CameraRig>
);

/* ski ticket */
const Ticket: React.FC<{x: number; y: number; place: string; price: string; color: string; rot?: number; s?: number; a?: number}> = ({x, y, place, price, color, rot = 0, s = 1, a = 0}) => {
  const frame = useCurrentFrame();
  if (frame < a) return null;
  const t = frame - a;
  const pop = kf(t, [[0, 0.2], [9, 1, EASE.overshoot]]);
  return (
    <div style={{position: 'absolute', left: x, top: y, width: 300 * s, height: 160 * s, rotate: `${rot}deg`, scale: String(pop), background: color, border: `5px solid ${OL}`, borderRadius: 16 * s, boxShadow: '0 8px 0 rgba(0,0,0,0.35)'}}>
      <div style={{position: 'absolute', left: 0, right: 0, top: 14 * s, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 30 * s, color: OL, letterSpacing: 2}}>⛷️ {place}</div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 54 * s, textAlign: 'center', fontFamily: DISPLAY, fontSize: 78 * s, color: OL}}>{price}</div>
      <div style={{position: 'absolute', left: 16 * s, right: 16 * s, top: 136 * s, borderTop: `4px dashed ${OL}`}} />
    </div>
  );
};

/* skiHook: { sameOnWord } — Arm B current opening: frame 0 = the study, Kit proudly holding two ski tickets, Professor watching; camera eases in.
   On "same" the board calendar slams both tickets onto ONE weekend (camera kick). */
const SkiHook: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sAt = at(captions, scene.sameOnWord, fps, dur * 0.4);
  const kick = impulse(frame, sAt, 0.05, 14, 1.3);
  const cam = {x: kf(frame, [[0, 560], [dur, 600, EASE.smooth]]), y: kf(frame, [[0, 900], [dur, 860, EASE.smooth]]), zoom: kf(frame, [[0, 1.0], [dur, 1.1, EASE.smooth]]) + kick, roll: impulse(frame, sAt, 1.5, 14, 1.1)};
  const cal = kf(frame, [[sAt, 0], [sAt + 9, 1, EASE.overshoot]]);
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 0, right: 0, top: 24, textAlign: 'center', fontFamily: DISPLAY, fontSize: 56, color: W.chalk, letterSpacing: 4}}>WEEKEND PLANS</div>
          <Ticket x={70} y={120} place="TRIP A" price="$100" color={W.gold} rot={-6} />
          <Ticket x={500} y={120} place="TRIP B" price="$50" color={W.mint} rot={5} a={10} />
          {frame >= sAt ? <div style={{position: 'absolute', left: 180, top: 330, width: 520, height: 170, scale: String(cal), background: W.cream, border: `5px solid ${OL}`, borderRadius: 16, textAlign: 'center'}}>
            <div style={{background: W.coral, borderBottom: `5px solid ${OL}`, fontFamily: BODY, fontWeight: 900, fontSize: 34, color: OL, padding: 6}}>SATURDAY</div>
            <div style={{fontFamily: DISPLAY, fontSize: 62, color: OL, marginTop: 14}}>BOTH TRIPS 😬</div>
          </div> : null}
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={talkOf(mouth, frame)} look={0.5} point={kf(frame, [[sAt - 8, 0], [sAt + 4, 1, EASE.out]])} />
          <Raccoon x={660} y={840} s={1.15} look={frame >= sAt ? -0.5 : -0.1} joy={frame < sAt ? 0.8 : 0.1} arm={frame < sAt ? 0.6 : 0.2} />
        </>} />
      <Badge text={(scene.badge as string) ?? 'THE HIDDEN RULE #6'} />
    </AbsoluteFill>
  );
};

/* onlyOne: { funOnWord, oneOnWord } — fun meters fill (B much higher); "ONLY ONE" stamp slams on "one". */
const OnlyOne: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fAt = at(captions, scene.funOnWord, fps, 10);
  const oAt = at(captions, scene.oneOnWord, fps, dur * 0.7);
  const fillA = kf(frame, [[fAt, 0], [fAt + 18, 0.4, EASE.out]]);
  const fillB = kf(frame, [[fAt + 4, 0], [fAt + 26, 0.95, EASE.overshoot]]);
  const st = kf(frame, [[oAt, 2.2], [oAt + 7, 1, EASE.in], [oAt + 12, 1.06, EASE.out], [oAt + 16, 1]]);
  const cam = {x: kf(frame, [[0, 520], [dur, 540, EASE.smooth]]), y: kf(frame, [[0, 760], [dur, 720, EASE.smooth]]), zoom: kf(frame, [[0, 1.12], [dur, 1.2, EASE.smooth]]) + impulse(frame, oAt + 6, 0.05, 12, 1.4)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 0, right: 0, top: 24, textAlign: 'center', fontFamily: DISPLAY, fontSize: 54, color: W.chalk, letterSpacing: 4}}>FUN METER</div>
          {[{lab: 'TRIP A · $100', v: fillA, c: W.gold}, {lab: 'TRIP B · $50', v: fillB, c: W.mint}].map((b, i) => (
            <div key={i} style={{position: 'absolute', left: 60, top: 130 + i * 170}}>
              <div style={{fontFamily: BODY, fontWeight: 900, fontSize: 32, color: W.chalk, letterSpacing: 2}}>{b.lab}</div>
              <div style={{marginTop: 10, width: 700, height: 70, borderRadius: 12, border: `4px solid ${W.chalk}`, overflow: 'hidden'}}>
                <div style={{width: `${b.v * 100}%`, height: '100%', background: b.c}} />
              </div>
              <div style={{position: 'absolute', left: 720, top: 46, fontSize: 64}}>{i === 1 && frame > fAt + 20 ? '🤩' : i === 0 && frame > fAt + 14 ? '😐' : ''}</div>
            </div>
          ))}
          {frame >= oAt ? <div style={{position: 'absolute', left: 230, top: 210, rotate: '-12deg', scale: String(st), fontFamily: DISPLAY, fontSize: 96, color: W.coral, border: `8px solid ${W.coral}`, borderRadius: 18, padding: '0 30px', background: 'rgba(34,48,42,0.85)'}}>ONLY ONE!</div> : null}
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={talkOf(mouth, frame)} point={1} look={0.5} />
          <Raccoon x={660} y={840} s={1.15} look={-0.6} joy={frame >= oAt ? 0 : 0.3} />
        </>} />
    </AbsoluteFill>
  );
};

/* kitPicks: { pickOnWord } — Kit's line (lip-synced): he snatches the $100 ticket with an anticipation wind-up; the $50 ticket flutters away. */
const KitPicks: React.FC<SceneProps> = ({captions, mouth, durationInFrames: dur, scene}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pAt = at(captions, scene.pickOnWord, fps, 6);
  const grab = kf(frame, [[pAt - 6, 0], [pAt, -0.15, EASE.anticip], [pAt + 8, 1, EASE.overshoot]]);
  const flyT = Math.max(0, frame - pAt - 4);
  const cam = {x: kf(frame, [[0, 760], [dur, 740, EASE.smooth]]), y: kf(frame, [[0, 1000], [dur, 980, EASE.smooth]]), zoom: kf(frame, [[0, 1.35], [dur, 1.45, EASE.smooth]]) + impulse(frame, pAt + 6, 0.06, 14, 1.3), roll: -1};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        actors={<>
          <Raccoon x={640} y={840} s={1.2} talk={talkOf(mouth, frame)} look={-0.2} joy={0.9} arm={Math.max(0, grab)} />
          <div style={{position: 'absolute', left: 560 + grab * 60, top: 820 - grab * 120, rotate: `${-10 + grab * 18}deg`}}><Ticket x={0} y={0} place="TRIP A" price="$100" color={W.gold} s={0.8} /></div>
          {frame < pAt + 50 ? <div style={{position: 'absolute', left: 900 + flyT * 7, top: 900 - flyT * 9 + Math.sin(flyT / 3) * 20, rotate: `${flyT * 9}deg`, opacity: 1 - flyT / 50}}><Ticket x={0} y={0} place="TRIP B" price="$50" color={W.mint} s={0.6} /></div> : null}
          <Particles count={12} color={W.gold} size={10} speedY={-0.8} speedX={0.2} seed={4} opacity={frame > pAt ? 0.6 : 0} />
        </>} />
    </AbsoluteFill>
  );
};

/* sunkReveal: { goneOnWord, titleOnWord } — both tickets drop into a hole labelled ALREADY SPENT ($150 either way); title SUNK COST TRAP slams. */
const SunkReveal: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const gAt = at(captions, scene.goneOnWord, fps, dur * 0.35);
  const tAt = at(captions, scene.titleOnWord, fps, dur * 0.7);
  const drop = (d: number) => kf(frame, [[gAt + d, 0], [gAt + d + 14, 1, EASE.in]]);
  const title = kf(frame, [[tAt, 0], [tAt + 9, 1, EASE.overshoot]]);
  const cam = {x: 540, y: kf(frame, [[0, 760], [dur, 800, EASE.smooth]]), zoom: kf(frame, [[0, 1.15], [dur, 1.05, EASE.smooth]]) + impulses(frame, [gAt + 14, tAt + 6], 0.04, 12, 1.4)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 250, top: 330, width: 400, height: 120, borderRadius: '50%', background: '#0b0f0d', border: `6px solid ${W.chalk}`}} />
          <div style={{position: 'absolute', left: 0, right: 0, top: 470, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 34, color: W.chalk, letterSpacing: 3}}>ALREADY SPENT: $150 EITHER WAY</div>
          {[0, 1].map((i) => {
            const d = drop(i * 6);
            return <div key={i} style={{position: 'absolute', left: (i ? 470 : 230) + (i ? -60 : 60) * d, top: 80 + 260 * d, scale: String(1 - d * 0.75), opacity: 1 - Math.max(0, d - 0.85) * 6}}>
              <Ticket x={0} y={0} place={i ? 'TRIP B' : 'TRIP A'} price={i ? '$50' : '$100'} color={i ? W.mint : W.gold} s={0.7} rot={(i ? 8 : -8) + d * 40} />
            </div>;
          })}
          {frame >= tAt ? <div style={{position: 'absolute', left: 0, right: 0, top: 30, textAlign: 'center', scale: String(title), fontFamily: DISPLAY, fontSize: 92, color: W.coral}}>THE SUNK COST TRAP</div> : null}
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={talkOf(mouth, frame)} point={frame > gAt ? 1 : 0} look={0.5} />
          <Raccoon x={660} y={840} s={1.15} look={-0.5} joy={0} />
        </>} />
    </AbsoluteFill>
  );
};

/* studyDots: { askOnWord, moreOnWord } — 61 dots (one per student); quick question "how many picked the pricey trip?"; on "More" 33 dots flip coral. */
const StudyDots: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mAt = at(captions, scene.moreOnWord, fps, dur * 0.65);
  const cam = {x: kf(frame, [[0, 520], [dur, 540, EASE.smooth]]), y: 720, zoom: kf(frame, [[0, 1.08], [dur, 1.2, EASE.smooth]]) + impulse(frame, mAt + 4, 0.04, 12, 1.4)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 0, right: 0, top: 20, textAlign: 'center', fontFamily: BODY, fontWeight: 900, fontSize: 32, color: W.grey, letterSpacing: 3}}>ARKES & BLUMER · 1985 · 61 STUDENTS</div>
          {new Array(61).fill(0).map((_, i) => {
            const on = frame >= mAt + i * 0.6 && i < 33;
            const appear = kf(frame, [[i * 0.8, 0], [i * 0.8 + 6, 1, EASE.out]]);
            return <div key={i} style={{position: 'absolute', left: 70 + (i % 11) * 70, top: 90 + Math.floor(i / 11) * 62, width: 44, height: 44, borderRadius: 22, scale: String(appear * (on ? 1.15 : 1)), background: on ? W.coral : W.chalk, border: `3px solid ${OL}`}} />;
          })}
          {frame >= mAt + 22 ? <div style={{position: 'absolute', left: 0, right: 0, top: 470, textAlign: 'center', fontFamily: DISPLAY, fontSize: 52, color: W.coral, scale: String(kf(frame, [[mAt + 22, 0.4], [mAt + 30, 1, EASE.overshoot]]))}}>33 OF 61 PICKED THE PRICEY, LESS FUN TRIP</div> : null}
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={talkOf(mouth, frame)} point={1} look={0.5} />
          <Raccoon x={660} y={840} s={1.15} look={-0.6} joy={frame >= mAt ? 0.6 : 0} />
        </>} />
    </AbsoluteFill>
  );
};

/* sunkTurn: { questionOnWord } — "You think I'm talking about ski trips": everyday traps (bad film, paid game, gym), then the question card; silent send line + pill; loops into the hook. */
const SunkTurn: React.FC<SceneProps> = ({scene, captions, mouth, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const qAt = at(captions, scene.questionOnWord, fps, dur * 0.55);
  const icons = [['🍿', 'THE BAD FILM'], ['🎮', 'THE PAID GAME'], ['🏋️', 'THE GYM YOU HATE']];
  const cam = {x: kf(frame, [[0, 540], [dur, 560, EASE.smooth]]), y: kf(frame, [[0, 760], [dur, 800, EASE.smooth]]), zoom: kf(frame, [[0, 1.04], [qAt, 1.12, EASE.smooth], [dur, 1.16, EASE.smooth]]) + impulse(frame, qAt + 4, 0.04, 12, 1.4)};
  return (
    <AbsoluteFill>
      <Set cam={cam}
        board={<Board>
          <div style={{position: 'absolute', left: 20, right: 20, top: 24, textAlign: 'center', fontFamily: DISPLAY, fontSize: 52, color: W.chalk}}>YOU THINK I'M TALKING ABOUT SKI TRIPS.</div>
          {icons.map(([ic, lab], i) => {
            const s = kf(frame, [[14 + i * 10, 0], [24 + i * 10, 1, EASE.overshoot]]);
            return <div key={i} style={{position: 'absolute', left: 60 + i * 270, top: 130, width: 240, textAlign: 'center', scale: String(s), opacity: frame >= qAt ? 0.35 : 1}}>
              <div style={{fontSize: 110}}>{ic}</div>
              <div style={{fontFamily: BODY, fontWeight: 900, fontSize: 26, color: W.chalk, letterSpacing: 1}}>{lab}</div>
            </div>;
          })}
          {frame >= qAt ? <div style={{position: 'absolute', left: 60, right: 60, top: 290, scale: String(kf(frame, [[qAt, 0.3], [qAt + 9, 1, EASE.overshoot]])), background: W.cream, border: `5px solid ${OL}`, borderRadius: 18, padding: '14px 20px', textAlign: 'center', fontFamily: DISPLAY, fontSize: 46, color: OL, lineHeight: 1.1}}>"IF I STARTED TODAY, WOULD I STILL CHOOSE THIS?"</div> : null}
          <div style={{position: 'absolute', left: 30, right: 30, top: 430, textAlign: 'center', opacity: kf(frame, [[qAt + 10, 0], [qAt + 20, 1, EASE.out]])}}><span style={{fontFamily: BODY, fontWeight: 900, fontSize: 30, color: '#111', background: '#86efac', padding: '6px 16px', borderRadius: 12, border: `4px solid ${OL}`}}>📤 Send this to the friend who never walks out</span></div>
        </Board>}
        actors={<>
          <Owl x={10} y={800} s={1.2} talk={talkOf(mouth, frame)} look={0.3} point={frame >= qAt ? 1 : 0} />
          <Raccoon x={660} y={840} s={1.15} look={-0.6} />
        </>} />
    </AbsoluteFill>
  );
};

export const RULE6_SCENES: Record<string, React.FC<SceneProps>> = {skiHook: SkiHook, onlyOne: OnlyOne, kitPicks: KitPicks, sunkReveal: SunkReveal, studyDots: StudyDots, sunkTurn: SunkTurn};
void interpolate;
