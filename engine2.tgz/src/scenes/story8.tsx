import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Story scenes, set 8 (cartoon): ballFee, hyperKid, coalYard, finalsGoals. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Ball: React.FC<{x: number; y: number; r: number; rot?: number}> = ({x, y, r, rot = 0}) => (
  <svg width={r * 2} height={r * 2} viewBox="0 0 100 100" style={{position: 'absolute', left: x - r, top: y - r, rotate: `${rot}deg`}}>
    <circle cx={50} cy={50} r={44} fill="#fff" stroke={OL} strokeWidth={8} />
    <path d="M50 30 L68 44 L61 66 H39 L32 44 Z" fill={OL} /><path d="M50 30 V8 M68 44 L90 38 M61 66 L74 86 M39 66 L26 86 M32 44 L10 38" stroke={OL} strokeWidth={6} />
  </svg>
);

/* ballFee: { total, countOnWord?, tag?, tagOnWord?, tag2?, tag2OnWord? } — footballs rain into a heap beside the little kid while a counter climbs. */
const BallFee: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const total = (scene.total as number) ?? 35;
  const cAt = at(captions, scene.countOnWord, fps, 20), tAt = at(captions, scene.tagOnWord, fps, 6), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.75);
  const n = Math.round(total * interpolate(frame, [4, cAt + 12], [0, 1], clamp));
  return (
    <Shake at={0} amount={24}>
      <Shake at={cAt + 12} amount={18}>
        <Camera dur={dur} from={1.25} to={1.0}>
          <AbsoluteFill style={{background: 'linear-gradient(180deg, #7dd3fc 0%, #bae6fd 56%, #4ade80 57%, #15803d 100%)'}} />
          <div style={{position: 'absolute', left: 0, top: 1290, width: 1080, height: 700, background: 'linear-gradient(180deg, #16a34a, #14532d)', borderTop: '10px solid #fff'}} />
          {new Array(total).fill(0).map((_, i) => {
            const row = Math.floor(i / 7), col = i % 7, land = 4 + (i / total) * (cAt + 8), p = interpolate(frame, [land - 9, land], [0, 1], clamp);
            const tx = 420 + col * 86 + (row % 2) * 43 + (random(`bx${i}`) - 0.5) * 16, ty = 1250 - row * 74;
            return frame >= land - 9 ? <Ball key={i} x={tx} y={-80 + (ty + 80) * p * p} r={44} rot={i * 47 + frame * (1 - p) * 9} /> : null;
          })}
          <Boy x={210} y={1340} height={430} stage="child" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood={frame > cAt ? 'laugh' : 'shock'} pose={frame > cAt ? 'cheer' : 'stand'} phase={frame / 4} />
          {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={200} size={84} color="#fff" rot={-3} /> : null}
          <div style={{position: 'absolute', top: 390, width: '100%', textAlign: 'center'}}>
            <span style={{fontFamily: DISPLAY, fontSize: 300, lineHeight: 1, color: '#fde047', WebkitTextStroke: `14px ${OL}`, paintOrder: 'stroke fill', fontVariantNumeric: 'tabular-nums'}}>{n}</span>
          </div>
          {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={720} size={92} color="#ef4444" fg="#fff" rot={3} /> : null}
        </Camera>
      </Shake>
    </Shake>
  );
};

/* hyperKid: { age?, tag, tagOnWord?, tag2, tag2OnWord? } — living room; a tiny kid zooms wall to wall leaving speed streaks, mum at her wits' end. */
const HyperKid: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.45), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.8);
  const ph = frame / 9, kx = 330 + Math.sin(ph) * 240, dir = Math.cos(ph) < 0;
  return (
    <Shake at={t2} amount={16}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: '#fecaca'}} />
        <AbsoluteFill style={{background: 'repeating-linear-gradient(90deg, rgba(255,255,255,0.25) 0 30px, transparent 30px 90px)'}} />
        <div style={{position: 'absolute', left: 90, top: 480, width: 240, height: 200, background: '#fef3c7', border: `10px solid #92400e`, outline: `7px solid ${OL}`, rotate: `${Math.sin(frame / 2) * 5}deg`}} />
        <div style={{position: 'absolute', left: 40, top: 1080, width: 520, height: 210, background: '#7c3aed', border: `10px solid ${OL}`, borderRadius: 40}} /><div style={{position: 'absolute', left: 20, top: 980, width: 560, height: 150, background: '#8b5cf6', border: `10px solid ${OL}`, borderRadius: 40}} />
        <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: '#b45309', borderTop: `10px solid ${OL}`}} />
        {[1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: kx + (dir ? 1 : -1) * i * 70 - 60, top: 1090 + i * 30, width: 120, height: 12, borderRadius: 6, background: '#fff', opacity: 0.8 - i * 0.2}} />)}
        <Boy x={kx} y={1340} height={330} stage="child" pose="run" phase={frame / 1.6} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="laugh" flip={dir} />
        <Boy x={860} y={1340} height={640} stage="adult" hair="long" skin="#mum-figure" rim="#fff" glow={0.2} mood={frame >= t2 ? 'happy' : 'shock'} flip />
        {frame < t2 ? [0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 790 + i * 60, top: 600 - ((frame * 3 + i * 20) % 60), fontFamily: DISPLAY, fontSize: 70, color: '#ef4444', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>!</div>) : null}
        {scene.age ? <Tag text={scene.age as string} at={0} x={300} y={240} size={96} color="#fff" rot={-4} /> : null}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={400} size={76} color="#7dd3fc" rot={3} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={560} x={420} size={110} color="#4ade80" rot={-4} /> : null}
      </Camera>
    </Shake>
  );
};

/* coalYard: { tag, tagOnWord?, age?, ageOnWord? } — a black-dusted back yard; dad shovels charcoal, the boy hauls a sack. */
const CoalYard: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 12), aAt = at(captions, scene.ageOnWord, fps, dur * 0.6);
  const bx = interpolate(frame, [aAt - 6, dur], [360, 520], clamp);
  return (
    <Camera dur={dur} from={1.08} to={1.0}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #a8a29e, #d6d3d1 60%)'}} />
      <div style={{position: 'absolute', left: 560, top: 520, width: 520, height: 780, background: '#78716c', border: `10px solid ${OL}`}}>
        <div style={{position: 'absolute', left: 60, top: 300, width: 170, height: 480, background: '#292524', border: `9px solid ${OL}`}} /><div style={{position: 'absolute', left: 300, top: 120, width: 150, height: 150, background: '#44403c', border: `9px solid ${OL}`}} />
      </div>
      <div style={{position: 'absolute', left: 520, top: 440, width: 600, height: 0, borderLeft: '300px solid transparent', borderRight: '300px solid transparent', borderBottom: `100px solid #57534e`}} />
      <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: '#292524', borderTop: `10px solid ${OL}`}} />
      <svg width={520} height={300} viewBox="0 0 520 300" style={{position: 'absolute', left: -40, top: 1010}}>
        <path d="M10 290 Q60 110 190 80 Q300 30 380 130 Q480 190 510 290 Z" fill="#1c1917" stroke={OL} strokeWidth={10} />
        {new Array(14).fill(0).map((_, i) => <circle key={i} cx={70 + random(`cx${i}`) * 380} cy={150 + random(`cy${i}`) * 120} r={16 + random(`cr${i}`) * 14} fill="#292524" stroke="#000" strokeWidth={5} />)}
      </svg>
      {new Array(22).fill(0).map((_, i) => { const p = ((frame + i * 9) % 70) / 70; return <div key={i} style={{position: 'absolute', left: 60 + random(`d${i}`) * 900 + Math.sin(frame / 12 + i) * 20, top: 1200 - p * 520, width: 12, height: 12, borderRadius: 6, background: '#1c1917', opacity: 0.55 * (1 - p)}} />; })}
      <Boy x={790} y={1340} height={620} stage="adult" skin="#dad-figure" rim="#fff" glow={0.2} mood="neutral" flip />
      <Boy x={bx} y={1350} height={440} stage="child" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="determined" pose="run" phase={frame / 5} />
      <svg width={170} height={200} viewBox="0 0 170 200" style={{position: 'absolute', left: bx - 150, top: 1010 + Math.sin(frame / 5) * 6, rotate: '-14deg'}}>
        <path d="M30 40 Q20 150 40 180 H130 Q150 150 140 40 Q110 56 85 46 Q60 56 30 40 Z" fill="#a16207" stroke={OL} strokeWidth={10} strokeLinejoin="round" /><path d="M60 44 Q85 10 110 44" fill="#a16207" stroke={OL} strokeWidth={10} /><path d="M50 90 H120 M54 130 H116" stroke="#713f12" strokeWidth={7} />
      </svg>
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={230} size={84} color="#111" fg="#fff" rot={-3} /> : null}
      {scene.age ? <Tag text={scene.age as string} at={aAt} x={320} y={400} size={84} color="#fde047" rot={3} /> : null}
    </Camera>
  );
};

/* finalsGoals: { finals: [{text, onWord}] } — the grown hero keeps scoring; a "FINAL: GOAL" card slams in for each one. */
const FinalsGoals: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fin = (scene.finals as {text: string; onWord?: string}[]) ?? [];
  const ats = fin.map((f, i) => at(captions, f.onWord, fps, 10 + i * 24));
  const last = ats.reduce((a, b) => (frame >= b ? b : a), -100), k = frame - last, t = clamp && interpolate(k, [0, 9], [0, 1], clamp);
  return (
    <Shake at={ats[0] ?? 0} amount={14}>
      <Shake at={ats[1] ?? 0} amount={14}>
        <Shake at={ats[2] ?? 0} amount={22}>
          <Camera dur={dur} from={1.0} to={1.08}>
            <AbsoluteFill style={{background: 'linear-gradient(180deg, #020617 0%, #1e1b4b 45%, #166534 62%, #14532d 100%)'}} />
            <svg width={1080} height={300} style={{position: 'absolute', top: 760}}>
              {new Array(260).fill(0).map((_, i) => <circle key={i} cx={random(`fx${i}`) * 1080} cy={20 + random(`fy${i}`) * 250 + Math.sin(frame / 3 + i) * 5} r={7} fill={['#7dd3fc', '#f8fafc', '#475569', '#38bdf8', '#334155'][i % 5]} opacity={0.85} />)}
            </svg>
            <div style={{position: 'absolute', left: 0, top: 1060, width: 1080, height: 900, background: 'linear-gradient(180deg, #16a34a, #14532d)', borderTop: '10px solid #fff'}} />
            <svg width={360} height={420} style={{position: 'absolute', left: 720, top: 880}}>
              <g stroke="rgba(255,255,255,0.6)" strokeWidth={3}>{new Array(9).fill(0).map((_, i) => <line key={`v${i}`} x1={20 + i * 40 + (k < 12 ? Math.sin(k) * 8 : 0)} y1={20} x2={20 + i * 40} y2={400} />)}{new Array(10).fill(0).map((_, i) => <line key={`h${i}`} x1={20} y1={30 + i * 40} x2={350} y2={30 + i * 40} />)}</g>
              <path d="M20 400 L20 20 L350 20" stroke="#fff" strokeWidth={16} fill="none" strokeLinejoin="round" />
            </svg>
            <Boy x={300} y={1330} height={520} stage="adult" pose={k >= 0 && k < 14 ? 'kick' : 'cheer'} phase={k >= 0 && k < 14 ? (k / 14) * Math.PI * 2 : frame / 4} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.7} mood={last >= 0 ? 'laugh' : 'determined'} />
            {last >= 0 ? <Ball x={420 + t * 440} y={1270 - t * 250 - Math.sin(t * Math.PI) * 90} r={34} rot={frame * 20} /> : <Ball x={420} y={1290} r={34} />}
            {fin.map((f, i) => { const s = spring({frame: frame - ats[i], fps, config: {damping: 9, stiffness: 200}}); return (
              <div key={i} style={{position: 'absolute', left: 110, top: 240 + i * 170, width: 860, height: 140, borderRadius: 26, border: `9px solid ${OL}`, boxShadow: `0 11px 0 ${OL}`, background: ['#fff', '#7dd3fc', '#fde047'][i % 3], opacity: frame >= ats[i] ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${[-2, 2, -1][i % 3]}deg`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 34px'}}>
                <span style={{fontFamily: DISPLAY, fontSize: 70, color: '#111'}}>{f.text}</span>
                <span style={{fontFamily: DISPLAY, fontSize: 70, color: '#fff', background: '#16a34a', border: `6px solid ${OL}`, borderRadius: 14, padding: '0 18px'}}>GOAL</span>
              </div>); })}
          </Camera>
        </Shake>
      </Shake>
    </Shake>
  );
};

export const STORY8_SCENES: Record<string, React.FC<SceneProps>> = {
  ballFee: BallFee,
  hyperKid: HyperKid,
  coalYard: CoalYard,
  finalsGoals: FinalsGoals,
};
