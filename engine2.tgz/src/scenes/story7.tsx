import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {BODY, DISPLAY} from '../fonts';

/* Story scenes, set 7 (cartoon): kitchenMilk, darkFlat, goalMachine, debutNight. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

/* kitchenMilk: { pourOnWord, tag?, tagOnWord?, stamp?, stampOnWord? } — mum tops up the milk with water at the counter; the boy watches. */
const KitchenMilk: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pour = at(captions, scene.pourOnWord, fps, 12), tAt = at(captions, scene.tagOnWord, fps, pour + 6), st = at(captions, scene.stampOnWord, fps, dur * 0.8);
  const p = interpolate(frame, [pour, pour + 40], [0, 1], clamp);
  const ss = spring({frame: frame - st, fps, config: {damping: 8, stiffness: 200}});
  const tilt = interpolate(frame, [pour - 8, pour], [0, -55], clamp);
  return (
    <Shake at={st} amount={18}>
      <Camera dur={dur} from={1.1} to={1.0}>
        <AbsoluteFill style={{background: '#d9f99d'}} />
        {new Array(8).fill(0).map((_, r) => new Array(7).fill(0).map((__, c) => <div key={`${r}${c}`} style={{position: 'absolute', left: c * 160 - 20, top: r * 160 - 40, width: 150, height: 150, background: (r + c) % 2 ? '#ecfccb' : '#d9f99d', border: '4px solid #bef264'}} />))}
        {/* fridge */}
        <div style={{position: 'absolute', left: 40, top: 430, width: 300, height: 760, background: '#e2e8f0', border: `10px solid ${OL}`, borderRadius: 24}}>
          <div style={{position: 'absolute', left: 0, right: 0, top: 240, height: 10, background: OL}} /><div style={{position: 'absolute', right: 26, top: 90, width: 16, height: 90, background: '#64748b', borderRadius: 8}} /><div style={{position: 'absolute', right: 26, top: 300, width: 16, height: 140, background: '#64748b', borderRadius: 8}} />
        </div>
        {/* counter */}
        <div style={{position: 'absolute', left: 300, top: 1040, width: 800, height: 60, background: '#fef3c7', border: `10px solid ${OL}`, borderRadius: 14}} />
        <div style={{position: 'absolute', left: 330, top: 1100, width: 760, height: 420, background: '#b45309', border: `10px solid ${OL}`}}>{[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 30 + i * 240, top: 40, width: 200, height: 300, border: `7px solid ${OL}`, borderRadius: 10, background: '#d97706'}} />)}</div>
        <div style={{position: 'absolute', left: 0, top: 1500, width: 1080, height: 500, background: '#78716c', borderTop: `10px solid ${OL}`}} />
        {/* milk bottle */}
        <svg width={170} height={300} viewBox="0 0 170 300" style={{position: 'absolute', left: 600, top: 750}}>
          <path d="M55 10 H115 V70 Q150 100 150 150 V270 Q150 290 130 290 H40 Q20 290 20 270 V150 Q20 100 55 70 Z" fill="#f8fafc" stroke={OL} strokeWidth={10} strokeLinejoin="round" />
          <path d={`M26 ${270 - 60 - p * 70} H144 V270 Q144 284 130 284 H40 Q26 284 26 270 Z`} fill={`rgb(${248 - p * 40}, ${250 - p * 14}, 252)`} />
          <rect x={40} y={150} width={90} height={60} rx={8} fill="#60a5fa" stroke={OL} strokeWidth={6} /><text x={85} y={192} textAnchor="middle" fontFamily="Anton" fontSize={34} fill="#fff">MILK</text>
        </svg>
        {/* jug + stream */}
        {frame >= pour && p < 1 ? <div style={{position: 'absolute', left: 676, top: 640, width: 14, height: 130, background: '#7dd3fc', borderRadius: 7, opacity: 0.9}} /> : null}
        <svg width={220} height={220} viewBox="0 0 220 220" style={{position: 'absolute', left: 660, top: 500, rotate: `${tilt}deg`, transformOrigin: '40px 160px'}}>
          <path d="M40 40 H150 L140 190 H50 Z" fill="#bae6fd" stroke={OL} strokeWidth={10} strokeLinejoin="round" /><path d="M150 70 Q205 80 196 130 Q190 160 144 150" fill="none" stroke={OL} strokeWidth={12} strokeLinecap="round" />
          <path d={`M48 ${100 + p * 50} H146 L141 184 H53 Z`} fill="#38bdf8" />
        </svg>
        <Boy x={880} y={1500} height={700} stage="adult" hair="long" skin="#mum-figure" rim="#fff" glow={0.1} mood="sad" flip />
        <Boy x={250} y={1520} height={420} stage="child" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.4} mood={frame >= pour ? 'sad' : 'neutral'} />
        {scene.age ? <Tag text={scene.age as string} at={0} y={230} size={96} color="#fff" rot={-3} /> : null}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={390} size={72} color="#7dd3fc" rot={2} /> : null}
        <div style={{position: 'absolute', left: 0, right: 0, top: 620, textAlign: 'center', opacity: frame >= st ? 1 : 0, scale: String(2.6 - ss * 1.6), rotate: '-10deg'}}>
          <span style={{fontFamily: DISPLAY, fontSize: 210, color: '#ef4444', border: '14px solid #ef4444', padding: '0 40px', borderRadius: 26, background: '#00000099'}}>{(scene.stamp as string) ?? 'BROKE'}</span>
        </div>
      </Camera>
    </Shake>
  );
};

/* darkFlat: { tags: [{text,onWord}] } — lights out: a dead bulb, a candle, a cold tap, the boy shivering in the dark. */
const DarkFlat: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tags = (scene.tags as {text: string; onWord?: string}[]) ?? [];
  const fl = 0.85 + Math.sin(frame / 2.3) * 0.08 + Math.sin(frame / 5.1) * 0.07;
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <AbsoluteFill style={{background: '#0b1020'}} />
      <div style={{position: 'absolute', left: 640, top: 420, width: 330, height: 400, background: 'linear-gradient(180deg, #1e1b4b, #312e81)', border: `12px solid ${OL}`, borderRadius: 12}}>
        <div style={{position: 'absolute', left: 190, top: 60, width: 90, height: 90, borderRadius: '50%', background: '#e0e7ff', boxShadow: '0 0 60px #c7d2fe'}} /><div style={{position: 'absolute', left: 154, top: 0, width: 12, height: 400, background: OL}} /><div style={{position: 'absolute', left: 0, top: 190, width: 330, height: 12, background: OL}} />
      </div>
      {/* dead bulb */}
      <svg width={200} height={330} viewBox="0 0 200 330" style={{position: 'absolute', left: 200, top: 0, rotate: `${Math.sin(frame / 14) * 3}deg`, transformOrigin: '100px 0'}}>
        <path d="M100 0 V170" stroke={OL} strokeWidth={10} /><rect x={78} y={170} width={44} height={40} fill="#64748b" stroke={OL} strokeWidth={8} />
        <path d="M100 210 Q40 230 46 280 Q56 322 100 322 Q144 322 154 280 Q160 230 100 210 Z" fill="#334155" stroke={OL} strokeWidth={9} /><path d="M70 250 L130 300 M130 250 L70 300" stroke="#ef4444" strokeWidth={12} strokeLinecap="round" />
      </svg>
      <div style={{position: 'absolute', left: 0, top: 1320, width: 1080, height: 700, background: '#1c1917', borderTop: `10px solid ${OL}`}} />
      {/* candle glow */}
      <div style={{position: 'absolute', left: 540 - 520, top: 1040 - 520, width: 1040, height: 1040, borderRadius: '50%', background: `radial-gradient(circle, rgba(253,186,116,${0.5 * fl}) 0%, rgba(253,186,116,0.12) 45%, transparent 68%)`}} />
      <Boy x={380} y={1340} height={520} stage="child" skin={sb.character.palette.skin} rim="#fdba74" glow={0.7} mood="sad" />
      {[0, 1, 2].map((i) => { const t = ((frame + i * 14) % 44) / 44; return <div key={i} style={{position: 'absolute', left: 470 + t * 70, top: 960 - t * 80, width: 30 + t * 50, height: 30 + t * 50, borderRadius: '50%', background: '#e2e8f0', opacity: 0.35 * (1 - t)}} />; })}
      <svg width={200} height={330} viewBox="0 0 200 330" style={{position: 'absolute', left: 620, top: 1020}}>
        <path d={`M100 ${30 - fl * 10} Q${70 - Math.sin(frame / 3) * 8} 80 100 120 Q${130 + Math.sin(frame / 3) * 8} 80 100 ${30 - fl * 10} Z`} fill="#fb923c" stroke={OL} strokeWidth={7} strokeLinejoin="round" /><path d="M100 70 Q88 96 100 116 Q112 96 100 70 Z" fill="#fde047" />
        <rect x={72} y={120} width={56} height={150} rx={8} fill="#fffbeb" stroke={OL} strokeWidth={9} /><ellipse cx={100} cy={280} rx={86} ry={24} fill="#a16207" stroke={OL} strokeWidth={9} />
      </svg>
      {tags.map((t, i) => <Tag key={i} text={t.text} at={at(captions, t.onWord, fps, 10 + i * 24)} y={340 + i * 440} x={i ? 620 : 540} size={84} color={i ? '#7dd3fc' : '#fde047'} rot={i ? 3 : -4} />)}
    </Camera>
  );
};

/* goalMachine: { age?, goals, games, countOnWord?, gamesOnWord? } — the kid hammers ball after ball into the net while a counter spins up. */
const GoalMachine: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cAt = at(captions, scene.countOnWord, fps, 10), gAt = at(captions, scene.gamesOnWord, fps, dur * 0.7), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.85);
  const goals = (scene.goals as number) ?? 76;
  const n = Math.round(goals * interpolate(frame, [cAt, cAt + 34], [0, 1], {...clamp, easing: (t) => 1 - Math.pow(1 - t, 2)}));
  const cyc = 9, k = frame % cyc, t = k / cyc;
  const bx = 400 + t * 440, by = 1250 - Math.sin(t * Math.PI) * 220 - t * 150 + ((Math.floor(frame / cyc) * 37) % 120 - 60) * t;
  const net = Math.sin(frame / 1.5) * 6;
  return (
    <Shake at={gAt} amount={14}>
      <Camera dur={dur} from={1.06} to={1.0}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #38bdf8 0%, #bae6fd 46%, #4ade80 58%, #15803d 100%)'}} />
        {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: ((i * 420 + frame * 0.6) % 1400) - 200, top: 380 + i * 90, width: 260, height: 80, borderRadius: 60, background: '#fff', opacity: 0.85}} />)}
        <svg width={420} height={560} style={{position: 'absolute', left: 670, top: 760}}>
          <g stroke="rgba(255,255,255,0.6)" strokeWidth={3}>{new Array(10).fill(0).map((_, i) => <line key={`v${i}`} x1={30 + i * 40 + net} y1={20} x2={30 + i * 40} y2={520} />)}{new Array(13).fill(0).map((_, i) => <line key={`h${i}`} x1={30} y1={30 + i * 40} x2={400 + net} y2={30 + i * 40} />)}</g>
          <path d="M30 520 L30 20 L400 20" stroke="#fff" strokeWidth={18} fill="none" strokeLinejoin="round" /><path d="M30 520 L30 20 L400 20" stroke={OL} strokeWidth={4} fill="none" opacity={0.3} />
        </svg>
        <div style={{position: 'absolute', left: 0, top: 1280, width: 1080, height: 700, background: 'linear-gradient(180deg, #16a34a, #14532d)', borderTop: '10px solid #fff'}} />
        <Boy x={330} y={1320} height={520} stage="teen" pose="kick" phase={(k / cyc) * Math.PI * 2} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="determined" />
        <div style={{position: 'absolute', left: bx - 30, top: by - 30, width: 60, height: 60, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #d4d4d4)', border: `6px solid ${OL}`}} />
        {[0, 1, 2, 3, 4].map((i) => <div key={i} style={{position: 'absolute', left: 760 + (i % 3) * 90, top: 1180 + Math.floor(i / 3) * 50, width: 56, height: 56, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #d4d4d4)', border: `6px solid ${OL}`, opacity: n > i * 12 ? 1 : 0}} />)}
        {scene.age && !(scene.tag2 && frame >= t2) ? <Tag text={scene.age as string} at={0} y={210} size={84} color="#fff" rot={-3} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={200} size={88} color="#fff" rot={-4} /> : null}
        <div style={{position: 'absolute', top: 375, width: '100%', textAlign: 'center', opacity: frame >= cAt ? 1 : 0}}>
          <span style={{fontFamily: DISPLAY, fontSize: 250, lineHeight: 1, color: '#fde047', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill', fontVariantNumeric: 'tabular-nums'}}>{n}</span>
          <span style={{fontFamily: DISPLAY, fontSize: 90, color: '#fff', WebkitTextStroke: `8px ${OL}`, paintOrder: 'stroke fill', marginLeft: 16}}>GOALS</span>
        </div>
        <Tag text={`IN ${(scene.games as number) ?? 34} GAMES`} at={gAt} y={655} size={84} color="#ef4444" fg="#fff" rot={3} />
      </Camera>
    </Shake>
  );
};

/* debutNight: { card1, card2, card1OnWord?, card2OnWord?, tag?, tagOnWord? } — floodlit stadium; calendar cards slam in; the teen hero walks out. */
const DebutNight: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const c1 = at(captions, scene.card1OnWord, fps, 8), c2 = at(captions, scene.card2OnWord, fps, dur * 0.5), tAt = at(captions, scene.tagOnWord, fps, dur * 0.25);
  const s1 = spring({frame: frame - c1, fps, config: {damping: 11}}), s2 = spring({frame: frame - c2, fps, config: {damping: 8, stiffness: 200}});
  return (
    <Shake at={c2} amount={18}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg, #020617 0%, #1e1b4b 45%, #166534 62%, #14532d 100%)'}} />
        {[90, 990].map((x) => <React.Fragment key={x}><div style={{position: 'absolute', left: x - 10, top: 330, width: 20, height: 500, background: '#475569', border: `5px solid ${OL}`}} /><div style={{position: 'absolute', left: x - 80, top: 250, width: 160, height: 90, background: '#fef9c3', border: `8px solid ${OL}`, borderRadius: 10, boxShadow: '0 0 90px #fef08a'}} />
          <div style={{position: 'absolute', left: x - 500, top: 300, width: 1000, height: 1100, background: 'linear-gradient(180deg, rgba(254,249,195,0.2), transparent 80%)', clipPath: x < 540 ? 'polygon(46% 0, 54% 0, 100% 100%, 30% 100%)' : 'polygon(46% 0, 54% 0, 70% 100%, 0 100%)'}} /></React.Fragment>)}
        <svg width={1080} height={420} style={{position: 'absolute', top: 640}}>
          {new Array(320).fill(0).map((_, i) => <circle key={i} cx={random(`dx${i}`) * 1080} cy={30 + random(`dy${i}`) * 340 + Math.sin(frame / 3 + i) * 5} r={7} fill={['#a78bfa', '#f8fafc', '#475569', '#7c3aed', '#334155'][i % 5]} opacity={0.85} />)}
        </svg>
        <div style={{position: 'absolute', left: 0, top: 1060, width: 1080, height: 900, background: 'linear-gradient(180deg, #16a34a, #14532d)', borderTop: '10px solid #fff'}} />
        <Boy x={540} y={1330} height={600} stage="teen" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.8} mood={frame >= c2 ? 'laugh' : 'determined'} pose={frame >= c2 ? 'cheer' : 'stand'} phase={frame / 4} />
        {[{t: (scene.card1 as string) ?? '', s: s1, a: c1, x: 60, c: '#fff', r: -6}, {t: (scene.card2 as string) ?? '', s: s2, a: c2, x: 560, c: '#fde047', r: 5}].map((c, i) => (
          <div key={i} style={{position: 'absolute', left: c.x, top: 390, width: 460, height: 250, background: c.c, border: `10px solid ${OL}`, borderRadius: 26, boxShadow: `0 12px 0 ${OL}`, opacity: frame >= c.a ? 1 : 0, scale: String(1.7 - c.s * 0.7), rotate: `${c.r}deg`, overflow: 'hidden'}}>
            <div style={{height: 56, background: '#ef4444', borderBottom: `8px solid ${OL}`}} />
            <div style={{fontFamily: DISPLAY, fontSize: 84, lineHeight: 1.05, color: '#111', textAlign: 'center', paddingTop: 8}}>{c.t}</div>
          </div>
        ))}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={230} size={84} color="#22c55e" fg="#fff" /> : null}
      </Camera>
    </Shake>
  );
};

export const STORY7_SCENES: Record<string, React.FC<SceneProps>> = {
  kitchenMilk: KitchenMilk,
  darkFlat: DarkFlat,
  goalMachine: GoalMachine,
  debutNight: DebutNight,
};
