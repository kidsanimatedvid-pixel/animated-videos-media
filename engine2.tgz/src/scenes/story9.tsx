import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {SceneProps} from '../types';
import {Boy} from '../components/Boy';
import {Camera, Shake} from '../components/Fx';
import {wordFrame} from './kit';
import {DISPLAY} from '../fonts';

/* Story scenes, set 9 (cartoon): shirtLift, desertTown, skinnyCoach, goldenBoot, emptyChair, twoHeaders. */
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const OL = '#1b1b22';
const at = (captions: SceneProps['captions'], w: unknown, fps: number, fb: number) => (w ? wordFrame(captions, w as string, fps, fb) : fb);

const Tag: React.FC<{text: string; at: number; x?: number; y: number; color?: string; size?: number; rot?: number; fg?: string}> = ({text, at: a, x = 540, y, color = '#ffcc4d', size = 64, rot = -3, fg = '#111'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - a, fps, config: {damping: 10, stiffness: 190}});
  return (
    <div style={{position: 'absolute', left: x - 500, width: 1000, top: y, textAlign: 'center', opacity: frame >= a ? 1 : 0, scale: String(1.6 - s * 0.6), rotate: `${rot}deg`}}>
      <span style={{fontFamily: DISPLAY, fontSize: size, color: fg, background: color, padding: '4px 28px', borderRadius: 16, border: `6px solid ${OL}`, boxShadow: `0 9px 0 ${OL}`}}>{text}</span>
    </div>
  );
};

const Crowd: React.FC<{top: number; h: number; cols?: string[]}> = ({top, h, cols = ['#fde047', '#f8fafc', '#2563eb', '#ef4444', '#475569']}) => {
  const frame = useCurrentFrame();
  return <svg width={1080} height={h} style={{position: 'absolute', top}}>{new Array(300).fill(0).map((_, i) => <circle key={i} cx={random(`cx${i}`) * 1080} cy={20 + random(`cy${i}`) * (h - 40) + Math.sin(frame / 3 + i) * 5} r={7} fill={cols[i % cols.length]} opacity={0.85} />)}</svg>;
};

/* shirtLift: { text, liftOnWord, tag?, tagOnWord? } — night stadium; the hero pulls his shirt up to show a hand-written message underneath. */
const ShirtLift: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lAt = at(captions, scene.liftOnWord, fps, dur * 0.4), tAt = at(captions, scene.tagOnWord, fps, 6);
  const p = interpolate(frame, [lAt, lAt + 8], [0, 1], clamp);
  const toon = (sb.character as unknown as {toon: {shirt: string}}).toon;
  const X = 540, Y = 1340, Hh = 700, chest = Y - Hh * 0.62;
  return (
    <Shake at={0} amount={24}>
      <Shake at={lAt} amount={18}>
        <Camera dur={dur} from={1.25} to={1.02}>
          <AbsoluteFill style={{background: 'linear-gradient(180deg, #020617 0%, #1e1b4b 40%, #14532d 62%, #166534 100%)'}} />
          <Crowd top={560} h={420} cols={['#ef4444', '#f8fafc', '#b91c1c', '#475569']} />
          {[110, 970].map((x) => <div key={x} style={{position: 'absolute', left: x - 70, top: 300, width: 140, height: 80, background: '#fef9c3', border: `8px solid ${OL}`, borderRadius: 10, boxShadow: '0 0 90px #fef08a'}} />)}
          <div style={{position: 'absolute', left: 0, top: 1040, width: 1080, height: 900, background: 'linear-gradient(180deg, #16a34a, #14532d)', borderTop: '10px solid #fff'}} />
          <Boy x={X} y={Y} height={Hh} stage="adult" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.8} mood={frame >= lAt ? 'cry' : 'determined'} pose="stand" />
          {/* undershirt panel */}
          <div style={{position: 'absolute', left: X - 160, top: chest - 70, width: 320, height: 250 * p, background: '#fff', border: p > 0 ? `8px solid ${OL}` : 'none', borderRadius: 18, overflow: 'hidden'}}>
            <div style={{fontFamily: DISPLAY, fontSize: 64, lineHeight: 1.05, color: '#111', textAlign: 'center', paddingTop: 22, rotate: '-3deg'}}>{((scene.text as string) ?? '').split('|').map((l, i) => <div key={i}>{l}</div>)}</div>
          </div>
          {/* the rolled-up shirt over the face */}
          <div style={{position: 'absolute', left: X - 175, top: chest - 70 - p * 175, width: 350, height: 70 + p * 40, background: toon.shirt, border: `8px solid ${OL}`, borderRadius: 30, opacity: p > 0 ? 1 : 0}} />
          {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={220} size={92} color="#ef4444" fg="#fff" rot={-3} /> : null}
        </Camera>
      </Shake>
    </Shake>
  );
};

/* desertTown: { tags: [{text,onWord}] } — dusty desert town at the border: cacti, a dirt pitch, a kid dribbling barefoot. */
const DesertTown: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tags = (scene.tags as {text: string; onWord?: string}[]) ?? [];
  const bx = 300 + Math.sin(frame / 10) * 260;
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #fb923c 0%, #fde68a 55%, #f59e0b 56%, #c2410c 100%)'}} />
      <div style={{position: 'absolute', left: 740, top: 360, width: 200, height: 200, borderRadius: '50%', background: '#fff7c2', boxShadow: '0 0 140px #fde047'}} />
      {[[110, 820, 1], [960, 880, 0.8]].map(([x, y, s], i) => <svg key={i} width={160} height={300} viewBox="0 0 160 300" style={{position: 'absolute', left: (x as number) - 80, top: y as number, scale: String(s)}}><path d="M60 300 V60 Q80 20 100 60 V300 Z M60 170 H30 V110 Q40 90 50 110 V140 H60 M100 150 H130 V90 Q120 70 110 90 V120 H100" fill="#16a34a" stroke={OL} strokeWidth={9} strokeLinejoin="round" /></svg>)}
      {[0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 300 + i * 200, top: 900 + (i % 2) * 20, width: 150, height: 120, background: ['#fef3c7', '#fecaca', '#bae6fd'][i], border: `8px solid ${OL}`}}><div style={{position: 'absolute', left: -14, top: -36, width: 166, height: 36, background: '#a16207', border: `7px solid ${OL}`}} /></div>)}
      <div style={{position: 'absolute', left: 0, top: 1150, width: 1080, height: 900, background: '#b45309', borderTop: `10px solid ${OL}`}} />
      {[0, 1, 2, 3].map((i) => { const p = ((frame + i * 6) % 24) / 24; return <div key={i} style={{position: 'absolute', left: bx - 60 - p * 60, top: 1300 - p * 50, width: 40 + p * 60, height: 40 + p * 60, borderRadius: '50%', background: '#fed7aa', opacity: 0.6 * (1 - p)}} />; })}
      <Boy x={bx} y={1360} height={420} stage="child" pose="run" phase={frame / 2.4} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="happy" flip={Math.cos(frame / 10) < 0} />
      <div style={{position: 'absolute', left: bx + (Math.cos(frame / 10) < 0 ? -90 : 60), top: 1300, width: 50, height: 50, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #d4d4d4)', border: `6px solid ${OL}`}} />
      {tags.map((t, i) => <Tag key={i} text={t.text} at={at(captions, t.onWord, fps, 10 + i * 18)} x={[400, 680, 470][i % 3]} y={230 + i * 160} size={84} color={['#fff', '#fde047', '#f472b6'][i % 3]} rot={[-4, 3, -2][i % 3]} />)}
    </Camera>
  );
};

/* skinnyCoach: { tag, tagOnWord?, tag2?, tag2OnWord? } — a scale; the skinny teen steps on and the needle barely moves; the coach gasps. */
const SkinnyCoach: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, dur * 0.4), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.75);
  const needle = interpolate(frame, [tAt - 10, tAt], [-80, -55], clamp) + Math.sin(frame / 2) * 3;
  return (
    <Camera dur={dur} from={1.0} to={1.08}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, #fef3c7, #fde68a)'}} />
      <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: '#a16207', borderTop: `10px solid ${OL}`}} />
      <svg width={230} height={230} viewBox="0 0 300 300" style={{position: 'absolute', left: 390, top: 990}}>
        <circle cx={150} cy={150} r={130} fill="#fff" stroke={OL} strokeWidth={14} />
        {new Array(9).fill(0).map((_, i) => <rect key={i} x={146} y={30} width={8} height={24} fill={OL} transform={`rotate(${-80 + i * 20} 150 150)`} />)}
        <rect x={145} y={46} width={10} height={108} rx={5} fill="#ef4444" transform={`rotate(${needle} 150 150)`} /><circle cx={150} cy={150} r={14} fill={OL} />
      </svg>
      <div style={{position: 'absolute', left: 130, top: 1240, width: 280, height: 50, background: '#94a3b8', border: `8px solid ${OL}`, borderRadius: 14}} />
      <div style={{position: 'absolute', left: 0, top: 0, scale: '0.62 1', transformOrigin: '270px 1250px'}}>
        <Boy x={270} y={1250} height={560} stage="teen" skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.5} mood="neutral" />
      </div>
      <Boy x={780} y={1340} height={620} stage="adult" skin="#coach-b" rim="#fff" glow={0.2} mood={frame >= tAt ? 'shock' : 'neutral'} flip />
      {frame >= tAt ? [0, 1, 2].map((i) => <div key={i} style={{position: 'absolute', left: 720 + i * 50, top: 560 - ((frame * 3 + i * 20) % 60), fontFamily: DISPLAY, fontSize: 80, color: '#ef4444', WebkitTextStroke: `7px ${OL}`, paintOrder: 'stroke fill'}}>!</div>) : null}
      {scene.year ? <Tag text={scene.year as string} at={0} y={220} size={110} color="#fff" rot={-4} /> : null}
      {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={380} size={90} color="#fde047" rot={3} /> : null}
      {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={520} size={74} color="#4ade80" rot={-2} /> : null}
    </Camera>
  );
};

/* goldenBoot: { goals, goalsOnWord?, tag, tagOnWord?, tag2?, tag2OnWord? } — a giant golden boot spins down onto a plinth with a goal counter. */
const GoldenBoot: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const gAt = at(captions, scene.goalsOnWord, fps, dur * 0.3), tAt = at(captions, scene.tagOnWord, fps, 8), t2 = at(captions, scene.tag2OnWord, fps, dur * 0.7);
  const s = spring({frame: frame - 4, fps, config: {damping: 9, stiffness: 120}});
  const n = Math.round(interpolate(frame, [gAt, gAt + 16], [0, (scene.goals as number) ?? 4], clamp));
  return (
    <Shake at={gAt + 16} amount={16}>
      <Camera dur={dur} from={1.0} to={1.06}>
        <AbsoluteFill style={{background: '#78350f'}} />
        <AbsoluteFill style={{background: 'repeating-conic-gradient(from 0deg at 50% 46%, #92400e 0 9deg, #b45309 9deg 18deg)', rotate: `${frame * 0.3}deg`, scale: '2.2'}} />
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 46%, rgba(253,224,71,0.5), transparent 55%)'}} />
        <svg width={460} height={360} viewBox="0 0 460 360" style={{position: 'absolute', left: 310, top: 560 - (1 - s) * 700, rotate: `${(1 - s) * 200 + Math.sin(frame / 10) * 4}deg`}}>
          <path d="M120 20 H250 V170 Q330 170 400 210 Q450 240 440 300 H40 Q30 240 60 200 Q110 170 120 120 Z" fill="#fbbf24" stroke={OL} strokeWidth={14} strokeLinejoin="round" />
          <path d="M40 300 H440 V330 Q440 345 425 345 H55 Q40 345 40 330 Z" fill="#d97706" stroke={OL} strokeWidth={12} />
          {[180, 230, 280].map((x) => <path key={x} d={`M${x - 40} ${x - 10} l60 20`} stroke="#fff7" strokeWidth={9} strokeLinecap="round" />)}
          {[100, 180, 260, 340].map((x) => <circle key={x} cx={x} cy={358} r={10} fill="#d97706" stroke={OL} strokeWidth={6} />)}
        </svg>
        <div style={{position: 'absolute', left: 300, top: 960, width: 480, height: 150, background: '#1c1917', border: `10px solid ${OL}`, borderRadius: 16, textAlign: 'center', fontFamily: DISPLAY, fontSize: 96, lineHeight: '130px', color: '#fde047'}}>{n} GOALS</div>
        <div style={{position: 'absolute', left: 0, top: 1240, width: 1080, height: 700, background: '#451a03', borderTop: `10px solid ${OL}`}} />
        <Boy x={170} y={1330} height={470} stage="adult" skin={sb.character.palette.skin} rim="#fde047" glow={0.8} pose="cheer" mood="laugh" phase={frame / 4} />
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={220} size={80} color="#fff" rot={-3} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={t2} y={380} size={92} color="#fde047" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* emptyChair: { days, countOnWord?, tag, tagOnWord?, homeOnWord, tag2? } — night kitchen, dad's chair empty while a calendar counts days; then he walks back in. */
const EmptyChair: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tAt = at(captions, scene.tagOnWord, fps, 6), cAt = at(captions, scene.countOnWord, fps, dur * 0.4), hAt = at(captions, scene.homeOnWord, fps, dur * 0.75);
  const max = (scene.days as number) ?? 12;
  const d = Math.max(1, Math.round(interpolate(frame, [tAt, cAt + 6], [1, max], clamp)));
  const home = frame >= hAt, dx = interpolate(frame, [hAt, hAt + 14], [1200, 760], clamp);
  return (
    <Shake at={hAt} amount={14}>
      <Camera dur={dur} from={1.0} to={1.08}>
        <AbsoluteFill style={{background: home ? 'linear-gradient(180deg, #fde68a, #fdba74)' : 'linear-gradient(180deg, #1e293b, #334155)'}} />
        <div style={{position: 'absolute', left: 90, top: 380, width: 280, height: 280, background: home ? '#bae6fd' : '#0f172a', border: `12px solid #78350f`, outline: `7px solid ${OL}`}} />
        <div style={{position: 'absolute', left: 0, top: 1270, width: 1080, height: 700, background: home ? '#b45309' : '#1c1917', borderTop: `10px solid ${OL}`}} />
        {/* chair */}
        <svg width={260} height={420} viewBox="0 0 260 420" style={{position: 'absolute', left: home ? 140 : 400, top: 870}}>
          <rect x={40} y={0} width={30} height={240} rx={8} fill="#a16207" stroke={OL} strokeWidth={8} /><rect x={40} y={210} width={190} height={34} rx={8} fill="#ca8a04" stroke={OL} strokeWidth={8} />
          <rect x={40} y={240} width={24} height={170} fill="#a16207" stroke={OL} strokeWidth={7} /><rect x={200} y={240} width={24} height={170} fill="#a16207" stroke={OL} strokeWidth={7} />
        </svg>
        {!home ? <Boy x={180} y={1340} height={460} stage="adult" hair="long" skin="#family-mum" rim="#94a3b8" glow={0.2} mood="cry" /> : null}
        <div style={{position: 'absolute', left: 660, top: 380, width: 330, height: 300, background: '#fff', border: `10px solid ${OL}`, borderRadius: 24, boxShadow: `0 12px 0 ${OL}`, overflow: 'hidden', rotate: '4deg', textAlign: 'center'}}>
          <div style={{height: 80, background: '#ef4444', borderBottom: `8px solid ${OL}`, fontFamily: DISPLAY, fontSize: 56, color: '#fff', lineHeight: '80px'}}>DAY</div>
          <div style={{fontFamily: DISPLAY, fontSize: 190, lineHeight: 1.08, color: '#111'}}>{d}</div>
        </div>
        {home ? <><Boy x={dx} y={1340} height={600} stage="adult" skin="#family-dad" rim="#fff" glow={0.4} mood="laugh" flip /><Boy x={dx - 230} y={1350} height={470} stage="adult" hair="long" skin="#family-mum" rim="#fff" glow={0.3} mood="laugh" /></> : null}
        {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={220} size={84} color="#fff" rot={-3} /> : null}
        {scene.tag2 ? <Tag text={scene.tag2 as string} at={hAt} y={760} size={110} color="#4ade80" rot={3} /> : null}
      </Camera>
    </Shake>
  );
};

/* twoHeaders: { g1OnWord, g2OnWord, score1, score2, tag?, tagOnWord? } — stadium; dad cries in the stands; the hero heads in twice and the scoreboard flips. */
const TwoHeaders: React.FC<SceneProps> = ({sb, scene, captions, durationInFrames: dur}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const g1 = at(captions, scene.g1OnWord, fps, dur * 0.3), g2 = at(captions, scene.g2OnWord, fps, dur * 0.55), tAt = at(captions, scene.tagOnWord, fps, dur * 0.8);
  const last = frame >= g2 ? g2 : frame >= g1 ? g1 : -100, k = frame - last;
  const t = interpolate(k, [0, 10], [0, 1], clamp);
  const score = frame >= g2 ? (scene.score2 as string) : frame >= g1 ? (scene.score1 as string) : (scene.score0 as string) ?? '0 - 1';
  const sp = spring({frame: frame - last, fps, config: {damping: 8, stiffness: 200}});
  return (
    <Shake at={g1} amount={16}>
      <Shake at={g2} amount={24}>
        <Camera dur={dur} from={1.0} to={1.06}>
          <AbsoluteFill style={{background: 'linear-gradient(180deg, #020617 0%, #1e1b4b 38%, #166534 60%, #14532d 100%)'}} />
          <Crowd top={520} h={420} cols={['#fde047', '#2563eb', '#ef4444', '#f8fafc']} />
          <div style={{position: 'absolute', left: 60, top: 560, width: 300, height: 360, background: '#0f172a', border: `8px solid ${OL}`, borderRadius: 20}} />
          <Boy x={210} y={900} height={300} stage="adult" skin="#family-dad" rim="#fde047" glow={0.6} mood={last > 0 ? 'cry' : 'neutral'} pose={last > 0 ? 'cheer' : 'stand'} phase={frame / 4} />
          <div style={{position: 'absolute', left: 0, top: 1040, width: 1080, height: 900, background: 'linear-gradient(180deg, #16a34a, #14532d)', borderTop: '10px solid #fff'}} />
          <svg width={360} height={400} style={{position: 'absolute', left: 720, top: 860}}>
            <g stroke="rgba(255,255,255,0.6)" strokeWidth={3}>{new Array(9).fill(0).map((_, i) => <line key={`v${i}`} x1={20 + i * 40 + (k >= 0 && k < 12 ? Math.sin(k) * 8 : 0)} y1={20} x2={20 + i * 40} y2={380} />)}{new Array(9).fill(0).map((_, i) => <line key={`h${i}`} x1={20} y1={30 + i * 40} x2={350} y2={30 + i * 40} />)}</g>
            <path d="M20 380 L20 20 L350 20" stroke="#fff" strokeWidth={16} fill="none" strokeLinejoin="round" />
          </svg>
          <Boy x={460} y={1330} height={560} stage="adult" pose={k >= 0 && k < 12 ? 'cheer' : 'stand'} phase={frame / 3} skin={sb.character.palette.skin} rim={sb.character.palette.rim} glow={0.7} mood={last > 0 ? 'laugh' : 'determined'} />
          {last > 0 && k < 12 ? <div style={{position: 'absolute', left: 480 + t * 380 - 30, top: 820 + t * 240 - 30, width: 60, height: 60, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #fff, #d4d4d4)', border: `6px solid ${OL}`}} /> : null}
          <div style={{position: 'absolute', left: 460, top: 300, width: 560, height: 170, background: '#111', border: `10px solid ${OL}`, borderRadius: 20, boxShadow: `0 12px 0 ${OL}`, display: 'flex', alignItems: 'center', justifyContent: 'center', scale: String(1 + (last > 0 ? (1 - sp) * 0.25 : 0))}}>
            <span style={{fontFamily: DISPLAY, fontSize: 120, color: '#fde047', letterSpacing: 6}}>{score}</span>
          </div>
          {last > 0 && k < 26 ? <div style={{position: 'absolute', left: 0, right: 0, top: 700, textAlign: 'center', fontFamily: DISPLAY, fontSize: 180, color: '#fff', WebkitTextStroke: `12px ${OL}`, paintOrder: 'stroke fill', scale: String(0.6 + sp * 0.5), rotate: '-6deg'}}>GOAL!</div> : null}
          {scene.tag ? <Tag text={scene.tag as string} at={tAt} y={200} size={78} color="#fff" rot={-3} /> : null}
          {scene.dadTag ? <Tag text={scene.dadTag as string} at={0} x={210} y={500} size={44} color="#fde047" rot={-3} /> : null}
        </Camera>
      </Shake>
    </Shake>
  );
};

export const STORY9_SCENES: Record<string, React.FC<SceneProps>> = {
  shirtLift: ShirtLift,
  desertTown: DesertTown,
  skinnyCoach: SkinnyCoach,
  goldenBoot: GoldenBoot,
  emptyChair: EmptyChair,
  twoHeaders: TwoHeaders,
};
