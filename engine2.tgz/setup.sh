#!/bin/bash
# Engine v2 restore (22 Nov 2026): run from an empty folder after `tar xzf engine2.tgz`. ~3-5 min.
set -e
npm i --no-audit --no-fund --loglevel=error
pip install --break-system-packages -q kokoro-onnx soundfile numpy scipy faster-whisper >/dev/null 2>&1 || true
mkdir -p models public/vo out
[ -f models/kokoro-v1.0.onnx ] || curl -sSL -o models/kokoro-v1.0.onnx https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx
[ -f models/voices-v1.0.bin ] || curl -sSL -o models/voices-v1.0.bin https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin
[ -f public/sfx/drone.wav ] || python3 scripts/make_sfx.py >/dev/null 2>&1 || true
[ -f public/sfx/music_tension.wav ] || python3 scripts/make_music.py >/dev/null 2>&1 || true
export REMOTION_CHROME=${REMOTION_CHROME:-$(command -v google-chrome || command -v chromium || true)}
npx tsc -p . && echo "ENGINE READY (chrome: $REMOTION_CHROME)"
